__author__ = 'Qiusheng'

import arcpy
import os

workspace = os.path.join(os.path.dirname(os.getcwd()),'data')
clip_fc = os.path.join(workspace, 'basin.shp') 
output_dir = os.path.join(workspace, 'Results') 

arcpy.env.workspace = workspace
arcpy.env.overwriteOutput = True
fc_list = arcpy.ListFeatureClasses()

desc = arcpy.Describe(clip_fc)
if desc.path == workspace:
    fc_list.remove(desc.file)

for fc in fc_list:
    out_fc = os.path.join(output_dir,fc)
    arcpy.Clip_analysis(fc,clip_fc,out_fc)

