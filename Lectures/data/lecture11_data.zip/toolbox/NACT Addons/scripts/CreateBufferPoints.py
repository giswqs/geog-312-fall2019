# ---------------------------------------------------------------------------
# CreateBufferPoints.py
# ---------------------------------------------------------------------------

# Import system modules
import sys, string, os

# arcgis module, nact
from arcgisscripting import ExecuteError as GPError

# add nact.py module
Here = os.path.dirname(sys.argv[0])
sys.path.append(os.path.join(Here,"../scripts"))
import nact
from nact import GPMsg, MsgError, CountRows

# Create the Geoprocessor object
gp = nact.getGP()
# add nact toolbox

gp.OverwriteOutput = True
gp.LogHistory = False

# initialize variables
memWS = "in_memory"
lyrPnt, lyrWeed, tmpFGDB = [None] * 3
try:

  # variables
  inputPoints = gp.GetParameterAsText(0)
  AreaIDField = gp.GetParameterAsText(1)
  outputPoints = gp.GetParameterAsText(2)
  bufRadius = gp.GetParameterAsText(3)
  groupDistance = gp.GetParameterAsText(4)
  groupClump = int(gp.GetParameterAsText(5))
  MGSThresh =  float(gp.GetParameterAsText(6))


  # get processing coordinate system from environment
  CS = gp.OutputCoordinateSystem
  # if not set, use input dataset's coordinate system
  if not CS:
    CS = gp.Describe(inputPoints).SpatialReference
    if CS.Name == "Unknown":
      GPMsg("w","ID 522 %s" % inputFC)
  # check output coordinate system - decimal degrees
  if CS.Type != "Projected":
    GPMsg("e","ID 981 distance") # decimal degrees inappropriate
    raise MsgError, "Tool could not execute"

  outRoot = "buf"

  distUnits = bufRadius.split()[1]
  if not distUnits: distUnits = "Unknown"
  bufValue = float(bufRadius.split()[0])
  weedDist = "%s %s" % ( (bufValue * 2), distUnits)

  GPMsg("Weeding distance: %s (2 x buffer radius)" % weedDist)
  GPMsg("Grouping distance: %s" % groupDistance)
  try:
    groupDist = float(groupDistance.split()[0])
  except:
    groupDist = float(groupDistance)

  # set up a file geodatabase
  tmpFGDB = nact.ScratchName("",".gdb","workspace")
  gp.CreateFileGDB(os.path.dirname(tmpFGDB),os.path.basename(tmpFGDB))
  gp.Workspace = tmpFGDB

  GPMsg("t","Copying features...")
  tmpPoints = "distPoints"

  # first create temp points and
  # delete fields we don't need
  gp.CreateFeatureClass(tmpFGDB,tmpPoints,"#",inputPoints)
  FldList = ""
  for Fld in gp.ListFields(tmpPoints):
    if Fld.Type == "OID": OIDField = Fld.Name
    if not (Fld.Name == AreaIDField or Fld.Type in ["OID","Geometry"]):
      FldList += Fld.Name + ";"
  gp.DeleteField(tmpPoints,FldList)
  gp.AddField(tmpPoints,"PROCID","LONG") # unique feature ids
  gp.AddField(tmpPoints,"PROCPASS","LONG")
  gp.AddField(tmpPoints,"PROCGRP","LONG")
  gp.AddField(tmpPoints,"PROCGRPC","LONG")
  # now copy data and initialize fields
  gp.Append(inputPoints,tmpPoints,"NO_TEST")
  gp.CalculateField(tmpPoints,"PROCID","[%s]" % OIDField)
  gp.CalculateField(tmpPoints,"PROCGRP","-1")

  k = 1
  numGroups = 0
  # Group points
  tmpgrp = "groupPoints"
  lyrPnt = "lyrPnt"
  lyrWeed = "lyrWeed"
  tmpweed = "xxtmpweed"
  gp.MakeFeatureLayer(tmpPoints,lyrPnt,"PROCGRP < 0")
  numPts = nact.CountRows(lyrPnt)
  GPMsg("%s points to process..." % numPts)
  numLeft = numPts
  lastLeft = numPts

  # alternately group and weed to create spatial contiguous groups of points
  # that will have no buffer overlaps

  while numLeft > 1:
    # group points
    GPMsg("t","Grouping points...")
    gp.GroupPoints(lyrPnt,tmpgrp,groupDist,groupClump)
    # weed points
    GPMsg("t","Weeding points...")
    gp.WeedPoints(tmpgrp,tmpweed,weedDist)

    # tag grouped and weeded points
    gp.MakeFeaturelayer(tmpPoints,lyrPnt)
    gp.AddJoin(lyrPnt,"PROCID",tmpweed,"PROCID","KEEP_COMMON")
    gp.SelectLayerByAttribute(lyrPnt,"#","%s.WEEDCODE = 'KEEP'" % tmpweed)
    gp.CalculateField(lyrPnt,"PROCPASS",str(k))
    gp.CalculateField(lyrPnt,"%s.PROCGRP" % tmpPoints,
                      "[%s.GRP] + %s + 1" % (tmpweed,numGroups))

    # count groups
    gp.Statistics(lyrPnt,"xxgroups",\
                  "distPoints.PROCID COUNT","distPoints.PROCGRP")
    numGroup = CountRows("xxgroups")
    numGroups += numGroup

    # get set for next pass
    gp.MakeFeatureLayer(tmpPoints,lyrPnt, "PROCGRP < 0")
    numLeft = CountRows(lyrPnt) # how many left?
    numProc = lastLeft - numLeft
    MeanGroupSize = round(numProc / float(numGroup),2)
    GPMsg("t","Pass %s:  %s pts in %s groups (%s pts/grp); %s remaining..." %\
          (k,numProc,numGroup,MeanGroupSize,numLeft))

    if MeanGroupSize < MGSThresh:
      GPMsg("Mean Group Size less than %.2f.\n" % MGSThresh + \
            "Remainder will be tagged as individual groups, with PROCPASS = 0")
      numLeft = 0
    lastLeft = numLeft # to check next loop

    k += 1

  gp.Delete(tmpgrp)
  gp.Delete(tmpweed)
  gp.MakeFeatureLayer(tmpPoints,lyrPnt)

  # tag remainder points as PROCPASS (pass) 0
  # and PROCGRP = (PROCID + 1) * -1 (unique groups)
  gp.SelectLayerByAttribute(lyrPnt,"#","PROCGRP < 0")
  gp.CalculateField(lyrPnt,"PROCPASS","0")
  gp.CalculateField(lyrPnt,"PROCGRP","([PROCID] + 1) * -1")
  gp.SelectLayerByAttribute(lyrPnt,"CLEAR_SELECTION")

  # retag all groups with unique, sequential PROCGRP numbers
  GPMsg("t","Creating unique, sequential group IDs:")
  gp.MakeFeatureLayer(tmpPoints,lyrPnt) # refresh layer
  tmp1 = os.path.join(memWS,"tmpGrp")
  tmp1Name = "tmpGrp"
  OIDField = gp.ListFields(lyrPnt,"#","OID")[0].Name
  gp.Statistics_analysis(lyrPnt,tmp1,"%s COUNT" % OIDField,"PROCGRP")
  gp.AddJoin(lyrPnt,"PROCGRP",tmp1,"PROCGRP")
  gp.CalculateField(lyrPnt,"PROCGRPC","[%s.FREQUENCY]" % tmp1Name)
  gp.CalculateField(lyrPnt,"PROCGRP","[%s.%s]" % (tmp1Name,OIDField))
  gp.RemoveJoin(lyrPnt,tmp1Name)

  # copy points
  gp.CopyFeatures(tmpPoints,outputPoints)
  GPMsg("t","Points copied to output %s" % outputPoints)

  # clean up
  gp.Delete(lyrPnt)
  gp.Delete(tmpFGDB)


except MsgError, xmsg:
  GPMsg("Error",str(xmsg))
except GPError:
  line, file, err = nact.TraceInfo()
  GPMsg("Error",str(gp.GetMessages(0)))
except:
  line, file, err = nact.TraceInfo()
  GPMsg("Error","Python error on %s of %s" % (line,file))
  GPMsg("Error",err)
finally:
  try:
    # delete cursors if open
    try:
      del Row, Rows
    except:
      pass
    # delete layers and datasets
    for f in [lyrPnt,lyrWeed,tmpFGDB]:
      if f: gp.Delete(f)
  except Exception, xmsg:
    pass


