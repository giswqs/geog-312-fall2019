"""
ArcGIS Script Tool - Footprint Areas
"""
# Import system modules
import sys, string, os

# enable garbage collection
import gc; gc.enable()

# arcgis module
import arcgisscripting
from arcgisscripting import ExecuteError as GPError
# Create the Geoprocessor object
gp = arcgisscripting.create(9.3)

# import nact module (../../scripts)
nactPath = os.path.join(os.path.dirname(sys.argv[0]),
                        "../../scripts")
sys.path.append(os.path.normpath(nactPath))
try:
  import nact
  from nact import GPMsg, MsgError
except:
  gp.AddError("%s not found" % os.path.join(nactPath,"nact.py"))


try:

  # Environment
  gp.Toolbox = "management"
  gp.OverwriteOutput = 1
  gp.QualifiedFieldNames = False

  # Script arguments

  inLayers = gp.GetParameterAsText(0)  # input layers/datasets
  outTable = gp.GetParameterAsText(1)  # output table
  FullPathFootprint = gp.GetParameterAsText(2) == "true"

  lstFootprints = inLayers.split(";")
  numFP = len(lstFootprints)  # count them!
  if numFP == 1:
    GPMsg("w",\
      "Only one footprint data set entered -- only one row will be output.")

  # verify input footprint datasets
  FPFix = []
  for FP in lstFootprints:
    dFP = gp.Describe(FP)
    strFP = dFP.CatalogPath
    try:
      DSType = dFP.DatasetType
    except:
      raise MsgError, "%s is not a dataset" % FP
    if dFP.DatasetType.find("Raster") == -1:
      # if a coverage was entered - extract polygon feature class
      if dFP.DataType == "Coverage":
        strFP = os.path.join(dFP.CatalogPath,"polygon")
        if not gp.Exists(strFP):
          raise MsgError, "Coverage \"%s\" does not have polygon topology" % FP
        dFP = gp.Describe(strFP)
      else:
        strFP = FP
      if dFP.ShapeType != "Polygon":
        raise MsgError, "Cannot process \"%s\".\n" % dFP.CatalogPath + \
              "Only polygon feature and raster data sets are supported."
    FPFix.append(strFP)
  lstFootprints = FPFix

  # create output table
  gp.CreateTable(os.path.dirname(outTable),
                 os.path.basename(outTable))
  gp.AddField(outTable,"DATASET","TEXT","#","#","64")
  gp.AddField(outTable,"AREAFIELD","TEXT","#","#","15")
  gp.AddField(outTable,"FOOTAREA","DOUBLE")
  gp.DeleteField(outTable,"FIELD1")


  # process each footprint, one at a time
  for FP in lstFootprints:
    # Calculate string ID Field value from data set name
    dFP = gp.Describe(FP)

    ZonesAreFeatures = dFP.DataSetType.find("Raster") == -1

    # extract strIDFieldValue from input dataset path
    if not FullPathFootprint:
      strIDFieldValue = os.path.basename(dFP.CatalogPath)
      if ZonesAreFeatures:
        if gp.Describe(dFP.Catalogpath).DataType == "CoverageFeatureClass":
          # "e:\work\MyCover\polygon" -> "MyCover"
          strIDFieldValue = os.path.basename(os.path.dirname(dFP.CatalogPath))
          strIDFieldValue = os.path.splitext(strIDFieldValue)[0]
      strIDFieldWidth = "32"
    else:
      strIDFieldValue = dFP.CatalogPath
      strIDFieldWidth = "128"


    # find area field
    lstFields = dFP.Fields
    AField = None
    for F in lstFields:
      for ff in ["Shape_Area","AREA","COUNT"]:
        if str(F.Name.lower()) == ff.lower():
          AField = ff
          break

    if AField:
      # calculate sum of area
      gp.MakeTableView(FP,"lyrFP","%s > 0" % AField)
      TotArea = 0
      Rows = gp.SearchCursor("lyrFP")
      Row = Rows.Next()
      while Row:
        TotArea += float(Row.GetValue(AField))
        Row = Rows.Next()

      cellSize = None
      if AField == "COUNT":
        if ZonesAreFeatures:
          GPMsg("w","Input %s is not raster - cannot " %   dFP.Name + \
                "estimate area from COUNT")
          AField = "Count_"
          cellSize = 1
        else:
          cellSize = float(dFP.MeanCellHeight)
          AField = "CountArea"
        TotArea = TotArea * cellSize * cellSize


      if not FullPathFootprint:
        strIDFieldValue = os.path.basename(strIDFieldValue)
      GPMsg("%s,%s,%s" % (strIDFieldValue,AField,TotArea))
      Rows = gp.InsertCursor(outTable)
      Row = Rows.NewRow()
      Row.DATASET = strIDFieldValue
      Row.AREAFIELD = AField
      Row.FOOTAREA = TotArea
      Rows.InsertRow(Row)
      del Rows, Row
    else:
      GPMsg("w", "No area field available for %s" % dFP.Name)

except MsgError, xmsg:
  GPMsg("Error",str(xmsg))
except GPError:
  line, file, err = nact.TraceInfo()
  GPMsg("Error","Geoprocessing error on %s of %s:" % (line,file))
  GPMsg("Error",str(gp.GetMessages(0)))
except:
  line, file, err = nact.TraceInfo()
  GPMsg("Error","Python error on %s of %s" % (line,file))
  GPMsg("Error",err)
finally:
  try:
    gp.Workspace = CWS
    gp.ScratchWorkspace = SWS
    gp.Delete(lyrVR)
    gp.Delete(tmpWS)
  except:
    pass
