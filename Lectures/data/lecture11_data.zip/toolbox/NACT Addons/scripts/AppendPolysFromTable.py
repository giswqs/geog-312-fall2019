#
# Append feature classes listed in a table
# into a single output feature class
#
import sys
import os
import arcgisscripting
nactPath = os.path.join(os.path.dirname(sys.argv[0]),"../../scripts")
sys.path.append(os.path.normpath(nactPath))
import nact
from nact import GPMsg, MsgError

gp = arcgisscripting.create(9.3)

gp.Toolbox = "management"

try:
    inTable   = gp.GetParameterAsText(0)
    PathField = gp.GetParameterAsText(1)
    rowQuery  = gp.GetParameterAsText(2)
    outFC     = gp.GetParameterAsText(3)

    if rowQuery == "#": rowQuery = ""
    if not gp.ListFields(inTable,PathField):
        raise MsgError, "Field %s not found in %s" % (inTable, PathField)
    if not gp.Exists(outFC):
        raise MsgError, "Output feature class \"%s\" not found" % outFC
    tvCovs = "tv"
    gp.MakeTableView(inTable,tvCovs,rowQuery)
    Rows = gp.SearchCursor(tvCovs)
    lstFC = list()
    Row = Rows.Next()
    while Row:
        FCPath = Row.GetValue(PathField)
        if not gp.Exists(FCPath):
            raise MsgError, "%s \"%s\" not found" % (PathField,FCPath)
        # If the input is a coverage, add "/polygon" if not in pathname
        if gp.Describe(FCPath).DataType == "Coverage":
            if os.path.basename(FCPath) != "polygon":
                FCPath = os.path.join(FCPath,"polygon")
        lstFC.append(FCPath)
        Row = Rows.Next()
    if not lstFC: raise MsgError, "No rows selected"

    # remove any existing rows in the output feature class
    gp.MakeFeatureLayer(gp.Describe(outFC).CatalogPath,"xfc")
    gp.DeleteRows("xfc")
    gp.Delete("xfc")

    # append features to output
    strFC = ';'.join(lstFC)
    gp.Append(strFC,outFC,"NO_TEST")
    GPMsg(gp.GetMessages(0))

except Exception, xmsg:
    GPMsg("e",str(xmsg))
finally:
    try:
        del Row, Rows
    except:
        pass




