#
# Get Field Value tool
#

import arcgisscripting
import sys
gp = arcgisscripting.create(9.3)

def getFieldValue(tv,field):
    try:
        Row, Rows = None, None
        try:
            Rows = gp.SearchCursor(tv)
            Row = Rows.Next()
            if not Row:
                raise Exception, "Could not read data from %s" % tv
            Val = Row.GetValue(field)
        except Exception, xmsg:
            gp.AddError(str(xmsg))
            gp.AddError(repr(Val))
            Val = None
        finally:
            try:
                del Row, Rows
            except:
                pass
        gp.AddMessage("%s = %s" % (field,Val))
        return Val
    except:
        gp.AddError("e",str(traceback.format_exc()).strip())


if __name__ == "__main__":
    # get arguments
    tv = gp.GetParameterAsText(0)
    field = gp.GetParameterAsText(1)
    gp.SetParameterAsText(2,getFieldValue(tv,field))