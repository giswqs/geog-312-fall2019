#
# Script tool GroupNonOverlappingPolys.py
# Curtis Price cprice@usgs.gov
# 2011-09-20 Original coding
# 2012-02-29 Major re-rewrite with auto-raster-resolution
#
# Separates overlapping polygons into groups
#
# The algorithm this tool uses is to
#   a. Sort polygons by area descending
#   b. Select those not tagged in a group yet
#      Reselect for smallest polygon up to smallest x 10 in area
#   c. Convert the polygons to raster
#   d. Determine which polygons have about the same area
#      as the input. These polygons do not overlap with
#      other polygons. Tag them in with a group ID.
#   e. Repeat b-d until pctToGroup percent of the input polys
#      have been completed
#   f. Tag unique group IDs to the remaining polygons
#
import sys
import os
import traceback
import gc
gc.enable()
try:
    import arcpy
except:
    gp = arcgisscripting.create()
    gp.AddError("This script requires Arc 10.x")
    sys.exit()

from arcpy import management as DM
from arcpy import env as ENV
arcpy.CheckOutExtension("spatial")

# import nact module (../../scripts/nact.py)
nactPath = os.path.join(os.path.dirname(sys.argv[0]),
                        "../../scripts")
sys.path.append(os.path.normpath(nactPath))
import nact
from nact import GPMsg, GPMode, ScratchName

def RunTool():
    # Script arguments
    inPoly = arcpy.GetParameterAsText(0)
    outPoly = arcpy.GetParameterAsText(1)
    grpField = arcpy.GetParameterAsText(2)
    try:
        pctToGroup = float(arcpy.GetParameterAsText(3))
    except:
        pctToGroup = None
    GroupNonOverlappingPolys(inPoly,outPoly,grpField,pctToGroup)


def FieldStats(tv,field,stat):    
    tmpStat = "in_memory/xxstat"
    arcpy.Statistics_analysis(tv,tmpStat,"%s %s" % (field,stat))
    Row = arcpy.SearchCursor(tmpStat).next()
    try:
        statFieldName = "%s_%s" % (stat,field)
        minValue = Row.getValue(statFieldName)
    except:
        arcpy.AddError("Could not read field %s" % statFieldName)
    finally:
        del Row
        DM.Delete(tmpStat)
    return minValue
    
def GroupNonOverlappingPolys(inPoly,outPoly,grpField,pctToGroup=95):
    """Separate polygons into non-overlapping groups
    
        inPoly      Input polygons
        outPoly     Output polygons
        grpField    Integer grouping field (added to outPoly)
        pctToGroup  Percent to group - after this percent of polygons
                    grouped, assign remaining to their own groups
                    
    """
    ENV.overwriteOutput = True
    arcpy.gp.logHistory = False

    # temp layers and data
    lyrInput,lyrPoly,tmpPoly1,tmpPoly2,tmpPoly3,tmpPoly3x, \
            tmpRaster,tempGDB,lyrOut = [None] * 9

    try:
        arcpy.SetProgressor("","Group Polygons")
        arcpy.SetProgressorLabel("Initializing...")

        # create temporary workspace
        tempGDB = ScratchName("",".gdb","workspace")
        DM.CreateFileGDB(os.path.dirname(tempGDB),os.path.basename(tempGDB))
        GPMsg("t","Created " + tempGDB)
        ENV.workspace = tempGDB
        # set coordinate system for processing
        try:
            if ENV.outputCoordinateSystem.Name != "Unknown": pass
        except:
            ENV.outputCoordinateSystem = arcpy.Describe(inPoly).SpatialReference

        tmpPoly1, tmpPoly2, tmpPoly3, tmpPoly3x, tmpRaster = \
                "tp1", "tp2","tp3","","tras"

        # copy selected polygons
        DM.CopyFeatures(inPoly,tmpPoly1)

        # sort polygons by location (to spatially distribute)
        # and assign ones not near in the sort order to the same group
        DM.Sort(tmpPoly1,tmpPoly2,"Shape_Area DESCENDING")
        tagField = "xxtag"
        DM.AddField(tmpPoly2,tagField,"LONG")
        OIDField = arcpy.Describe(tmpPoly2).OIDFieldName
        DM.CalculateField(tmpPoly2,tagField,"[%s]" % OIDField)
        
        # initialize groups
        DM.AddField(tmpPoly2, "DIF", "DOUBLE")
        grpField = arcpy.ValidateFieldName(grpField,tempGDB)
        DM.AddField(tmpPoly2, grpField, "LONG")
        lyrPoly = "lyrPoly"
        DM.MakeFeatureLayer(tmpPoly2,lyrPoly)
        DM.CalculateField(lyrPoly,grpField,"[%s] * -1" % tagField)
        # add indexes for speed
        DM.AddIndex(lyrPoly, tagField,"idxTag","UNIQUE")
        DM.AddIndex(lyrPoly, grpField,"idxGroup","","ASCENDING")
        numLeft = int(DM.GetCount(lyrPoly).getOutput(0))
        allPolys = numLeft
        GPMsg("t","Processing %s polygons..." % allPolys)
        pStep = int(allPolys / 50. + .5) # 50 steps
        arcpy.SetProgressorLabel("Grouping...")
        groupPolys = 999
        intGroup = 1

        # select polygons, smallest up to smallest * 10
        # for efficient raster processing
        areaMin = FieldStats(lyrPoly,"Shape_Area","MIN")
        DM.SelectLayerByAttribute(lyrPoly,"",
                                  "Shape_Area < %s" % (areaMin * 10))
        
        numProc = int(DM.GetCount(lyrPoly).getOutput(0))
        while numProc:
            # if small number of features, use in_memory workspace for speed
            if numProc > 1000:
                tmpWS = ENV.workspace
            else:
                tmpWS = "in_memory"

            tmpPoly3x = os.path.join(tmpWS,tmpPoly3)
            # copy this pass's worth of polys
            DM.CopyFeatures(lyrPoly,tmpPoly3x)
            ENV.extent = tmpPoly3x
            
            # set processing cell size for this pass
            # if smallest polygon was square, its extent
            # would be 500 x 500 cells at this resolution
            # largest would be 5000 x 5000
            procCell = ( areaMin ) ** 0.5 / 500            
            GPMsg("Gridding %s polys @ cell size %.1f ..." % (numProc,procCell))
            arcpy.FeatureToRaster_conversion(tmpPoly3x,tagField,
                                             tmpRaster,procCell)
            DM.BuildRasterAttributeTable(tmpRaster)
            DM.Delete(tmpPoly3x)

            # select polygons we just rasterized,          
            # Calculate area difference (poly area - raster zone area)
            DM.SelectLayerByAttribute(lyrPoly,"","%s < 0" % grpField)              
            DM.AddJoin(lyrPoly,tagField,tmpRaster,"VALUE","KEEP_COMMON")            
            strExpr = \
              "Abs([%s.Shape_Area] - ([VAT_%s.COUNT] * (%s ^ 2)) )" \
                    % (tmpPoly2,tmpRaster,procCell)            
            DM.CalculateField(lyrPoly, "%s.DIF" % tmpPoly2, strExpr)
            DM.RemoveJoin(lyrPoly, "VAT_%s" % tmpRaster)                

            # Select polygons  with differences < threshhold
            # these are non-overlapping polygons!
            thresh = .01 # One percent
            DM.SelectLayerByAttribute(lyrPoly, "SUBSET_SELECTION", 
                                      "( DIF / Shape_Area ) < %s " % thresh)
            ##GPMsg("selected: %s" % DM.GetCount(lyrPoly).getOutput(0))
          
            # tag them with group number intGroup
            DM.CalculateField(lyrPoly, grpField, str(intGroup))

            # select yet untagged polygons
            DM.SelectLayerByAttribute(lyrPoly, "","%s < 0" % grpField)
            # count how many left (numLeftx is the new number remaining)
            numLeftx = int(DM.GetCount(lyrPoly).getOutput(0))
            # Calculate how many processed in this pass
            groupPolys = numLeft - numLeftx
            numLeft = int(numLeftx)
            if groupPolys == 0:
                # none found on this pass
                # halve cell size for next pass (to find small polys)
                procCell = procCell / 2
                GPMsg("w","No polys found, re-running at cellsize %.1f" % procCell)
            else:
                # report results
                numProc = allPolys - numLeft
                pctComplete = float(100 * numProc) / allPolys
                strMsg = "%3s polys in group %s.  %s / %s (%.1f%%) completed..." \
                       % (groupPolys,intGroup,numProc,allPolys,pctComplete)
                GPMsg("t",strMsg)
                intGroup += 1                

                # If there is only one left (or less that pctComplete percent)
                # remaining polygons to individual groups.
                # This is for efficiencies sake.
                if numLeft > 0:
                    if ( numLeft == 1 ) or ( pctComplete > pctToGroup ): 
                        GPMsg("Assigning %s features left to unique groups..."\
                              % numLeft)
                        Rows = arcpy.UpdateCursor(lyrPoly,"","","",
                                                  "Shape_Area A")
                        for Row in Rows:
                            Row.setValue(grpField,intGroup)
                            Rows.updateRow(Row)
                            intGroup += 1                        
                        numProc = 0    # We're done.
                    else:
                        # Create next processing group
                        # reselect polygons, smallest up to smallest * 10
                        # for efficient raster processing
                        areaMin = FieldStats(lyrPoly,"Shape_Area","MIN")
                        DM.SelectLayerByAttribute(lyrPoly,"SUBSET_SELECTION",
                                  "Shape_Area < %s" % (areaMin * 10))
                        numProc = int(DM.GetCount(lyrPoly).getOutput(0))

        # all done, copy out results
        intGroup -= 1
        arcpy.ClearEnvironment("Extent")
        GPMsg("t","Copying results...")
        DM.SelectLayerByAttribute(lyrPoly, "CLEAR_SELECTION")
        DM.DeleteField(lyrPoly,"%s;%s" % (tagField,"DIF"))
        DM.CopyFeatures(tmpPoly2,outPoly)
        GPMsg("%s non-overlapping polygon groups. (%s)" % \
              (intGroup,grpField))

    except arcpy.ExecuteError:
        for i in range(arcpy.GetMessageCount()):
            GPMsg("r", i)
        tb = sys.exc_info()[2]
        GPMsg("e", traceback.format_tb(tb)[0])
    except Exception, xmsg:
        GPMsg("e", str(xmsg))
        tb = sys.exc_info()[2]
        GPMsg("e", traceback.format_tb(tb)[0])
    finally:
        try:
            del Row, Rows
        except:
            pass
        for f in [lyrInput,lyrPoly,tmpPoly3x,tempGDB]:      
        ##for testing -- save output by replacing with:
        ##for f in [lyrInput,lyrPoly]:
            if f:
                try:
                    DM.Delete(f)
                except:
                    pass


if __name__ == "__main__":
    RunTool()



