"""
ArcGIS Script Tool - Weed Points

"""
# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc; gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName

# Create the Geoprocessor object
gp = nact.getGP(9.3)

def RunWeedPoints():
    """Pass arguments from script tool interface"""
    argv = tuple([gp.GetParameterAsText(i) \
                  for i in range(gp.ParameterCount)])
    WeedPoints(*argv)


def WeedPoints(inputFC,outputFC,
               nearTolerance, weightField=None,
               weedStyle="LONELY",deletePoints=False):
    """Weed Points - "thin" point features

    arguments

      inputFC - input points
      outputFC - output point dataset
      nearTolerance - select points separated by more than this distance
      weightField - optional weight field
      weedStyle - weeding algorithm:
        LONELY (low density point priority)
        POPULAR (high-density point priority)
      deletePoints - if True, weeded points are removed from output
    """
    try:

        nact.SetProduct("ArcInfo") # need ArcInfo license
        # initialize temp variables for cleanup at end
        lyrPnt,tmpPnt,tvTag,tvDist,tblDistance,\
            tblDistFrq,tblMinDist = [None] * 7

        # GP Environment
        gp.Toolbox = "management"
        gp.QualifiedFieldNames = False
        gp.OverwriteOutput = True
        gp.LogHistory = False

        # parameters
        if nearTolerance == None:
            raise MsgError, "Near tolerance is required"
        if weedStyle.find("POP") > -1: weedStyle = "POPULAR"
        weedStyle = weedStyle.upper()

        if deletePoints == "false": deletePoints = False

        # get processing coordinate system from environment
        CS = gp.OutputCoordinateSystem
        # if not set, use input dataset's coordinate system
        if not CS:
            CS = gp.Describe(inputFC).SpatialReference
            if CS.Name == "Unknown":
                GPMsg("w","ID 522 %s" % inputFC)
        # check output coordinate system - decimal degrees
        elif CS.Type == "Geographic":
            GPMsg("e","ID 981 distance") # decimal degrees inappropriate

        # workspace environment
        # save current workspaces

        tmpWS = ScratchName("xx",".gdb","workspace")
        gp.CreateFileGDB(os.path.dirname(tmpWS),
                         os.path.basename(tmpWS))
        gp.workspace = tmpWS
        gp.scratchWorkspace = tmpWS

        tmpPnt = "xxpt"
        tblDistance =  "xxdist"
        tblDistancePath = os.path.join(tmpWS,tblDistance)
        # use in_memory workspace for smaller temp files for speed
        tblDistFrq  = tmpWS + "/xxpt_distf"
        tblMinDist  = tmpWS + "/xxmindist"

        # Copy / project selected points from layer
        GPMsg("Copying features...")
        gp.CopyFeatures(inputFC,tmpPnt)

        GPMsg("Calculating point-to-point distances...")
        gp.SetProgressorLabel("Calculating point-to-point distances...")
        try:
            gp.PointDistance_analysis(tmpPnt,tmpPnt,tblDistance,nearTolerance)
        except:
            GPMsg("e", "Point-to-point calculations failed")
            raise


        # create a feature layer and count points
        lyrPnt = "lyrPnt"
        gp.MakeFeatureLayer(tmpPnt,lyrPnt)
        numPoints = nact.CountRows(lyrPnt)

        # initialize fields
        try:
            gp.AddField(lyrPnt,"WEEDCODE","TEXT","","",4)
            gp.AddField(lyrPnt,"WEEDDIST","DOUBLE")
            gp.AddField(lyrPnt,"WEEDNBR","LONG")

        except:
            GPMsg()
            pass

        # refresh with new field names
        gp.MakeFeatureLayer(tmpPnt,lyrPnt)
        gp.SelectLayerByAttribute(lyrPnt,"CLEAR_SELECTION")

        gp.workspace = tmpWS
        # select all points with neighbors
        pntFID = gp.Describe(lyrPnt).OIDFieldName
        gp.AddIndex(tblDistancePath,"INPUT_FID","idx0")
        gp.AddJoin(lyrPnt,pntFID,tblDistancePath,"INPUT_FID")

        ##GPMsg("Tagging points with no neighbors...")
        # select all points with no match in distance table
        where = "%s.INPUT_FID IS NULL" % tblDistance
        gp.SelectLayerByAttribute(lyrPnt,"NEW_SELECTION",where)
        # Count these lonely points and tag them "KEEP"
        numLoners = nact.CountRows(lyrPnt)
        ##GPMsg("numloners: %s" % numLoners)
        if numLoners > 0:
            gp.CalculateField(lyrPnt,"%s.%s" % (tmpPnt,"WEEDCODE"),'"KEEP"')
            gp.CalculateField(lyrPnt,"%s.%s" % (tmpPnt,"WEEDDIST"),"-1")
            GPMsg("%s points have no neighbors within %s" %\
                  (numLoners,nearTolerance))
        else:
            GPMsg("w", "All points have neighbors within %s" % nearTolerance)
        gp.RemoveJoin(lyrPnt,tblDistance)

        # select those that need more weeding
        gp.SelectLayerByAttribute(lyrPnt,"SWITCH_SELECTION")

        # Add neighbor count
        GPMsg("Counting neighbors...")
        fromID = "INPUT_FID"
        toID = "NEAR_FID"
        gp.Frequency(tblDistance,tblDistFrq,fromID)
        gp.DeleteField(tblDistance,"FREQUENCY")
        gp.JoinField(tblDistance,fromID,tblDistFrq,fromID,"FREQUENCY")

        # set up sort order (for priority of selection

        # A. frequency-based sort  ("LONELY" or "POPULAR")
        if weedStyle == "LONELY":
            strFreqSort = "%s A;%s A" % ("FREQUENCY",fromID)
        else:
            strFreqSort = "%s D;%s A" % ("FREQUENCY",fromID)
        # B. Add optional weighted sort (by a field value)
        if not weightField:
            strSortFields = strFreqSort
        else:
            strSortFields = "%s DESCENDING;" % weightField + strFreqSort

        # add tag field
        gp.AddField(tblDistance,"KEEPTAG","LONG")

        GPMsg("Tagging point pairs...")

        ##raise Exception, "stop"
        # tag points....
        numRows = nact.CountRows(tblDistance)
        # setup progressor bar (updates user with progress)
        gp.SetProgressor("step", "Tagging point pairs...",0,numRows)

        keep, drop = {},{}  # keep, drop point lists
        k = 0
        Rows = gp.UpdateCursor(tblDistance,"","","",strSortFields)

        Row = Rows.next()
        while Row:
            fromIDV = Row.getValue(fromID)
            toIDV = Row.getValue(toID)
            if not keep.has_key(fromIDV):
                # is this from-point in the drop list?
                if not drop.has_key(fromIDV):
                    # No -- this from-point is a keeper!
                    # Tag it in table and add to keep list
                    Row.setValue("KEEPTAG",1)
                    Rows.updateRow(Row)
                    keep[fromIDV] = True
                    # add to-point in pair to drop list
                    drop[toIDV] = True
                else:
                    # Yes -- this from-point is in the drop list
                    # do nothing
                    pass
            else:
                # This from-point is already in the keep list
                # Add the to-point in pair to the drop list
                drop[toIDV] = True

            ### debug listings
            #GPMsg("fromID: " + str(fromID))
            #GPMsg("keep: " + str(keep.keys()))
            #GPMsg("drop: " + str(drop.keys()))
            if not k % 10:
                gp.SetProgressorPosition(k)
            k += 1
            Row = Rows.next()
        del Row, Rows
        gp.ResetProgressor()
        gp.SetProgressorLabel("")

        # mark tagged points in lyrPnt
        GPMsg("Tagging kept points...")
        gp.AddIndex(tblDistance,fromID,"idx1")
        tvTag = "tvTag"
        gp.MakeTableView(tblDistance,tvTag,'\"KEEPTAG\" IS NOT NULL')
        gp.AddJoin(lyrPnt,pntFID,tvTag,fromID,"KEEP_COMMON")
        gp.CalculateField(lyrPnt,"WEEDCODE",'"KEEP"')
        gp.RemoveJoin(lyrPnt,tblDistance)
        gp.SelectLayerByAttribute(lyrPnt,"CLEAR_SELECTION")

        ##GPMsg("Populating WEEDDIST ...")
        # find nearest distance for each point
        tvDist = "tvDist"
        gp.MakeTableView(tblDistance,tvDist)
        gp.Statistics(tvDist,tblMinDist,"DISTANCE MIN",fromID)
        mdname = os.path.basename(tblMinDist)
        gp.AddIndex(tblMinDist,fromID,"idx2")
        gp.AddJoin(lyrPnt,pntFID,tblMinDist,fromID,"KEEP_COMMON")
        gp.CalculateField(lyrPnt,"WEEDDIST","[%s.MIN_DISTANCE]" % mdname)
        gp.CalculateField(lyrPnt,"WEEDNBR","[%s.FREQUENCY]" % mdname)
        gp.RemoveJoin(lyrPnt,mdname)

        # tag drop points
        ##GPMsg("Populating WEEDCODE = \"DROP\" ...")
        gp.SelectLayerByAttribute(lyrPnt,"","WEEDCODE = 'KEEP' AND WEEDDIST >= 0")
        numPick = nact.CountRows(lyrPnt)
        gp.SelectLayerByAttribute(lyrPnt,"ADD_TO_SELECTION","WEEDCODE = 'KEEP'")
        gp.SelectLayerByAttribute(lyrPnt,"SWITCH_SELECTION")
        gp.CalculateField(lyrPnt,"WEEDCODE",'"DROP"')
        numDrop = nact.CountRows(lyrPnt)
        gp.SelectLayerByAttribute(lyrPnt,"CLEAR_SELECTION")

        # copy out results
        GPMsg("Writing " + outputFC + " ...")

        if deletePoints:
            gp.SelectLayerByAttribute(lyrPnt,"","WEEDCODE = 'KEEP'")
        gp.CopyFeatures(lyrPnt,outputFC)

        # report results
        strFmt = "%8s  %4s %s"
        GPMsg("")
        GPMsg(strFmt % ("WEEDCODE","Number of points",""))
        GPMsg(strFmt % ("-"*8,"-"*50,""))
        GPMsg(strFmt % ("KEEP  ",numLoners,
                        "No neighbors within tolerance"))
        GPMsg(strFmt % ("KEEP  ",numPick,
                        "Chosen using weeding filter"))
        GPMsg(strFmt % ("DROP  ",numDrop,
                        "Flagged for deletion"))
        GPMsg("")
        numKeep = numLoners+numPick
        GPMsg("%s of %s points (%.1f%%) chosen (WEEDCODE = \"KEEP\")" % \
                 (numKeep,numPoints,100.0 * numKeep / numPoints))
        GPMsg("")

    except MsgError, xmsg:
        GPMsg("e",str(xmsg))
    except GPError:
        GPMsg("e",str(traceback.format_exc()).strip())
        numMsg = gp.MessageCount
        for i in range(0, numMsg):
            GPMsg("Return",i)
    except:
        GPMsg("e",str(traceback.format_exc()).strip())
    finally:
        try:
            del Row,Rows
        except:
            pass
        for f in [lyrPnt,tmpPnt,tvTag,tvDist,tblDistance,
                  tblDistFrq,tblMinDist,tmpWS]:
            try:
                if f: gp.Delete(f)
            except:
                pass
        if gp.Exists(tmpWS):
            GPMsg("w", "Could not delete %s" % tmpWS)

if __name__ == "__main__":
    RunWeedPoints()