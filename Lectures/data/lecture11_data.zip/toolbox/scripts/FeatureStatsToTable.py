"""
ArcGIS Script Tool - Feature Statistics To Table

"""
# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc
gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName, CountRows

# Create the Geoprocessor object
gp = nact.getGP(9.3,"spatial")


# Environment
gp.Toolbox = "management"
gp.OverwriteOutput = 1
gp.QualifiedFieldNames = False
gp.LogHistory = False

def RunTool():
  inFeatures = gp.GetParameterAsText(0)
  strIDField = gp.GetParameterAsText(1)
  valueRaster = gp.GetParameterAsText(2)
  outTable = gp.GetParameterAsText(3)
  procStats = gp.GetParameter(4)
  strBufDist = gp.GetParameterAsText(5)
  ignoreNoData = (gp.GetParameterAsText(6) in ["true","NODATA"])
  featuresOverlap = (gp.GetParameterAsText(7) in ["","true","NO_OVERLAP"])
  groupField = gp.GetParameterAsText(8)

  if not groupField:
    FeatureStatsToTable(inFeatures,strIDField,valueRaster,outTable,
                  procStats,strBufDist,ignoreNoData,featuresOverlap)
  else:
    # do multiple runs on selected non-overlapping groups of features
    gp.Toolbox = "management"
    lyrGrp = "lyrGrp"
    gp.MakeFeatureLayer(inFeatures,lyrGrp)
    # format query expression
    gFld = gp.ListFields(lyrGrp,groupField)[0]
    groupField1 = gp.AddFieldDelimiters(inFeatures,groupField)
    if gFld.Type == "String":
      queryFmt = "%s = \'%s\'" % (groupField1,"%s")
    else:
      queryFmt = "%s = %s" % (groupField1,"%s")
    # get unique values
    groups = nact.ListUnique(lyrGrp,groupField)
    k = 0
    gp.overwriteOutput = True
    CellSize = gp.cellSize
    SnapRaster = gp.snapRaster
    WSType = gp.Describe(os.path.dirname(outTable)).workspaceType
    for grp in groups:
      GPMsg("\nProcessing %s = %s" % (groupField,grp))
      queryExp = queryFmt % grp
      gp.SelectLayerByAttribute(lyrGrp,"NEW_SELECTION",queryExp)
      p = os.path.splitext(outTable)
      tmpOut = "%s%s%s" % (p[0],k,p[1])
      # use dbf if output is INFO - only way I could get it to work!
      if p[1] == "" and WSType == "FileSystem": tmpOut += ".dbf"
      try:
        FeatureStatsToTable(lyrGrp,strIDField,valueRaster,tmpOut,
                            procStats,strBufDist,ignoreNoData)
        if gp.Exists(tmpOut):
          if not gp.Exists(outTable):
            gp.CopyRows(tmpOut,outTable)
          else:
            gp.Append(tmpOut,outTable,"NO_TEST")
          gp.Delete(tmpOut)
          GPMsg("Results for %s = %s written to %s" % (groupField,grp,outTable))
        else:
          GPMsg("w","No results for %s = %s" % (groupField,grp))
      except:
        pass
      # reset environment to before next tool run
      gp.cellSize = CellSize
      gp.snapRaster = SnapRaster
      k += 1
    gp.Delete(lyrGrp)


def FeatureStatsToTable(inFeatures,strIDField,valueRaster,outTable,
         procStats,strBufDist,ignoreNoData=True,featuresOverlap=False):
  """Feature Stats To Table

  arguments

  inFeatures - input feature class or feature layer
  strIDField - group features for unique statistics
  valueRaster - raster for which to calc statistics over features
  procStats - Stats to calculate
  strBufDist - buffer distance (if required)
  ignoreNoData - ZonalStats DATA|NODATA option
  featuresOverlap - if true, process features one at a time

  """

  # initialize dataset name variables (for cleanup later)
  lyrFC, lyrProcFC,lyrVR,tmpFGDB,tmpWS, tmpZone, tmpFeat, \
    tmpTable,tmpSchema,tmpOut,tmpZStat = [None] * 11

  try:

    # inFeatures
    lyrFC = "lyrFC"
    gp.MakeFeatureLayer(inFeatures,lyrFC)
    dFC = gp.Describe(lyrFC)

    # strIDField
    if strIDField == "":
      raise MsgError, "Input_zone_field is required."
    # find datatype and length of IDField
    try:
      IDField = gp.ListFields(lyrFC,strIDField)[0]
    except:
      # this happens when a name contains a "."
      GPMsg("e","Joins are not supported in input")
      raise MsgError, "Could not identify field %s" % strIDField

    IDFieldType = IDField.Type
    IDFieldLen =  IDField.Length
    if IDField.Type == "OID":
      IDFieldIsOID = True
    else:
      IDFieldIsOID = False

    # valueRaster
    dVR = gp.Describe(valueRaster)
    VRName = os.path.basename(dVR.CatalogPath)
    lyrVR = "lyrVR"
    gp.MakeRasterLayer(valueRaster,lyrVR)

    # procStats : zonal statistics to calculate
    # this is a multi value (many stats can be calculated)
    # Feature Class or Raster Layer(s)
    lstStats = []
    # convert multi-value argument to a python list
    numStats = procStats.RowCount
    for k in range(numStats):
      lstStats.append(procStats.GetValue(k,0).upper())
    # verify arguments and figure out which fields to drop from output
    if lstStats[0] in ["","#"]: lstStats[0] = "MEAN"
    fltStats =  ["MIN","MAX","RANGE","MEAN","STD","SUM"]
    intStats = ["VARIETY","MAJORITY","MINORITY","MEDIAN"]
    lstDrop = fltStats + intStats
    for kStat in lstStats:
      # Output field names for min,max are "MIN","MAX"
      strStatField = kStat.replace("IMUM","")
      if strStatField not in intStats + fltStats:
        raise MsgError, "Invalid statistic: " + kStat
      # Check to make sure we're not asking integer stats for a float raster
      if strStatField in intStats:
        if not dVR.isInteger:
          raise MsgError, "%s is only supported for integer rasters" % strStat
      # we're using this stat; drop from "drop list"
      lstDrop.remove(strStatField)
    # convert to string for DeleteFields tool
    strDrop = ";".join(lstDrop)

    # strBufDist
    if not strBufDist:
      # Points require a buffer
      if dFC.ShapeType == "Point":
        raise MsgError, "{Buffer_Distance} is required for point features"

    # ignoreNoData (optional)
    # if any cell under features is NoData,
    # do not calculate statistics
    ignoreNoData = bool(ignoreNoData)

    # Features overlap, if true, features will be processed one at a time
    featuresOverlap = bool(featuresOverlap)

    # scratch names
    tmpWS = ScratchName("xxwk","","workspace")
    tmpFGDB = os.path.join(tmpWS,"xx.gdb")
    memWS = "in_memory"
    tmpFC = os.path.join(tmpFGDB,"workfc")
    tmpID_list = os.path.join(tmpFGDB,"IDlist")
    tmpFeat = os.path.join(tmpFGDB,"workfeat")
    tmpZone = os.path.join(tmpWS,"zonegrid")
    tmpZStat = os.path.join(tmpFGDB,"stats")
    tmpTable = ScratchName("xtab","","table",memWS)
    tmpSchema = ScratchName("xschema","","table",memWS)
    tmpOut = ScratchName("xout","","table",memWS)

    # this dictionary maps field types to AddField keywords
    typeMap = {"String":"TEXT","SmallInteger":"SHORT","Integer":"LONG",
               "Single":"FLOAT","Double":"DOUBLE"}

    # workspace environment

    # save current workspace environment
    CWS = gp.Workspace
    SWS = gp.ScratchWorkspace

    # set up scratch folder and gdb
    os.mkdir(tmpWS)
    gp.Workspace = tmpWS
    gp.ScratchWorkspace = tmpWS
    gp.CreateFileGDB(tmpWS,os.path.basename(tmpFGDB))

    # Set output coordinate system - if we can
    IRSR = dFC.SpatialReference
    VRSR = dVR.SpatialReference
    if IRSR.Name == "Unknown":
      GPMsg("w","ID 522 %s" % lyrFC)
    if VRSR.Name == "Unknown":
      GPMsg("w","ID 522 %s" % valueRaster)
    else:
      gp.OutputCoordinateSystem = VRSR

    # buffer features if necessary
    # or just make a gdb copy for speed (and in the raster coord system)

    if not strBufDist:
      # Just copy to temporary feature class
      gp.ClearEnvironment("Extent")
      gp.CopyFeatures(lyrFC,tmpFC)
    else:
      GPMsg("Calculating buffers...")
      gp.ClearEnvironment("Extent")
      gp.Buffer_analysis(lyrFC,tmpFC,strBufDist,"#","#","NONE")

    lyrProcFC = "ProcFC"
    gp.MakeFeatureLayer(tmpFC,lyrProcFC)
    dPFC = gp.Describe(lyrProcFC)

    # validate ID field name to temp dataset
    if IDFieldIsOID:
      # if the ID field was the object ID of the input, set it to that
      strIDField1 = dPFC.OIDFieldName
    else:
      # Otherwise, just validate the name (in case it isn't legal in tmpFGDB)
      strIDField1 = gp.ValidateFieldName(strIDField,tmpFGDB)

    # Raster processing environment

    try:
      # if processing cell size explicitly set in environment, use it
      ProcCell = float(gp.CellSize)
      GPMsg("w","Using environment Cell Size: %s" % ProcCell)
    except:
      # otherwise, use cell size of value raster
      ProcCell = float(dVR.MeanCellHeight)
      GPMsg("Using Cell Size of %s (%s)" % (VRName,ProcCell))
    gp.CellSize = ProcCell
    if gp.SnapRaster:
      GPMsg("w","Using environment Snap Raster: %s" % gp.SnapRaster)
    else:
      gp.SnapRaster = dVR.CatalogPath
      GPMsg("Raster snapping to %s" % VRName)

    gp.ClearEnvironment("Extent")
    gp.ClearEnvironment("OutputCoordinateSystem")

    # create unique list of IDs
    gp.Statistics_analysis(lyrProcFC,tmpID_list,\
                           "%s COUNT" % strIDField1,strIDField)
    # are they unique?
    numRows = CountRows(tmpID_list)
    numFeatures = CountRows(lyrProcFC)
    if numRows != numFeatures:
      GPMsg("Warning", \
        "%s is not unique. Combining features..." % strIDField)

    if featuresOverlap:

      if gp.GetInstallinfo("desktop")["Version"] != "10.1":
        try: # this tool is picky
          gp.AddIndex(lyrProcFC,strIDField1,"idx")
        except:
          pass

      # Set query expression format string
      if IDFieldType == "String":
        strQF = "\"%s\" = \'%s\'"
        ZoneField = strIDField1 # "ZONEFIELD" for string zone fields
      else:
        strQF = "\"%s\" = %s"
        ZoneField = "VALUE" # "VALUE" for integer zone fields

      # Create cursor to step through list of IDs
      ProcRows = gp.SearchCursor(tmpID_list)
      ProcRow = ProcRows.Next()

      # setup progressor bar (updates user with progress)

      GPMsg("Calculating zonal statistics...")

      # process rows
      kRec = 0 # first record
      FirstFeature = True

      # Process each feature, one at a time
      while ProcRow:
        try:

          # get field value and select for that input feature
          strIDFieldValue = ProcRow.GetValue(strIDField1)
          strExpr = strQF % (strIDField1,strIDFieldValue)
          gp.SelectLayerByAttribute(lyrProcFC,"NEW_SELECTION",strExpr)

          # reset environment before copying feature
          gp.ClearEnvironment("Extent")

          gp.CopyFeatures(lyrProcFC,tmpFeat)
          # get id value for this feature
          strIDFieldValue = ProcRow.GetValue(strIDField1)

          # set up raster environment

          # Extent
          gp.Extent = tmpFeat

          ResampleExtent = True
          # check extent
          try:
            nact.CheckRasterExtent(gp.Extent, dVR.MeanCellHeight, False)
          except Exception, xmsg:
            if str(xmsg).find("larger than") != -1:
              raise Exception, \
                "Value raster cell size is larger than feature extent"
          featProcCell = ProcCell

          # Coarse sampling check
          nact.CheckRasterExtent(gp.Extent, featProcCell)
          # set the extent the feature area plus 1 cell
          # to insure all area is processed
          gp.Extent = nact.GetExtent(tmpFeat,featProcCell)

          # Feature To Raster
          try:
            gp.FeatureToRaster(tmpFeat,strIDField1,tmpZone)
            gp.BuildRasterAttributeTable(tmpZone)
          except Exception:
            GPMsg("w","Feature to Raster failed.")
            raise Exception

          if IDFieldType == "String":
            ZoneID = gp.Describe(tmpZone).Fields[3].Name
          else:
            ZoneID = "VALUE"

          # calculate statistics for feature

          # Stats can fail one of two ways:
          # - no records  (grid on grid overlay)
          # - zonalstats fails (grid on other raster format - NODATA on conversion
          #     trips an error condition)
          gp.Toolbox = "sa"
          gp.ZonalStatisticsAsTable(tmpZone,ZoneID,lyrVR,
                                     tmpZStat,ignoreNoData)
          gp.Toolbox = "management"

          # did we get any records out?
          StatsOK = bool(CountRows(tmpZStat)) # zero records is false
        except Exception, xmsg:
          GPMsg("w", xmsg)
          StatsOK = False

        # Notify the user that we couldn't get stats for that feature
        if not StatsOK:
          GPMsg("w",\
            "Zonal statistics could not be computed for feature %s (%s = %s)" %\
             (kRec + 1,strIDField,strIDFieldValue))


        # done raster processing; clean up
        gp.ClearEnvironment("Extent")

        if StatsOK:
          if FirstFeature:
            # create template table (first successful time through only)

            # AREA_ID is first column, follwed by stat fields
            gp.CreateTable(memWS,os.path.basename(tmpTable))
            if IDFieldType == "String":
              gp.AddField(tmpTable,strIDField1,"TEXT","","",IDFieldLen)
              strDrop += ";%s_1" % strIDField1
            else:
              gp.AddField(tmpTable,strIDField1,"LONG")
              strDrop += (";" + ZoneID)
            gp.AddField(tmpTable,"NCELLS","LONG")

            # Create table template with this list of fields
            gp.CreateTable(os.path.dirname(tmpSchema),
                          os.path.basename(tmpSchema),
                          tmpTable + ";" + tmpZStat)
            gp.Delete(tmpTable)
            # drop fields we don't need from schema table
            try:
              gp.DeleteField(tmpSchema,
                "Field1;VALUE;ZONE_CODE;" + strDrop)
            except:
              pass

            # create temp output table
            gp.CreateTable(os.path.dirname(tmpOut),
                           os.path.basename(tmpOut), tmpSchema)

            # create output table
            gp.CreateTable(os.path.dirname(outTable),
                           os.path.basename(outTable),
                           tmpSchema)
            gp.DeleteField(outTable,"COUNT;COUNT_")

          # add the results to the output table

          gp.Append(tmpZStat,tmpOut,"NO_TEST")

          # if integer ID, populate AREAID field from VALUE field
          if IDFieldType != "String":
            gp.CalculateField(tmpOut,strIDField1,strIDFieldValue)
          ##else:
          ##  gp.CalculateField(tmpOut,strIDField1,"\"%s\"" % strIDFieldValue)

          # replace COUNT field with NCELLS
          gp.CalculateField(tmpOut,"NCELLS","[COUNT]")

          # Validate field names against output table location
          # (only need to do this the first time)
          if FirstFeature:
            lstOutFields = gp.Describe(tmpOut).Fields
            outWS = os.path.dirname(outTable)

            lstOutFieldsV = list()
            for Fld in lstOutFields:
              FieldNameV = gp.ValidateFieldName(Fld.Name,outWS)
              if Fld.Name != FieldNameV and Fld.Name <> "COUNT":
                newFldType = typeMap[Fld.Type]
                gp.AddField(tmpOut,FieldNameV,newFldType,"#","#",Fld.Length)
                lstOutFieldsV.append([FieldNameV,Fld.Name])

            FirstFeature = False # don't need to do first-row procs again

          # copy values over to fields with validated names, if any
          for fldPair in lstOutFieldsV:
            gp.CalculateField(tmpOut,fldPair[0],"[%s]" % fldPair[1])


          # append results to output table
          gp.Append(tmpOut,outTable,"NO_TEST")
          gp.DeleteRows(tmpOut) # re-use this table next loop

          strMsg = "Processed %s = \"%s\" (%s/%s)..." % \
              (strIDField,strIDFieldValue,kRec + 1,numRows)
          GPMsg(strMsg)

        # Get next feature
        ProcRow = ProcRows.Next()
        kRec += 1

    else:
      # features do not overlap, we can do it one step

      # set up raster environment

      gp.ClearEnvironment("Extent")
      gp.ClearEnvironment("Mask")

      # Extent
      gp.Extent = tmpFC
      # Is extent larger than cell size of value raster?
      # If so this generates an error
      try:
        nact.CheckRasterExtent(gp.Extent, dVR.MeanCellHeight, False)
      except Exception, xmsg:
        if str(xmsg).find("larger than") != -1:
          GPMsg("e",str(xmsg))
          raise MsgError, \
            "Value raster cell size is larger than extent of input features"
      # Is extent close to or larger than processing cell size?
      # If close, a warning is printed
      nact.CheckRasterExtent(gp.Extent, ProcCell)
      # set the extent the feature area plus 1 cell
      # to insure all area is processed
      gp.Extent = nact.GetExtent(tmpFC,ProcCell)

      gp.CellSize = ProcCell

      # Feature To Raster
      try:
        gp.FeatureToRaster(tmpFC,strIDField1,tmpZone)
        # make sure we get a raster table (needed for zonalstats)
        gp.BuildRasterAttributeTable(tmpZone)
      except Exception:
        raise MsgError, "Could not convert input features to raster"

      # calculate statistics for feature
      # Stats can fail one of two ways:
      # - no records  (grid on grid overlay)
      # - zonalstats fails (grid on other raster format - NODATA on conversion
      #     trips an error condition)
      gp.Toolbox = "sa"
      if IDFieldType == "String":
        ZoneID = gp.Describe(tmpZone).Fields[3].Name
      else:
        ZoneID = "VALUE"
      try:
        gp.ZonalStatisticsAsTable(tmpZone,ZoneID,lyrVR,
                                   tmpZStat,ignoreNoData)
      except:
        raise MsgError, "Zonal Statistics failed" + "\n" + str(gp.GetMessages(0))
      gp.Toolbox = "management"

      # did we get any records out?
      StatsOK = bool(CountRows(tmpZStat)) # zero records is false

      # Notify the user that we couldn't get stats for that feature
      if not StatsOK:
        raise MsgError, "Could not calculate zonal statistics"

      # done raster processing; clean up
      gp.ClearEnvironment("Extent")
      gp.ClearEnvironment("Mask")
      gp.Delete(tmpFC)

      # AREAID is first column, followed by stat fields
      gp.CreateTable(os.path.dirname(tmpTable),os.path.basename(tmpTable))
      tvTmp = "tvTmp"
      gp.MakeTableView(tmpTable,tvTmp)
      if IDFieldType == "String":
        gp.AddField(tvTmp,strIDField1,"TEXT","#","#",IDFieldLen)
      else:
        gp.AddField(tvTmp,strIDField1,"LONG")
      gp.AddField(tvTmp,"NCELLS","LONG")

      # Create table template with this list of fields
      gp.CreateTable(memWS,
                    os.path.basename(tmpSchema),
                    tmpTable + ";" + tmpZStat)
      gp.Delete(tmpTable)

      # drop fields we don't need from schema table
      gp.DeleteField(tmpSchema,
        "Field1;ZONE_CODE;%s" % strDrop)

      # create output table
      gp.CreateTable(os.path.dirname(outTable),
                     os.path.basename(outTable),
                     tmpSchema)
      DropFields = "COUNT;COUNT_;VALUE"
      if IDFieldType == "String":
        DropFields += ";" + gp.ListFields(outTable)[3].Name # id field dupe
      gp.DeleteField(outTable,DropFields)

      # add the results to the temp output table
      gp.CreateTable(os.path.dirname(tmpOut),
                     os.path.basename(tmpOut),
                     tmpSchema)
      gp.Append(tmpZStat,tmpOut,"NO_TEST")

      # if integer ID, populate AREAID field from VALUE field
      if IDFieldType != "String":
        gp.CalculateField(tmpOut,strIDField1,"[VALUE]")
      elif strIDField1 != ZoneID:
        gp.CalculateField(tmpOut,strIDField1,"[%s]" % ZoneID)
        gp.DeleteField(tmpOut,ZoneID)


      # replace COUNT field with NCELLS
      gp.CalculateField(tmpOut,"NCELLS","[COUNT]")

      # Validate field names against output table workspace
      lstOutFields = gp.Describe(tmpOut).Fields
      outWS = os.path.dirname(outTable)
      for Fld in lstOutFields:
        FieldNameV = gp.ValidateFieldName(Fld.Name,outWS)
        if Fld.Name != FieldNameV and Fld.Name <> "COUNT":
          GPMsg(Fld.Name + "," + FieldNameV)
          # Create validated field name and copy value over
          gp.AddField(tmpOut,FieldNameV,typeMap[Fld.Type],"#","#",Fld.Length)
          gp.CalculateField(tmpOut,FieldNameV,"[%s]" % Fld.Name)

      gp.Append(tmpOut,outTable,"NO_TEST")

  ##    # if point buffers, check for overlap
  ##    if dFC.ShapeType == "point":
  ##      tmpTable = "in_memory/xxcount_check"
  ##      gp.Statistics(tmpOut,tmpTable,"NCELLS MIN;NCELLS MAX")
  ##      Rows = gp.SearchCursor(tmpTable)
  ##      Row = Rows.Next()
  ##      minCell = float(Row.MIN_NCELLS)
  ##      maxCell = float(Row.MAX_NCELLS)
  ##      del Row, Rows
  ##      gp.Delete(tmpTable)
  ##      pctDif = 100 * ( maxCell - minCell ) / maxCell
  ##      if pctDif > 5.0:
  ##        GPMsg("w","Statistics may be invalid due to point buffer overlaps")

  except MsgError, xmsg:
    GPMsg("e",str(xmsg))
  except GPError:
    GPMsg("e",str(traceback.format_exc()).strip())
    numMsg = int(gp.MessageCount)
    for i in range(0, numMsg):
      GPMsg("Return",i)
  except:
    GPMsg("e",str(traceback.format_exc()).strip())
  finally:
    try:
      del ProcRow, ProcRows # remove cursor if we have one
    except:
      pass
    for f in [lyrFC,lyrProcFC,lyrVR,tmpTable,tmpSchema,tmpOut,tmpZStat,\
              tmpZone, tmpFeat, tmpFGDB,tmpWS]:
      try:
        if f: gp.Delete(f)
      except:
        pass
    if gp.Exists(tmpWS):
      GPMsg("w", "Could not delete %s" % tmpWS)

# script tool interface

if __name__ == "__main__":
  RunTool()

