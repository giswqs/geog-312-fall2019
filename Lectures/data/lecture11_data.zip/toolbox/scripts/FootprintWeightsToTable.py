"""
ArcGIS Script Tool - Footprint Weights To Table

"""
# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc; gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName

# Create the Geoprocessor object
gp = nact.getGP(9.3,"spatial")

def RunTool():
  # Get arguments
  numArgs = 5
  argv = [gp.GetParameter(0)] # first arg uses getParameter (list of layers)
  argv = argv + [gp.GetParameterAsText(i) for i in range(1,numArgs)]
  FootprintWeightsToTable(*argv)

def FootprintWeightsToTable(inLayers, weightRaster, outTable,
                            missingCode=9999, zoneRaster=None):

  # initialize dataset name variables
  lyrWR,lyrZR,tvRAT,tvSchema,tvWRRAT,tmpCombRaster,tmpSchema,tmpRAT,tmpOut,\
              tmpFGDB,tmpWS = [None] * 11

  try:

    nact.SetProduct("ArcInfo") # need ArcInfo license

    # Environment
    gp.Toolbox = "management"
    gp.OverwriteOutput = 1
    gp.QualifiedFieldNames = False
    gp.LogHistory = False

    # Script arguments

    # inLayers
    # Feature layers or Raster Layer(s)
    lstFootprints = []
    # convert multi-value argument to a python list
    for k in range(inLayers.RowCount):
      lstFootprints.append(inLayers.GetValue(k,0))
    numFP = len(lstFootprints)
    if numFP == 1:
      GPMsg("w","Only one footprint data set entered -- "
            "only one set of weights will be output.")
   # convert coverages to polygon feature classes
    FPFix = []
    for FP in lstFootprints:
      dFP = gp.Describe(FP)
      strFP = dFP.CatalogPath
      if dFP.DatasetType.find("Raster") == -1:
        # if a coverage was entered - extract polygon feature class path
        if dFP.DataType == "Coverage":
          strFP = os.path.join(dFP.CatalogPath,"polygon")
          if not gp.Exists(strFP):
            raise MsgError(
              "Coverage \"%s\" does not have polygon topology" % FP)
          dFP = gp.Describe(strFP)
        else:
          strFP = FP
        if dFP.ShapeType != "Polygon":
          raise MsgError, "Cannot process \"%s\".\n" % dFP.CatalogPath + \
                "Only polygon feature and raster data sets are supported."
      FPFix.append(strFP)
    lstFootprints = FPFix

    # weightRaster
    # Weight Raster (required - raster layer)
    dWR = gp.Describe(weightRaster)
    WRCell = dWR.MeanCellHeight
    WRaster = dWR.CatalogPath
    WRName = os.path.basename(dWR.CatalogPath)
    # Weight Raster rasterlayer
    lyrWR = "lyrWR"
    gp.MakeRasterLayer(WRaster,lyrWR)

    # Create weight raster table view (for weight raster calculations)
    tvWRRAT = "tvWRRAT"
    try:
      gp.MakeTableView(lyrWR,tvWRRAT)
    except:
      GPMsg("w","Building raster attributes for %s..." % WRaster)
      try:
        gp.BuildRasterAttributeTable(lyrWR)
        gp.MakeTableView(lyrWR,tvWRRAT)
      except:
        raise MsgError, "Could not build raster attribute table"

    try:
      NDCode = int(missingCode)
    except:
      NDCode = 9999

    # zoneRaster
    # Zone Raster (optional - raster layer)
    try:
      lyrZR = "lyrZR"
      gp.MakeRasterLayer(zoneRaster,lyrZR)
      dZR = gp.Describe(zoneRaster)
      ZRCell = dZR.MeanCellHeight
      ZRaster = dZR.CatalogPath
    except:
      zoneRaster = None

    # workspace environment
    CWS = gp.Workspace       # save current workspace environment
    SWS= gp.ScratchWorkspace
    # work in a folder (GRIDs are fastest)
    tmpWS = ScratchName("xxwk","","workspace")
    os.mkdir(tmpWS)
    gp.Workspace = tmpWS
    gp.ScratchWorkspace = tmpWS
    # set up a file geodatabase for features
    tmpFGDB = os.path.join(tmpWS,"work.gdb")
    gp.CreateFileGDB(tmpWS,"work.gdb")
    # use memory workspace for small temp files (fast)
    memWS = "in_memory"
    tmpFC = "work.gdb/workfc"
    tmpFPRas = os.path.join(tmpWS,"fgrid")
    tmpZoneRas = os.path.join(tmpWS,"zgrid")
    tmpCombRaster = os.path.join(tmpWS,"cmbgrid")
    tmpRAT  = os.path.join(tmpFGDB,"tblRAT")
    tvCmb = "tvCmb"
    tvRAT = "tvRAT"

    # Raster processing environment

    try:
      # if processing cell size explicitly set in environment, use it
      ProcCell = float(gp.CellSize)
      GPMsg("w","Using environment Cell Size: %s" % ProcCell)
    except:
      # otherwise, use cell size of weight  raster
      ProcCell = float(dWR.MeanCellHeight)
      GPMsg("Using Cell Size of %s (%s)" % (WRName,ProcCell))
    gp.CellSize = ProcCell
    if gp.SnapRaster:
      GPMsg("w","Using environment Snap Raster: %s" % gp.SnapRaster)
    else:
      gp.SnapRaster = dWR.CatalogPath
      GPMsg("Raster snapping to %s" % WRName)

    # coordinate system
    WRSR = dWR.SpatialReference
    if WRSR.Name == "Unknown":
      GPMsg("w","ID 522 %s" % weightRaster)
    if zoneRaster:
      ZRSR = dZR.SpatialReference
      if ZRSR.Name == "Unknown":
        GPMsg("w","ID 522 %s" % zoneRaster)
        if not nact.CompareSR(WRSR,ZRSR):
          GPMsg("w","Weight raster and zone raster "
                "coordinate systems do not match")

    PrjWarning = False

    gp.ClearEnvironment("Extent")
    gp.ClearEnvironment("Mask")

    # process footprints, one by one...

    GPMsg("Processing %s footprint(s)..." % numFP)

    kRec = 0 # first record

    for FootPrint in lstFootprints:
      try:

        dFP = gp.Describe(FootPrint)

        FP_is_features = dFP.DataSetType.find("Raster") == -1

        # extract identifying AREAID value from input footprint's name
        strFPName = os.path.basename(dFP.CatalogPath)
        if FP_is_features:
          if gp.Describe(dFP.Catalogpath).DataType == "CoverageFeatureClass":
            # "e:\work\MyCover\polygon" -> "MyCover"
            strFPName = os.path.basename(os.path.dirname(dFP.CatalogPath))
        strIDFieldValue = os.path.splitext(strFPName)[0]

        # check output coordinate system
        FPSR = dFP.SpatialReference
        if FPSR.Name == "Unknown":
          GPMsg("w","ID 522 %s" % FootPrint)

        # reset environment
        gp.ClearEnvironment("Extent")
        gp.ClearEnvironment("Mask")

        # copy / project
        if FP_is_features:
          gp.CopyFeatures(FootPrint,tmpFC) # this will project
          FPData = tmpFC
        else:
          if nact.CompareSR(FPSR,WRSR):
            FPData = dFP.CatalogPath
          else:
            # footprint and weight rasters in different projections
            # try to project the raster footprint - if we can...
            try:
              GPMsg("w","Footprint and Weight Raster projections "
                    "do not match. Projecting...")
              gp.ClearEnvironment("CellSize")
              gp.ProjectRaster(FootPrint,tmpFPRas,WRSR,"NEAREST",ProcCell)
              gp.CellSize = ProcCell
              FPData = tmpFPRas
            except Exception, xmsg:
              GPMsg("w",gp.GetMessages(2)[:-1])
              FPData = dFP.CatalogPath
        try:

          # set up raster environment

          # check extent

          # Is extent larger than cell size of value raster?
          # If so this generates an error
          gp.Extent = nact.GetExtent(FPData)
          try:
            nact.CheckRasterExtent(gp.Extent,dWR.MeanCellHeight,False)
          except Exception, msg:
            if str(msg).find("larger than extent") != -1:
              raise Exception,\
                "Value raster cell size is larger than footprint extent"
          # Is extent close to or larger than processing cell size?
          # If close, a warning is printed
          nact.CheckRasterExtent(gp.Extent,ProcCell)
          # set the extent the feature area plus 1 cell
          # to insure all area is processed
          gp.Extent = nact.GetExtent(FPData,ProcCell)

          # Mask
          if FP_is_features:
            # Feature To Raster to create mask with raster environment
            OIDField = gp.Describe(tmpFC).OIDFieldName
            gp.FeatureToRaster(tmpFC,OIDField,tmpZoneRas)
            gp.Mask = tmpZoneRas
          else:
            gp.Mask = FPData

          # create map algebra expression for combine()
          if not zoneRaster:
            # use row # for for cover raster value (ZONE)
            # replace NoData with NDCode
            PRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,kRec,kRec)
            WRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,NDCode,lyrWR)
          else:
            # use Zone Raster values for ZONE
            # Replace nodata with our NoData code
            PRExpr = "con(isnull(%s),%s,%s)" % (lyrZR,NDCode,lyrZR)
            WRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,NDCode,lyrWR)

          strExpr = "combine(%s,%s)" % (PRExpr,WRExpr)
          gp.SingleOutputMapAlgebra(strExpr,tmpCombRaster)
          gp.BuildRasterAttributeTable(tmpCombRaster) # ensure COUNT is populated
        except Exception, msg:
          raise MsgError, msg

        # done raster processing; clean up
        for f in tmpFC, tmpFPRas, tmpZoneRas:
          if gp.Exists(f): gp.Delete(f)

        gp.MakeTableView(tmpCombRaster,tvCmb)
        # find field names in the combine output table
        #  VALUE, COUNT, <AFIELD>, <WFIELD>
        CFields = gp.Describe(tvCmb).Fields
        AField = CFields[3].Name
        WField = CFields[4].Name

        # check whether there was any overlap at all
        Result = gp.GetRasterProperties(tmpCombRaster,"UNIQUEVALUECOUNT")
        CombRows = int(Result.GetOutput(0))

        if CombRows > 0:
          tmpSchema = memWS + "/xxschema"
          if not gp.Exists(tmpRAT):
            # start create a schema table in-memory (first time)
            tvSchema = "tvSchema"
            gp.CreateTable(memWS,"xxschema")
            gp.MakeTableView(tmpSchema,tvSchema)
            # add fields to output weight table template
            gp.AddField(tvSchema,"AREAID","TEXT","#","#","132")
            gp.AddField(tvSchema,"ZONE","LONG")
            gp.AddField(tvSchema,"WTZONE","LONG")
            gp.AddField(tvSchema,"NCELLS","LONG")
            gp.AddField(tvSchema,"AREA","DOUBLE")
            gp.AddField(tvSchema,"AREAF","DOUBLE")
            gp.AddField(tvSchema,"WAREA","DOUBLE")
            gp.AddField(tvSchema,"WAREAF","FLOAT")
            gp.AddField(tvSchema,"COUNT","LONG")

            gp.CreateTable(os.path.dirname(tmpRAT),
                           os.path.basename(tmpRAT),tmpSchema)
            gp.Delete(tmpSchema)

          gp.AddField(tmpRAT,AField,"LONG")
          gp.AddField(tmpRAT,WField,"LONG")

          gp.Append(tvCmb,tmpRAT,"NO_TEST")
          gp.Delete(tmpCombRaster) # clean up

          gp.MakeTableView(tmpRAT,tvRAT)

          # populate ID field
          gp.CalculateField(tvRAT,"AREAID",
                  "\"%s\"" % strIDFieldValue)
          gp.CalculateField(tvRAT,"WTZONE", "[%s]" % WField)
          gp.CalculateField(tvRAT,"ZONE", "[%s]" % AField)
          gp.CalculateField(tvRAT,"NCELLS","[%s]" % "COUNT")

          # calculate area percents for input zone (AField)
          tmpSum = ScratchName("tmpStat","","table",memWS)
          gp.Statistics_analysis(tvRAT,tmpSum,"COUNT SUM")
          # Get the sum value out of the table
          Rows = gp.SearchCursor(tmpSum)
          SumCount = float(Rows.Next().SUM_COUNT)
          del Rows
          gp.Delete(tmpSum)

          # calculate cell areas
          CellArea = float(ProcCell) ** 2
          WRCellArea = float(dWR.MeanCellHeight) ** 2
          # calculate areas
          gp.CalculateField(tvRAT,"AREA", "[COUNT] * %s" % CellArea)
          try:
            # calculate percents
            gp.CalculateField(tvRAT,"AREAF","[COUNT] / %s" % SumCount)
          except:
            GPMsg("w", "Error calculating AREAF")


          # calculate weight zone WAREA, WAREAF

          gp.AddJoin(tvRAT,WField,tvWRRAT,"VALUE")

          # determine COUNT field name
          WRName =  gp.Describe(tvWRRAT).Name
          # remove .dbf extension if there (file image formats)
          WRName = os.path.splitext(WRName)[0]
          if dWR.Format == "GRID":
            CtField = "%s.vat:COUNT" % WRName
          else:
            CtField = "%s.vat.COUNT" % WRName
          # fgdb/arcsde raster - "VAT_name.COUNT"
          if not gp.ListFields(tvRAT,CtField):
            CtField = "%s.COUNT" % WRName

          strExpr = "[%s] * %s" % (CtField ,WRCellArea)
          gp.CalculateField(tvRAT,"WAREA", strExpr)
          gp.MakeTableView(tmpRAT,tvRAT) # remove join

          # calculate percent of weight zone area
          # reselect so we don't divide by zero
          gp.SelectLayerByAttribute(tvRAT,"#","\"WAREA\" > 0")
          gp.CalculateField(tvRAT,"WAREAF","[AREA] / [WAREA]")
          gp.SelectLayerByAttribute(tvRAT,"CLEAR_SELECTION")

          # save our results
          # create output table template

          tmpOut = os.path.join(memWS,"tmpOutTable")

          if not gp.Exists(tmpOut):
            gp.CreateTable(os.path.dirname(tmpOut),
                           os.path.basename(tmpOut),tmpRAT)
            # drop the fields we don't want
            DropFields = "VALUE;COUNT;%s;%s" % (WField,AField)
            gp.DeleteField(tmpOut,DropFields)


          if not gp.Exists(outTable):
            # create output table
            gp.CreateTable(os.path.dirname(outTable),\
                           os.path.basename(outTable),tmpOut)

          # Append rows to temporary table (only the fields we need will copy)
          gp.Append(tmpRAT,tmpOut,"NO_TEST")

          # create a sorted cursor and write the data sorted
          strSort =  "AREAID;WTZONE;ZONE"
          IRows = gp.SearchCursor(tmpOut,"","","",strSort)
          ORows = gp.InsertCursor(outTable)
          IRow = IRows.next()
          while IRow:
            ORows.InsertRow(IRow)
            IRow = IRows.Next()
          del IRow,IRows,ORows


          # clean up
          gp.DeleteField(tvRAT,"%s;%s" % (AField,WField))
          gp.DeleteRows(tmpRAT)
          gp.DeleteRows(tmpOut)

          # report success
          GPMsg("t","Processed \"%s\" (%s/%s) ..." % \
                (strIDFieldValue,kRec+1,numFP))

      except Exception, msg:
        # report failure
        GPMsg("w",str(msg))
        GPMsg("w","Processing of footprint \"%s\" (%s/%s) failed" % \
              (strIDFieldValue,kRec+1,numFP))

  ##      line, file, err = nact.TraceInfo()
  ##      GPMsg("Error","Python error on %s of %s" % (line,file))
  ##      GPMsg("Error",err)

      # Get next feature...
      kRec += 1

  except MsgError, xmsg:
    GPMsg("e",str(xmsg))
  except GPError:
    GPMsg("e",str(traceback.format_exc()).strip())
    numMsg = gp.MessageCount
    for i in range(0, numMsg):
      GPMsg("Return",i)
  except:
    GPMsg("e",str(traceback.format_exc()).strip())
  finally:
    # clean up
    try:
      del Rows
    except:
      pass
    for f in [lyrWR,lyrZR, tvCmb, tvRAT, tvWRRAT, tvSchema, tvWRRAT,
              tmpCombRaster,tmpSchema,tmpRAT,tmpOut,tmpFGDB,tmpWS]:
      try:
        if f: gp.Delete(f)
      except:
        pass
    if gp.Exists(tmpWS):
          GPMsg("w", "Could not delete %s" % tmpWS)

if __name__ == "__main__":
  RunTool()


