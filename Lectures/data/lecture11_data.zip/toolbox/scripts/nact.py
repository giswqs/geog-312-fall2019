"""
USGS Computer Program nact.py:
NAWQA Area-Characterization Toolbox helper module

Modified: 1/20/2012

Use of this program is described in:

Price, C. V., Nakagaki, Naomi, and Hitt, K. J., 2010, National Water-Quality
Assessment (NAWQA) Area-Characterization Toolbox, Release 1.0:
U.S. Geological Survey Open-File Report 2010-1268. [online-only]
http://pubs.usgs.gov/of/2010/1268

Operating Environment

Python 2.5.1 / 2.6.2
ArcGIS ArcInfo Desktop 9.3, 10.0
ArcGIS Spatial Analyst extension
Microsoft Windows [Version 5.2.3790] (Windows XP Service Pack 3)

This document is program source code.

"Although this program has been used by the USGS, no warranty, expressed or
implied, is made by the USGS or the United States Government as to the
accuracy and functioning of the program and related program material nor shall
the fact of distribution constitute any such warranty, and no responsibility
is assumed by the USGS in connection therewith."

"""
import sys, os, arcgisscripting

__version__ = "NAWQA Area-Characterization Toolbox helper module, " \
           "01/20/2012"

# local version of gp
gp = None

def getGP(GPVersion="9.3",strExt=None):
  """Instantiates a geoprocessor object.

  arguments
      GPVersion - GP version, specified as a number or string
      strExt - ";" -delimited list of extensions

  examples
      gp = getGP()
      gp = getGP(9.2,"spatial;3d")
  """
  global gp
  if not gp:
    gp = arcgisscripting.create(float(GPVersion))

  if strExt:
    for ex in strExt.split(";"):
      try:
        strStatus = gp.CheckOutExtension(ex)
        if strStatus != "CheckedOut": GPMsg("w",ex)
      except Exception, xmsg:
        GPMsg("w",str(xmsg))
        pass

  return gp

def SetProduct(strProduct="ArcInfo"):
  """Run gp.SetProduct,  returning an error is not successful

  Usage example: SetProduct(gp,"ArcInfo")
  """
  Result = None
  try:
    Result = gp.SetProduct(strProduct)
    if Result not in ["CheckedOut","AlreadyInitialized"]: raise Exception
  except:
    strMsg = "%s license not available." % strProduct
    raise MsgError, strMsg
  return Result


def ScratchName(strPrefix="",strSuffix="",strDataType="",strWorkspace=""):
  """Return a scratch name with a prefix and suffix.

  This method is a wrapper of the gp.CreateScratchName
  method with a few enhancements.

  arguments

    prefix - prefix for scratch name
    suffix - suffix added to scratch name (default="")
    dataType - includes CreateScratchName options:

  notes

  1) If a workspace is not provided, the scratch workspace
  is determined by picking the first valid workspace of:
  scratch workspace, current workspace, or Windows TEMP.
  If the currently set scratch or current workspace is a
  personal or file geodatabase, and the request scratch name
  is for a file-based path (folder, grid, shapefile, etc),
  the scratchname will be generated for the folder above
  the geodatabase. ("path/xxx.gdb -> path/xxshp.shp")

  2) The scratch name returned is verified against the workspace
  to ensure that the pathname does not have a conflict, for example
  if creating a folder, it checks to ensure there is not an existing
  file with the same name. For coverages and grids, a check is made
  of the INFO directory for name conflicts.

  3) If the suffix includes an file extension, and the datatype
  supports extensions (for example, folders and coverages do not),
  the extension is returned.
    >>> gp.CreateScratchName("",".img","raster","e:/work")
    u'e:/work\\xx0'
    >>> nact.ScratchName("",".img","raster","e:/work")
    u'e:/work\\xx0.img'

  """
  import os
  global gp
  if not gp: gp = getGP()

  strDT = strDataType.lower()

  # Check out prefixes and suffixes
  if strPrefix == "": strPrefix = "x"
  pp = os.path.splitext(strPrefix)
  if pp[1] and strSuffix == "":
    # split prefix into prefix + suffix
    strPrefix = pp[0]
    strSuffix = pp[1]
  strPre = strPrefix.lower()
  strSuf = strSuffix.lower()
  # don't let it start with a number
  try:
    if strPre[0].isdigit: strPre = "x" + strPre
  except:
    pass

  # make sure our scratch workspace is a folder if required
  strDT = strDataType.lower()

  # add .dbf suffix for dbase files
  if strSuf == ".dbf": strDT = "dbase"
  if strDT == "dbase" and strSuf.find(".dbf") == -1:
    strSuf += ".dbf"

  if strDT in ["coverage","folder","shapefile","arcinfotable",
      "workspace","dbase","grid","tin"]:
    strScratchWS = ScratchWS(strWorkspace,"Folder")
    # change strDataType for gp.CreateScratchName syntax
    if strDT == "grid": strDataType = "coverage"
    elif strDT == "tin": strDataType = "folder"
  else:
    strScratchWS = ScratchWS(strWorkspace)

  # validate prefix, suffix names against workspace
  vff = strPre + strSuf
  try:
    if vff[0] == "." or vff[0].IsDigit:
      strPre = "x"
      strSuf = vff[0]
  except:
    pass

  # validate prefix
  strPre = gp.ValidateTableName(strPre,strScratchWS)
  # check suffix


  # loop until we're SURE we have an available pathname
  InfoList = None # Initialize - in case we need it (see below)
  GotValidScratchName = False    # we'll loop until this is true
  TryNum = 0 # incrementor
  while not GotValidScratchName:
    # set incremented scratch name prefix
    if TryNum == 0:
      strPre1 = strPre
    else:
      strPre1 = strPre + str(TryNum)
    # invoke gp.CreateScratchName method
    strScratchName = \
        gp.CreateScratchName(strPre1,strSuf,strDataType,strScratchWS)
    # add back extension if gp.CreateScratchName dropped it
    # and "." is allowed in name
    SplitPath = os.path.splitext(strScratchName)
    if  SplitPath[1] != strSuf and strDT not in \
        ["coverage","grid","tin","folder"]:
      strScratchName += strSuf
      SplitPath = os.path.splitext(strScratchName)
    # Is this a valid scratch name?
    GotValidScratchName = True  # innocent until proven guilty!
    # does it exist already?
    if gp.Exists(strScratchName):
      GotValidScratchName = False
    # if shapefile, does .dbf
    elif strDataType == "shapefile" or SplitPath[1] == ".shp":
      # check for .dbf named same as proposed .shp file
      if gp.Exists(SplitPath[0] + ".dbf"):
        GotValidScratchName = False
    elif strDT in ["coverage","grid","tin","folder"]:
      # validating the name
      strScratchNameRoot = os.path.basename(strScratchName)
      if strDataType == "folder":
        strScratchNameRoot = strScratchNameRoot[:12]
      gp.ValidateTableName(strScratchNameRoot,os.path.dirname(strScratchName))
      strScratchName = os.path.join(\
        os.path.dirname(strScratchName),strScratchNameRoot)
      if strDT <> "folder":
        # check for name conflicts in INFO tables "<DSName>.xxx"
        if not InfoList:
          envWS = gp.Workspace # remember workspace
          gp.Workspace = strScratchWS
          InfoList = gp.ListTables("*","ArcInfoTable")
          InfoList = [os.path.splitext(k)[0].lower() for k in InfoList]
          gp.Workspace = envWS # restore
        try:
          # if we get an error, there was a match!
          idx = InfoList.index(strScratchNameRoot.lower())
          GotValidScratchName = False
        except:
          pass

    TryNum += 1  # increment, for next time around
  return os.path.normpath(strScratchName)


def ScratchWS(strWS="",strWSType=""):
  """Validate a scratch workspace path

  arguments

  strWS (optional) - existing workspace path

  strWSType (optional)
    - "Folder" - always return a folder path
    - "Geodatabase" - always return a geodatabase
    - "in_memory" - always return the "in_memory" workspace

  notes

  The first valid path in this list is returned:
    1) strWS (if strWS is a valid path)
    2) gp.ScratchWorkspace
    3) gp.Workspace
    4) If a gdb is found (.gdb/.mdb )and strWSType == "Folder":
         folder above workpace ("xxx.gdb/..")
    5) Windows TEMP folder

  """
  global gp
  if not gp: gp = getGP()

  # parse workspace type
  strWST = strWSType.lower()
  if strWST.find("f") != -1: strWSType = "Folder"
  elif strWST.find("g") != -1: strWSType = "Geodatabase"

  # in_memory is a special case - just return it
  elif strWST.find("m") != -1 or strWS.lower() == "in_memory":
    return "in_memory"

  # find a valid scratch workspace path
  if not gp.Exists(strWS):
    strWS = gp.ScratchWorkspace
  if not gp.Exists(strWS):
    strWS = gp.Workspace
  if not gp.Exists(strWS):
    strWS = gp.GetSystemEnvironment("TEMP")
  # Check the path we have found to make sure it aggress
  # with the strWSType argument.
  WSExt = os.path.splitext(strWS)[1]
  WSExt = WSExt.replace(".","").lower() # ".gdb" -> "gdb"
  if strWSType == "Folder":
    if WSExt in ["mdb","gdb"]:
      strWS = os.path.dirname(strWS)
    if not gp.Exists(strWS):
      strWS = os.environ["TEMP"]
  elif strWSType == "Geodatabase":
    if WSExt not in ["mdb","gdb"]:
      raise Exception, "%s is not a geodatabase workspace" % strWS
  return strWS

def CountRows(tbl):
  """Counts rows in a dataset, layer or table view.
  If the input is a layer or table view, the number of
  currently selected records is returned.
  """
  global gp
  if not gp: gp = getGP()

  Result = gp.GetCount(tbl)
  return int(Result.GetOutput(0))

def GetExtent(Dataset=None,Grace=0.0):
  """Returns a geoprocessing extent (as a string)

  arguments

  Dataset (Feature layer or geodataset) -
    * If not specified, the current GP extent is used.
    * If the feature layer has an active selection,
      only those features are used to determine the extent.

  Grace (number) -
    length to expand the extent (in extent's units)

  notes

  This function will not alter the current
  extent, but you can use it do so:

  gp.Extent = nact.GetExtent("e:/work/mygrid")
  gp.Extent = nact.GetExtent("polygon layer")


  """
  global gp
  if not gp: gp = getGP()

  try:
    lstExt = None  # initialize variable
    d = gp.Describe(Dataset)  # if dataset not valid, go to except
    Ex = gp.Describe(d.CatalogPath).Extent # returns an extent object
    lstExt = [Ex.XMin, Ex.YMin, Ex.XMax,Ex.YMax]
    if d.DataType != "FeatureLayer": raise Exception # our work is done
    # if this IS a layer - make sure there is a selected set
    numSel = CountRows(Dataset)
    numRow = CountRows(d.CatalogPath)
    if numSel == numRow: raise Exception # nothing selected, our work is done
    # Okay, this is a feature layer with selected features
    # Find the extent of selected features
    Rows = gp.SearchCursor(lyrFeatures)
    Row = Rows.Next()
    Ex = Row.Shape.Extent
    lstExt = [Ex.XMin, Ex.YMin, Ex.XMax,Ex.YMax]
    Row = Rows.Next()
    while Row:
      Ex = Row.Extent
      if lstExt[0] > Ex.XMin: lstExt[0] = Ex.XMin
      if lstExt[1] > Ex.YMin: lstExt[1] = Ex.YMin
      if lstExt[2] < Ex.XMax: lstExt[2] = Ex.XMax
      if lstExt[3] < Ex.YMax: lstExt[3] = Ex.YMax
      Row = Rows.Next()
      del Row, Rows
  except Exception, xmsg:
    if lstExt == None:
      # this is not a data set - use current extent
      try:
        strExt = gp.Extent
        lstExt = [float(k) for k in strExt.split()]
      except:
        # if we couldn't parse it, the extent is something like "MINOF"
        if Grace != 0:
          # can't add a grace area to something like "MINOF", sorry
          GPMsg("w",\
                "nact.GetExtent: can't add grace area to extent \"%s" % strExt)
        return strExt
    if not gp.Exists(d.CatalogPath):
      # something unexpected went wrong
      raise Exception, xmsg

  # Add "grace area" if requested
  try:
    Grace = float(Grace)
    if Grace != 0:
      lstExt[0] -= Grace
      lstExt[1] -= Grace
      lstExt[2] += Grace
      lstExt[3] += Grace
  except:
    raise Exception, "Invalid value for Grace"
  lstExt = [str(ee) for ee in lstExt]
  strExtent = "%s %s %s %s" % tuple(lstExt)

  # round numbers ending with .0 (like Arc 9.2 gp.Extent does)
  strExtent = (strExtent + " ").replace(".0 "," ").strip()

  return strExtent

def SetSnapRaster(gp,SnapRasterDS,XReg=None,YReg=None,CellSize=None):
  """Sets the geoprocessor SnapRaster environment

  arguments

  gp - geoprocessor object

  SnapRasterDS - snap raster path (or raster layer)

  If the raster does not exist, a new one is created
  using the following parameters.

  XReg, YReg, CellSize - XY registration point and cell size

  These are ignored if SnapRasterDS exists.

  notes

  The current effective (snapped) extent is returned as a string.
  If the current extent isn't explicitly set (for example: "MAXOF",None)
  that's what is returned.

  This tool checks out a spatial analyst license
  if one is not already available.
  """

  try:
    gp.CheckOutExtension("spatial")  # need a spatial analyst license
  except:
    raise Exception, "Spatial Analyst license is not available."
  try:
    d = gp.Describe(SnapRasterDS)
    if d.DatasetType.find("Raster") == -1:
      raise Exception, "%s is not a raster data set" % RasterDataset
    SnapRasterDS = d.CatalogPath
    if XReg != None:
      GPMsg("w","Using existing Snap Raster %s" % SnapRasterDS)
  except Exception, xmsg:
    # Snap path does not exist, create one
    if XReg==None or YReg==None or CellSize==None:
      raise Exception, \
        "XReg, YReg, and CellSize must be specified to create snap raster"
    # save environment
    envWS = gp.Workspace
    envExtent = gp.Extent
    envCell = gp.CellSize
    gp.ClearEnvironment("Extent")
    gp.CellSize = CellSize
    gp.Extent = "%s %s %s %s" % \
      (XReg,YReg,XReg + CellSize * 2.1, YReg + CellSize * 2.1)
    gp.SnapRaster = None
    # Single Output Map Algebra will honor this extent always!
    gp.Workspace = os.path.dirname(SnapRasterDS)
    if not gp.Workspace: gp.Workspace = envWS
    gp.SingleOutputMapAlgebra("1.0",os.path.basename(SnapRasterDS))
    gp.Workspace = envWS
    gp.Extent = envExtent
    gp.CellSize = envCell

  # Set SnapRaster environment
  gp.SnapRaster = SnapRasterDS

  # Snap current extent to new Snap Raster
  try:
    gp.Extent = gp.Extent + " " + SnapRasterDS
  except:
    pass

  return gp.Extent

def ListUnique(inTable,Field):
  """Create a list of unique values from a table/tableview.

    inTable - Table or table view
    Field   - Field name

    """
  global gp
  if not gp: gp = getGP()

  try:
    Row = None
    Rows = gp.SearchCursor(inTable,"","",Field,Field)
    Row = Rows.Next()
    lstValues = list()
    while Row:
      lstValues.append(Row.GetValue(Field))
      Row = Rows.Next()
    # unique-ize and sort the list
    lstValues = list(set(lstValues))
    lstValues.sort()
    return lstValues
  except:
    raise
  finally:
    try:
      del Row, Rows
    except:
      pass


def CheckRasterExtent(Extent=None,ProcCell=None,Warn=True):
  """
  Check raster sampling and extent

  arguments

    Extent: Extent as string: "x1 y1 x2 y2"

    ProcCell: cell size as string:

    (These values are extracted from the current
    geoprocessor environment if not provided)

    Some messages do not raise errors but print warnings GP
    if Warn == True
  """
  global gp
  if not gp: gp = getGP()

  Message = None

  try:
    if Extent == None: Extent = gp.Extent
    Ex = [float(x) for x in Extent.split()]
    if len(Ex) != 4: raise
  except:
    raise MsgError, \
          "Invalid or non-explicit extent \"%s\"" % Extent
  try:
    if ProcCell == None: ProcCell = gp.CellSize
    ProcCell = float(ProcCell)
  except:
    raise MsgError, \
          "Invalid or non-explicit cell size \"%s\"" % ProcCell


  DX, DY = Ex[2] - Ex[0], Ex[3] - Ex[1]
  DXCell,DYCell = int(DX / ProcCell), int(DY / ProcCell)
  if DXCell == 0 or DYCell == 0:
    # Error condition: raster processing will fail
    raise MsgError, \
          "Cell size (%s) larger than extent (%s x %s)."  \
          % (ProcCell, DX, DY)

  # These are warnings - processing will not fail but results
  # may not be accurate

  # is cell size really small compared to extent -- or really large?
  maxCell = min(DX,DY) / 10.0
  if ProcCell > maxCell:
    if Warn:
      GPMsg("w", \
            "Processing window is very small (%s x %s raster cells)" \
            % (DXCell,DYCell))
    Message = "EXTENT_SMALL"
  else:
    numCells = DXCell * DYCell
    # Extent is very large (approaching 2.1G limit - about 1e8 cells)
    if numCells > 1e8:
      if Warn:
        GPMsg("w", \
              "Processing window is very large (%s x %s raster cells)" \
              % (DXCell,DYCell))
    Message = "EXTENT_LARGE"

  return Message

class GPModeThing:
  """A little Python class to keep track of print mode for GPMsg()

  See the help for GPMsg()
    """
  def __init__(self):
    self.data = "gp"  # set default: "gp"

  def __call__(self,strMode=None):
    #  "" strMode returns current value"""
    if strMode:
      # check argument to make sure it is valid
      strMode = strMode.lower()
      if strMode not in ["gp","print","both"]:
        raise MsgError, "Valid values are: \"gp\",\"print\",\"both\""
      self.data = strMode
    else:
      # if no argument provided, return current mode
      return self.data

# initialize class on import of this module
GPMode = GPModeThing()

class MsgError(Exception):
  """Exception class for reporting errors to the user

  The raise syntax:  raise "We have a problem"
  has been deprecated in Python -- making this
  simple exception class needed.

  example

    try:
      ...
      raise MsgError, "We have problem"
      ...
    except MsgError, msg:
      print str(msg)

  """
  pass

def GPMsg(sev=None,msg=None,msgType=None):
  """Send a message to the geoprocessor,"python-print", or both

  Geoprocessing messages displayed with methods like "gp.AddMessage"
  may be visible in ArcGIS or in tty python output, but when
  running the script within IDE environments like IDLE or Wing,
  invisible, or display garbled. This method allows you
  to specify to send a message to python-print, just the geoprocessor, or
  to both places. The syntax also allows for a little less typing
  than the gp messaging methods it calls.

  dependencies

  GetGP, GPModeThing

  arguments

  sev - severity code / message option

    "Message","Warning","Error","Return","Time","Gpmessages"
    (only the first letter is required)

   msg - text message to display

    A special syntax for msg is used to support gp.AddIDMessage().
    (Spaces are required between each argument!)

      ID <MessageID> {AddArgument1} {AddArgument2}

    For example, to do this:
      gp.AddIDMessage("Error", 12, outFeatureClass)
    You can use this syntax with GPMsg:
      GPMsg("Error","ID %s %s" % (12,outFeatureClass))
    If a message argument contains a space, you can use | to separate
    the second argument so it will parse correctly:
       GPMsg("Error","ID %s %s|%s" % (328,name,outFeatureClass))
    (Please only use error numbers documented in the ArcGIS help!)

   msgType - Where to send the message. If this argument is given
      the destination will stay the same until GPMode is used or
      the argument is given again.

      "gp"      Geoprocessor (default) (arcpy or 9.x gp object)
      "print"   Python print
      "both"    Both places
      "off"     Nothing prints anywhere (use with care)
      None      Use current value of GPMode()

  examples

     GPMode("print")  # change default output to python-print
     GPMsg("This is a message") # default output, print ONLY
     GPMsg("t","The time is now","gp") # output to ArcGIS ONLY
     GPMsg() # print gp.AddMessages(0) GP messages to ARCGIS only
     GPMsg("w","ID 345","both") # use gp.AddIDMessage, output to both
     GPMode("off") # no messages printed

     Output:

     This is a message
     10:40:05 The time is now
     Executing: CopyFeatures poly_inout E:\work\poly_inout_CopyFeatures.shp # 0 0 0
     Start Time: Wed Apr 07 11:11:58 2010
     Executed (CopyFeatures) successfully.
     End Time: Wed Apr 07 11:11:58 2010 (Elapsed Time: 0.00 seconds)
     WARNING 000345: Input must be a workspace
  """
  global gp
  if not gp: gp = getGP()

  import time

  # support shorthand usage: GPMsg("message") and GPMsg()
  if sev != None and msg == None:
    # GPMsg("message") ->  GPMsg("","message")
    sev,msg = None,sev
  elif sev == None and msg == None:
    # GPMsg() -> GPMsg("Message",gp.GetMessages(0))
    sev,msg  = "g",None

  if not msgType:
    msgType = GPMode()  # use current value of GPMode
  else:
    msgType = GPMode(msgType) # set GPMode (and remember for next GPMsg)

  if msgType == "off":
    # Do not print anything! (like AML "&messages &off &all")
    return

  # decode severity to a code 0 thru 5:
  # sev  isev description
  #        0  message
  # "w"    1  warning
  # "e"    2  error
  # "r"    3  returnmessage
  # "t"    4  message with clock time
  # "g"    5  return gp.GetMessages(0)
  try:

    dictSev = {"w":1, "e":2, "r":3, "t":4,"g":5 }
    try:
      sev = str(sev).lower()[:1] # "Warning" -> "w"
      isev = dictSev[sev]
    except:
      isev = 0

    # support gp.AddIDMessage
    IDMessage = False # assume this isn't an id message
    try:
      # Usage: "ID <msgID> {|} {arg1} {|} {arg2}"
      lstMsg = msg.split()
      if lstMsg[0].lower() != "id": raise
      try:
        MessageID = int(lstMsg[1])
        if MessageID <= 0 or MessageID > 99999: raise
      except:
        GPMsg("w","GPMsg: Invalid message ID: %s" % MessageID)
        raise
      xmsg = " ".join(lstMsg[2:])
      if xmsg.find("|") > -1:
        lstMsg = xmsg.split("|")
      else:
        lstMsg = xmsg.split()

      IDMessage = True
      # capture AddArgument1, AddArgument2
      try:
        IDArg1, IDArg2 = "", ""
        IDArg1 = lstMsg[0]
        IDArg2 = lstMsg[1]
      except:
        pass
    except:
      pass

    # send our message

    if msgType.lower() in ["gp","both"]:
      # send message to geoprocessor
      if isev == 0:
        gp.AddMessage(msg)
      elif isev == 1:
        if not IDMessage:
          gp.AddWarning(msg)
        else:
          gp.AddIDMessage("Warning",MessageID,IDArg1,IDArg2)
      elif isev == 2:
        if not IDMessage:
          gp.AddError(msg)
        else:
          gp.AddIDMessage("Error",MessageID,IDArg1,IDArg2)
      elif isev == 4:
        strTime = time.strftime("%H:%M:%S ", time.localtime())
        gp.AddMessage(strTime + msg)
      elif isev == 5:
        gp.AddMessage(gp.GetMessages(0))
      elif isev == 3:
        gp.AddReturnMessage(int(msg))
    if msgType.lower() in ["print","both"]:
      # python-print messages
      SevLabel = ["","WARNING","ERROR"]
      if isev == 0:
        print msg
      elif isev in [1,2]:
        if not IDMessage:
          print "%s: %s" % (SevLabel[isev],msg)
        else:
          print "%s %06d: %s" % (SevLabel[isev],MessageID,lstMsg)
      elif isev == 3:
        print gp.GetMessage(int(msg))
      elif isev == 4:
        strTime = time.strftime("%H:%M:%S ", time.localtime())
        print strTime + msg
      elif isev == 5:
        msg = gp.GetMessages(0)
        if len(msg) > 0: print msg
  except Exception, xmsg:
    gp.AddError("GPMsg: %s" % str(xmsg))

def AddAttributeIndex(Table,Field,IndexName="idx",Unique=False,Ascending=False):
  # add an attribute index to a table, regardless of format
  gp = getGP()
  status = True
  try:
    gp.AddAttributeIndex_management(Table,Field,IndexName,Unique,Ascending)
  except:
    try:
      gp.AddAttributeIndex_management(Table,Field,Unique,Ascending)
    except:
      status = False
  return status

def CompareSR(SR1,SR2):
  """Compare the coordinate systems of two spatial reference objects,
  returning True if the CS's are the same, False if different."""
  try:
    # SpatialReference (SR) to string
    strSR1 = SR1.ExportToString()
    strSR2 = SR2.ExportToString()
    # strip out just the coordinate system part of the SR
    # (the name is not an accurate test)
    strCS1 = strSR1[strSR1.find("SPHEROID"):strSR1.find(';')]
    strCS2 = strSR2[strSR2.find("SPHEROID"):strSR2.find(';')]
    if strCS1 == strCS2: return True
    else: return False
  except:
    raise Exception, "CompareSR: Could not compare SR objects"

def TraceInfo():
  """
    Return traceback information for easy reporting.
     Modified from Dale Honeycutt's (ESRI) blog post:
     "ESRI Geoprocessing Blog: Error handling in Python script tools":
     http://tinyurl.com/dfsqzr
     Curtis Price - cprice@usgs.gov - 2009-05-06

    Here's an example of how to use it:

       except:
         line, file, err = TraceInfo()
         gp.AddError("Python error on %s of %s" % (line,sys.argv[0]))
         gp.AddError(err)

  """
  import sys, os, traceback
  try:
    # get traceback info
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]  # script name + line number
    # Get line number
    ErrLine = tbinfo.split(", ")[1]
    # Get error message
    ErrMsg = traceback.format_exc().splitlines()[-1]
  except:
    # just in case *this*  fails!
    import nact # import self to get pathname
    Here = os.path.realpath(nact.__file__)
    Msg = traceback.format_exc().splitlines()[-1]
    Msg = "TraceInfo failed\n%s\n(%s)" % (Here, Msg)
    raise Exception, Msg
  return ErrLine, sys.argv[0], ErrMsg


