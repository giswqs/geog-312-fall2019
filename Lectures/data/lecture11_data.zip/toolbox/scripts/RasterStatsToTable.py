"""
ArcGIS Script Tool - Area Statistics To Table

"""
# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc; gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName, CountRows

# Create the Geoprocessor object, with Spatial license
gp = nact.getGP(9.3,"spatial")

# Initialize tmp file names (easier cleanup at end)
tmpZones, tmpZones1, tmpZStat, tmpTable1, tmpSchemaTable, lyrAR, tmpWS \
        =  [None] * 7

try:

  # Environment
  gp.Toolbox = "management"
  gp.OverwriteOutput = 1
  gp.QualifiedFieldNames = False
  gp.LogHistory = False

  # Script arguments

  # Features to be used as source
  areaRaster = gp.GetParameterAsText(0)
  dAR = gp.Describe(areaRaster)

  # if this is a coverage input,
  # change it to a feature class instead
  dARPath = gp.Describe(dAR.CatalogPath)

  # Field to identify each feature
  strIDField = gp.GetParameterAsText(1).upper()
  if strIDField == "": strIDField = "#"

  # find datatype of IDField
  if strIDField != "#":
    # find datatype of IDField
    strOutFieldName = strIDField
    lstFields = gp.ListFields(areaRaster,strIDField)
    IDFieldType = lstFields[0].Type
    IDFieldLen = lstFields[0].Length
    IDFieldIsOID = strIDField in ['FID','OBJECTID']
  else:
    strOutFieldName = "AREAID"
    IDFieldType = "String"
    IDFieldLen = 32
    IDFieldIsOID = False

  # Output zone value (string)
  if strIDField != "#":
    strIDFieldValue = "FromTable"
  else:
    strIDFieldValue = gp.GetParameterAsText(2)
    if strIDFieldValue == "": strIDFieldValue = "#"
    if strIDFieldValue == "#":
      strIDFieldValue = os.path.basename(dAR.CatalogPath)

  # Value raster (required)
  # for zonal statistics
  valueRaster = gp.GetParameterAsText(3)
  dVR = gp.Describe(valueRaster)
  VRName = os.path.basename(dVR.CatalogPath)
  lyrVR = "lyrVR"
  gp.MakeRasterLayer(valueRaster,lyrVR)

  # output table (required)
  strOutTable = gp.GetParameterAsText(4)

  # zonal statistics to calculate
  # this is a multi value (many stats can be calculated)
  inStats = gp.GetParameter(5)
  lstStats = []
  # convert multi-value argument to a python list
  numStats = inStats.RowCount
  for k in range(numStats):
    lstStats.append(inStats.GetValue(k,0).upper())
  # verify arguments and figure out which fields to drop from output
  if lstStats[0] in ["","#"]: lstStats[0] = "MEAN"
  fltStats =  ["MIN","MAX","RANGE","MEAN","STD","SUM"]
  intStats = ["VARIETY","MAJORITY","MINORITY","MEDIAN"]
  lstDrop = fltStats + intStats
  for kStat in lstStats:
    # Output field names for min,max are "MIN","MAX"
    strStatField = kStat.replace("IMUM","")
    if strStatField not in intStats + fltStats:
      raise MsgError, "Invalid statistic: " + kStat
    # Check to make sure we're not asking integer stats for a float raster
    if strStatField in intStats:
      if not dVR.isInteger:
        raise MsgError, "%s is only supported for integer rasters" % strStat
    lstDrop.remove(strStatField) # we're using this, so drop from "drop list"
  strDrop = ";".join(lstDrop) # convert to string for DeleteFields tool

  # ignore nodata (optional)
  # "NODATA" = "false" = if any cell under features is NoData,
  # do not calculate statistics
  ignoreNoData = gp.GetParameterAsText(6) == "true"

  # workspace environment
  CWS = gp.Workspace       # save current workspace environment
  SWS = gp.ScratchWorkspace
  # work in a folder (GRIDs are fastest)
  tmpWS = ScratchName("xxwk","","workspace")
  os.mkdir(tmpWS)

  gp.Workspace = tmpWS
  gp.ScratchWorkspace = tmpWS
  # set up a file geodatabase for features
  tmpFGDB = os.path.join(tmpWS,"work.gdb")
  gp.CreateFileGDB(tmpWS,"work.gdb")
  # use memory workspace for small temp files (fast)
  memWS = "in_memory"

  # Check coordinate system
  ARSR = dAR.SpatialReference
  VRSR = dVR.SpatialReference
  if ARSR.Name == "Unknown": GPMsg("w","ID 522 %s" % areaRaster)
  if VRSR.Name == "Unknown":
    GPMsg("w","ID 522 %s" % valueRaster)
    if ARSR.Name != "Unknown":
      if not nact.CompareSR(ARSR,VRSR):
        raise MsgError, "Inputs have different coordinate systems."

  # set up processing layer
  lyrAR = "lyrAR"
  gp.MakeRasterLayer(areaRaster,lyrAR)

  # validate strIDField to temp GDB workspace
  strIDField1 = gp.ValidateFieldName(strIDField,tmpFGDB)
  strOutFieldName = gp.ValidateFieldName(strOutFieldName,tmpFGDB)

  # Raster processing environment

  try:
    # if processing cell size explicitly set in environment, use it
    ProcCell = float(gp.CellSize)
    GPMsg("w","Using environment Cell Size: %s" % ProcCell)
  except:
    # otherwise, use cell size of input raster (or value raster)
    ProcCell = dVR.MeanCellHeight
    CellRaster = valueRaster
    GPMsg("Using Cell Size of \"%s\" (%s)" % (CellRaster,ProcCell))
  gp.CellSize = ProcCell
  if gp.SnapRaster:
    GPMsg("w","Using environment Snap Raster: \"%s\"" % gp.SnapRaster)
  else:
    gp.SnapRaster = valueRaster
    GPMsg("Raster snapping to %s" % gp.SnapRaster)

  # Extent

  gp.Extent = dARPath.Extent

  # Coarse sampling check
  nact.CheckRasterExtent(gp.Extent, ProcCell)
  # set the extent the feature area plus 1 cell
  # to insure all area is processed
  gp.Extent = nact.GetExtent(dAR.CatalogPath,ProcCell)

  # create zone footprint for statistics

  areaRasterDS = lyrAR
  areaRasterField = strIDField

  gp.Toolbox = "sa"

  if strIDField == "#":
    tmpZones1 = os.path.join(tmpWS,"zonegrid")
    gp.Mask = areaRasterDS
    gp.CreateConstantRaster(tmpZones1,1)
    areaRasterDS = tmpZones1
    areaRasterField = "VALUE"

  # calculate statistics for each zone
  tmpZStat = ScratchName("","","",tmpFGDB)
  gp.Mask = areaRasterDS
  gp.ZonalStatisticsAsTable(areaRasterDS,areaRasterField,\
                            lyrVR,tmpZStat,ignoreNoData)

  gp.Toolbox = "management"

  # Set up schema (template) table
  # Area ID is first column, follwed by stat fields
  tmpTable1 = ScratchName("xx","","",memWS)
  tmpName = os.path.basename(tmpTable1)
  tmpSchemaTable = ScratchName("xxschema","","table",memWS)
  gp.CreateTable(memWS,tmpName)


  # put ID Field first (this creates a dupe field name, fix below)
  if IDFieldType == "String":
    gp.AddField(tmpTable1,strOutFieldName,"TEXT","#","#",IDFieldLen)
  else:
    gp.AddField(tmpTable1,strOutFieldName,"LONG")

  gp.AddField(tmpTable1,"NCELLS","LONG")

  # Create table template with this list of fields
  gp.CreateTable(memWS,
                os.path.basename(tmpSchemaTable),
                tmpTable1 + ";" + tmpZStat)
  # drop fields we don't need from schema table
  # dupe field name to drop
  DField = strIDField1 + "_1"
  # other drop fields are stats we didn't ask for (list created above)
  gp.DeleteField(tmpSchemaTable,"Field1;ZONE_CODE;%s;%s" % (DField,strDrop))
  gp.Delete(tmpTable1)

  # create tmp output table and write results to it
  gp.CreateTable(memWS,os.path.basename(tmpTable1),
                tmpSchemaTable)
  gp.Append(tmpZStat,tmpTable1,"NO_TEST")

  # populate AREAID field, COUNT field
  if strIDFieldValue == "FromTable":
    if IDFieldType == "String":
      IDField = strIDField1
    else:
      IDField = "VALUE"
    gp.CalculateField(tmpTable1,strOutFieldName,"[%s]" % IDField)
  else:
    gp.CalculateField(tmpTable1,strOutFieldName,"\"%s\"" % strIDFieldValue)

  gp.CalculateField(tmpTable1,"NCELLS","[COUNT]")

  # Validate field names against output table workspace
  lstOutFields = gp.Describe(tmpTable1).Fields
  outWS = os.path.dirname(strOutTable)
  typeMap = {"String":"TEXT","SmallInteger":"SHORT","Integer":"LONG",
             "Single":"FLOAT","Double":"DOUBLE"}
  for Fld in lstOutFields:
    FieldNameV = gp.ValidateFieldName(Fld.Name,outWS)
    if Fld.Name != FieldNameV and Fld.Name <> "COUNT":
      # Create validated field name and copy value over
      gp.AddField(tmpTable1,FieldNameV,typeMap[Fld.Type],"#","#",Fld.Length)
      gp.CalculateField(tmpTable1,FieldNameV,"[%s]" % Fld.Name)


  # calculate intersecting area percent
  tv = "tv"
  gp.AddField(tmpTable1,"AREAF","DOUBLE")
  gp.MakeTableView(tmpTable1,tv)
  tvAR = "tvAR"
  gp.MakeTableView(areaRasterDS,tvAR)
  gp.AddJoin(tv,strOutFieldName,tvAR,areaRasterField)
  ARName = gp.Describe(tvAR).name
  gp.CalculateField(tv,
                    "%s.%s" % (tmpName,"AREAF"),
                    "[%s.%s] / [%s:%s]" % \
                    (tmpName,"COUNT",ARName,"COUNT"))

  # create output table and write data to it
  gp.CreateTable(os.path.dirname(strOutTable),
                 os.path.basename(strOutTable),
                 tmpSchemaTable)
  gp.DeleteField(strOutTable,"COUNT")
  gp.AddField(strOutTable,"AREAF","DOUBLE")
  gp.Append(tmpTable1,strOutTable,"NO_TEST")


except MsgError, xmsg:
  GPMsg("e",str(xmsg))
except GPError:
  GPMsg("e",str(traceback.format_exc()).strip())
  numMsg = gp.MessageCount
  for i in range(0, numMsg):
    GPMsg("Return",i)
except:
  GPMsg("e",str(traceback.format_exc()).strip())
finally:
  for f in [lyrAR, lyrVR, tmpZones, tmpZones1, \
            tmpZStat, tmpTable1, tmpSchemaTable, tmpWS]:
    try:
      if f: gp.Delete(f)
    except:
      pass
  if gp.Exists(tmpWS):
    GPMsg("w", "Could not delete %s" % tmpWS)