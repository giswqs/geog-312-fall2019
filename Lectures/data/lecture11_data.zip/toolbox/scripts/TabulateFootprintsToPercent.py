"""
ArcGIS Script Tool - Tabulate Footprints To Percent

"""
# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc; gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName

# tools
from FootprintWeightsToTable import  FootprintWeightsToTable
from TabulateWeightTable     import  TabulateWeightTable

gp = nact.getGP(9.3,"spatial")

def RunTool():
    # Script arguments

    # Feature layers or Raster Layer(s)
    inLayers = gp.GetParameter(0)

    # Category Raster
    catRaster = gp.GetParameterAsText(1)

    # output table
    outTable = gp.GetParameterAsText(2)

    # missing value code for nodata areas
    try:
        NDCode = int(gp.GetParameterAsText(3))
    except:
        NDCode = None

    # area scale value for total
    try:
        areaScale = float(gp.GetParameterAsText(4))
    except:
        areaScale = None

def TabulateFootprintsToPercent(inLayers,catRaster,outTable,
                                NDCode=9999,areaScale=1.0):
    """Tabulate Features To Percent

      inLayers  - list of input layers
      catRaster - category raster
      outTable  - output table
      NDCode    - missing value code
      areaScale - scale factor
    """
    try:

        nact.SetProduct("ArcInfo") # need ArcInfo license

        tmpTable = ScratchName("","","table")

        # If output workspace is a folder, add .dbf extension
        # (INFO tables are not supported if spaces in path)
        outPath = os.path.dirname(tmpTable)
        if gp.Describe(outPath).DataType == "Folder":
            tmpTable += ".dbf"

        GPMsg("Footprint Weights to Table...")

        FootprintWeightsToTable(inLayers, catRaster, tmpTable, \
                                NDCode,None)

        if gp.GetMessages(2):
            raise MsgError, "Feature Weights to Table failed"

        GPMsg("Tabulating weight table...")

        TabulateWeightTable(tmpTable,"AREAID","WTZONE","PCT_",\
                            "AREA",outTable,"PERCENT",areaScale)
        if gp.GetMessages(2):
            GPMsg("e","Tabulate Weight Table failed")
            raise GPError

    except MsgError, xmsg:
        GPMsg("e",str(xmsg))
    except GPError:
        GPMsg("e",str(traceback.format_exc()).strip())
        numMsg = gp.MessageCount
        for i in range(0, numMsg):
            GPMsg("Return",i)
    except:
        GPMsg("e",str(traceback.format_exc()).strip())
    finally:
        try:
            gp.Delete(tmpTable)
        except:
            pass

if __name__ == "__main__":
    RunTool()