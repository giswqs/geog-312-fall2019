"""
ArcGIS Script Tool - Shrink Polygon Area
"""
# ---------------------------------------------------------------------------
# Shrink.py
#
# NAWQA Area-Characterization Toolbox
#
# This is a ArcGIS/Python implementation of SHRINK.AML, described in:
#
# Squillace, P.J., and Price, C.V., 1996, Urban land-use study plan for NAWQA,
# U.S.Geological Survey Open-File Report 96-217, 19 p. (Appendix B, SHRINK.AML)
#
# ---------------------------------------------------------------------------

# Import system modules
import sys
import os
import traceback

from arcgisscripting import ExecuteError as GPError

import nact
from nact import GPMsg, MsgError, ScratchName
gp = nact.getGP()

# temp variables
lyrSum,lyrPct,tmpWS = [None] * 3

try:

  # Script arguments...

  # input feature class
  Target_Polygon_Area = gp.GetParameterAsText(0)

  # Output polygon feature class
  outPolys = gp.GetParameterAsText(1)

  strBuf = gp.GetParameterAsText(2)
  fltBuf = float(strBuf.split()[0])

  # Percent inside to select (default = 75)
  strPctInside = gp.GetParameterAsText(3)
  try:
    PctInside = float(strPctInside)
    if PctInside < 1 or PctInside > 100:
      raise MsgError, "Percent_inside must be between 1 and 100"
  except:
    PctInside = 75.0

  # "Shrink" distance (distance from edge of study area)
  Shrink_Distance = gp.GetParameterAsText(4)
  SD = Shrink_Distance.split()
  fltShrinkDist = float(SD[0])
  strShrinkUnits = " ".join(SD[1:])

  # Processing cell size
  try:
    CellSize = float(gp.GetParameterAsText(5))
  except:
    try:
      Cellsize = float(gp.Cellsize)
      GPMsg("w","Using environment cell size %s" % Cellsize)
    except:
      CellSize = fltBuf / 25.0
      GPMsg("w","Calculating cell size (Buffer radius / 25) = %s" % CellSize)

  # Set up environment
  gp.CheckOutExtension("spatial")
  gp.OverwriteOutput = 1
  gp.CellSize = CellSize

  gp.Toolbox = "management"

  # temp feature and raster names
  tmpFC = "tmpFC.shp"
  tmpOneRaster = "onegrid"
  tmpSumRaster = "sumgrid"
  tmpPctRaster = "pctgrid"
  tmpShrinkRaster = "shrinkgrid"

  # workspace environment
  CWS = gp.Workspace       # save current workspace environment
  SWS = gp.ScratchWorkspace

  # work in a folder (GRIDs are fastest)
  tmpWS = ScratchName("xxwk","","workspace")
  os.mkdir(tmpWS)

  gp.Workspace = tmpWS
  gp.ScratchWorkspace = tmpWS

  # first create mask area (select/project)
  gp.CopyFeatures(Target_Polygon_Area,tmpFC)

  # set processing extent to input polygons + 1/2 buffer radius
  gp.Extent = nact.GetExtent(tmpFC,fltBuf * 0.5)

  # Check extent for problems
  Ext = [float(x) for x in gp.Extent.split()]
  WinX = Ext[2] - Ext[0]
  WinY = Ext[3] - Ext[1]
  ExtDiag = ( WinX ** 2 + WinY ** 2 ) ** 0.5
  if fltBuf > ExtDiag / 2.0:
    raise MsgError, "Buffer size too large for extent of input features"
  WinCells = WinX * WinY / CellSize ** 2
  if WinCells > 1e7:
    GPMsg("w","Processing more than 10 million grid cells (%i)...\n" +
          "this could take a while..." %  WinCells)

  # total up "inside cells"
  gp.Mask = tmpFC
  gp.SingleOutputMapAlgebra("1",tmpOneRaster)
  gp.ClearEnvironment("Mask")

  strNbr = "CIRCLE %s MAP" % fltBuf
  GPMsg("Counting neighborhood cells...")
  gp.FocalStatistics(tmpOneRaster,tmpSumRaster, strNbr, "SUM", True)
  # calculate number of cells in a circular buffer
  pi = 3.1415926535897931
  BufCells = pi * ( fltBuf ** 2 ) / ( CellSize ** 2 )

  # create map algebra expression to calculate percent inside
  # int ( 100 * data cells in buffer / total cells in buffer)
  lyrSum = "lyrSum"
  gp.MakeRasterLayer(tmpSumRaster,lyrSum)
  strExpr = "int(100 *  %s / %s)" % (lyrSum,BufCells)
  GPMsg("Converting cell counts to percent inside area...")
  gp.SingleOutputmapAlgebra(strExpr,tmpPctRaster)
  gp.Delete(lyrSum)

  # Set areas with less than X percent in buffer to NODATA
  lyrPct = "lyrPct"
  gp.MakeRasterLayer(tmpPctRaster,lyrPct)
  strExpr = "setnull(%s le %s,1)" % (lyrPct,PctInside)
  gp.SingleOutputmapAlgebra(strExpr,tmpShrinkRaster )
  gp.Delete(lyrPct)

  GPMsg("Raster to polygon...")
  tmpPoly = os.path.join(tmpWS,"shrinkpoly.shp")
  try:
    gp.RasterToPolygon_conversion(tmpShrinkRaster, tmpPoly)
  except:
    raise MsgError, "Could not define shrink area using these parameters"
  GPMsg(gp.GetMessages(0))
  # Run "Shrink" around edges using Shrink_Distance
  if fltShrinkDist > 0:
    strBufDist = "%s %s" % \
      ( fltShrinkDist * -1.0, strShrinkUnits)
    GPMsg("Shrinking by %s..." % Shrink_Distance)
    gp.Buffer_analysis(tmpPoly, outPolys, strBufDist)
  else:
    gp.CopyFeatures(tmpPoly,outPolys)

except MsgError, xmsg:
  GPMsg("e",str(xmsg))
except GPError:
  GPMsg("e",str(traceback.format_exc()).strip())
  numMsg = gp.MessageCount
  for i in range(0, numMsg):
    GPMsg("Return",i)
except:
  GPMsg("e",str(traceback.format_exc()).strip())
finally:
  for f in [lyrSum,lyrPct,tmpWS]:
    try:
      if f: gp.Delete(f)
    except:
      pass
  if gp.Exists(tmpWS):
    GPMsg("w", "Could not delete %s" % tmpWS)
