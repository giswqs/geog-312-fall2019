"""
ArcGIS Script Tool - Feature Weights To Table

"""
# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc
gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName, CountRows

# Create the Geoprocessor object
gp = nact.getGP(9.3,"spatial")

def runTool():
  # Get arguments
  inFeatures   = gp.GetParameterAsText(0)
  strIDField   = gp.GetParameterAsText(1)
  weightRaster = gp.GetParameterAsText(2)
  outTable     = gp.GetParameterAsText(3)
  bufDist      = gp.GetParameterAsText(4)
  missingCode  = gp.GetParameterAsText(5)
  zoneRaster   = gp.GetParameterAsText(6)
  featuresOverlap = (gp.GetParameterAsText(7) == "true")
  groupField   = gp.GetParameterAsText(8)

  if not groupField:
    FeatureWeightsToTable(inFeatures, strIDField, weightRaster, outTable,
         bufDist, missingCode, zoneRaster,featuresOverlap)
  else:
    # do multiple runs on selected non-overlapping groups of features
    gp.Toolbox = "management"
    lyrGrp = "lyrGrp"
    gp.MakeFeatureLayer(inFeatures,lyrGrp)
    # format query expression
    gFld = gp.ListFields(lyrGrp,groupField)[0]
    groupField1 = gp.AddFieldDelimiters(inFeatures,groupField)
    if gFld.Type == "String":
      queryFmt = "%s = \'%s\'" % (groupField1,"%s")
    else:
      queryFmt = "%s = %s" % (groupField1,"%s")
    # get unique values
    groups = nact.ListUnique(lyrGrp,groupField)
    k = 0
    gp.overwriteOutput = True
    CellSize = gp.cellSize
    SnapRaster = gp.snapRaster
    WSType = gp.Describe(os.path.dirname(outTable)).workspaceType
    for grp in groups:
      GPMsg("\nProcessing %s = %s" % (groupField,grp))
      queryExp = queryFmt % grp
      gp.SelectLayerByAttribute(lyrGrp,"NEW_SELECTION",queryExp)
      p = os.path.splitext(outTable)
      tmpOut = "%s%s%s" % (p[0],k,p[1])
      # use dbf if output is INFO - only way I could get it to work!
      if p[1] == "" and WSType == "FileSystem": tmpOut += ".dbf"
      try:
        FeatureWeightsToTable(lyrGrp, strIDField, weightRaster, tmpOut,
                              bufDist, missingCode, zoneRaster,featuresOverlap)
        if gp.Exists(tmpOut):
          if not gp.Exists(outTable):
            gp.CopyRows(tmpOut,outTable)
          else:
            gp.Append(tmpOut,outTable,"NO_TEST")
          gp.Delete(tmpOut)
        else:
          GPMsg("w","No results for %s = %s" % (groupField,grp))
      except:
        pass
      GPMsg("Results for %s = %s written to %s" % (groupField,grp,outTable))
      # reset environment to before next tool run
      gp.cellSize = CellSize
      gp.snapRaster = SnapRaster
      k += 1
    gp.Delete(lyrGrp)


def FeatureWeightsToTable(inFeatures, strIDField, weightRaster, outTable,
         bufDist=None, missingCode=None, zoneRaster=None,
         featuresOverlap=False):
  """Feature Weights To Table

    arguments

      inFeatures
      strIDField
      weightRaster
      outTable
      bufDist
      missingCode
      zoneRaster
      featuresOverlap

  """
  # temp dataset names (for cleanup at the end)
  lyrProcFC, lyrWR, lyrFR, tmpFC,     \
    tvWRRAT, tvCmb, tvSchema, tvRAT,  \
    tmpRAT, tmpFeat, tmpFeatRaster,   \
    tmpSchema, tmpSum, tmpOut, tmpFGDB, tmpWS = [None] * 16


  try:

    nact.SetProduct("ArcInfo") # need ArcInfo license

    # Environment
    gp.Toolbox = "management"
    gp.OverwriteOutput = 1
    gp.QualifiedFieldNames = False
    gp.LogHistory = False

    # Script arguments

    # Feature Class to use as source
    # can be a layer or dataset
    # each feature will be processed one at a time
    dInputFC = gp.Describe(inFeatures)

    # find datatype and length of IDField
    try:
      IDField = gp.ListFields(inFeatures,strIDField)[0]
      if IDField.Name.find(".") >= 0: raise
    except:
      GPMsg("e","Joins are not supported in input")
      raise MsgError, "ID Field %s invalid" % strIDField
    IDFieldType = IDField.Type
    IDFieldLen =  IDField.Length

    # Weight Raster (required - raster layer)
    dWR = gp.Describe(weightRaster)
    WRCell = dWR.MeanCellHeight
    WRaster = dWR.CatalogPath
    WRName = os.path.basename(dWR.CatalogPath)
    # Weight Raster rasterlayer
    lyrWR = "lyrWR"
    gp.MakeRasterLayer(WRaster,lyrWR)

    # Create weight raster table view (for weight raster calculations)
    tvWRRAT = "tvWRRAT"
    try:
      gp.MakeTableView(lyrWR,tvWRRAT)
    except:
      GPMsg("w","Building raster attributes for %s..." % WRaster)
      try:
        gp.BuildRasterAttributeTable(lyrWR)
        gp.MakeTableView(lyrWR,tvWRRAT)
      except:
        raise MsgError, "Could not build raster attribute table"

    # missing value code for nodata areas
    try:
      NDCode = int(missingCode)
    except:
      NDCode = 9999

    # Zone Raster (optional - raster layer)
    if zoneRaster:
      try:
        lyrZR = "lyrZR"
        gp.MakeRasterLayer(zoneRaster,lyrZR)
        dZR = gp.Describe(zoneRaster)
        ZRCell = dZR.MeanCellHeight
        ZRaster = dZR.CatalogPath
      except:
        zoneRaster = None

    featuresOverlap = bool(str(featuresOverlap).lower() in ["true","overlap"])

    # temp file names
    tmpWS = ScratchName("xxwk","","workspace")
    tmpFGDB = os.path.join(tmpWS,"work.gdb")
    memWS = "in_memory"
    tmpID_list = os.path.join(tmpFGDB,"tblID_list")
    tmpFC = os.path.join(tmpFGDB,"tempfc")
    tmpFeat = os.path.join(tmpFGDB,"tempfeat")
    tmpFeatRaster = os.path.join(tmpWS,"featgrid")
    tmpCombRaster = os.path.join(tmpWS,"combgrid")
    tmpRAT  = os.path.join(tmpFGDB,"tblRAT")
    tmpSum  = os.path.join(memWS,"tblSum")
    tmpOut  = os.path.join(memWS,"tblOut")
    tvRAT = "tvRAT"

    # workspace environment
    CWS = gp.Workspace       # save current workspace environment
    SWS= gp.ScratchWorkspace
    # work in a folder (GRIDs are fastest)
    os.mkdir(tmpWS)

    gp.Workspace = tmpWS
    gp.ScratchWorkspace = tmpWS
    # set up a file geodatabase for features
    gp.CreateFileGDB(os.path.dirname(tmpFGDB),os.path.basename(tmpFGDB))

    # coordinate system - if we can
    IRSR = dInputFC.SpatialReference
    WRSR = dWR.SpatialReference
    if IRSR.Name == "Unknown":
      GPMsg("w","ID 522 %s" % inFeatures)
    if WRSR.Name == "Unknown":
      GPMsg("w","ID 522 %s" % weightRaster)
    else:
      gp.OutputCoordinateSystem = WRSR
    if zoneRaster:
      ZRSR = dZR.SpatialReference
      if ZRSR.Name == "Unknown":
        GPMsg("w","ID 522 %s" % zoneRaster)
      else:
        if not nact.CompareSR(WRSR,ZRSR):
          GPMsg("w","The Weight and Zone raster "
                "spatial references do not match.")


    # Raster processing environment

    try:
      # if processing cell size explicitly set in environment, use it
      ProcCell = float(gp.CellSize)
      GPMsg("w","Using environment Cell Size: %s" % ProcCell)
    except:
      # otherwise, use cell size of weight  raster
      ProcCell = float(dWR.MeanCellHeight)
      GPMsg("Using Cell Size of %s (%s)" % (WRName,ProcCell))
    gp.CellSize = ProcCell
    if gp.SnapRaster:
      GPMsg("w","Using environment Snap Raster: %s" % gp.SnapRaster)
    else:
      gp.SnapRaster = dWR.CatalogPath
      GPMsg("Raster snapping to %s" % WRName)

    gp.ClearEnvironment("Extent")
    gp.ClearEnvironment("Mask")

    # Buffer features (if specified), otherwise copy
    if not bufDist:
      if dInputFC.ShapeType == "Point":
        raise MsgError,"{Buffer_distance} is required for point features"
      gp.CopyFeatures(inFeatures,tmpFC)
    else:
      # buffer without dissolve
      GPMsg("Calculating buffers...")
      gp.Buffer_analysis(inFeatures,tmpFC,bufDist,"#","#","NONE")
      GPMsg("Buffer completed.")

    gp.ClearEnvironment("OutputCoordinateSystem") # not needed anymore

    lyrProcFC = "ProcFC"
    gp.MakeFeatureLayer(tmpFC,lyrProcFC)
    dFC = gp.Describe(lyrProcFC)

    # validate ID field name (ID field name in temporary feature dataset)
    if IDFieldType == "OID":
      strIDField1 = gp.Describe(lyrProcFC).OIDFieldName
    else:
      strIDField1 = gp.ValidateFieldName(strIDField,tmpFGDB)


    if featuresOverlap:

##      if gp.GetInstallinfo("desktop")["Version"] != "10.1":
##        try: # this tool is picky
##          gp.AddIndex(lyrProcFC,strIDField1,"idx")
##        except:
##          pass

      gp.Frequency_analysis(lyrProcFC,tmpID_list,strIDField1)

      # Count results
      numRows=  CountRows(tmpID_list)
      numFeatures = CountRows(lyrProcFC)

      if numRows != numFeatures:
        GPMsg("w", "%s is not unique. Combining features..." % strIDField)


##      # add index for speed
##      if gp.GetInstallinfo("desktop")["Version"] != "10.1":
##        try: # this tool is picky
##          gp.AddIndex(lyrProcFC,strIDField1,"idx")
##        except:
##          pass

      # Create cursor to step through list of IDs
      ProcRows = gp.SearchCursor(tmpID_list)
      ProcRow = ProcRows.Next()

      # Set query expression format string
      if IDFieldType == "String": strQF = "\"%s\" = \'%s\'"
      else: strQF = "\"%s\" = %s"

      tmpSchema = memWS + "/xxschema"

      kRec = 1 # first record
      while ProcRow:
        # get id value for this feature (as a string)
        strIDValue = str(ProcRow.GetValue(strIDField1))

        try:
          # select one feature and copy it to a temp FC
          strExpr = strQF % (strIDField1,ProcRow.GetValue(strIDField1))
          gp.SelectLayerByAttribute(lyrProcFC,"NEW_SELECTION",strExpr)
          gp.CopyFeatures(lyrProcFC,tmpFeat)

          # set up raster environment

          # Extent
          gp.Extent = tmpFeat

          # check extent
          try:
            nact.CheckRasterExtent(gp.Extent, dWR.MeanCellHeight,False)
          except Exception, xmsg:
            raise Exception, str(xmsg)

          # Coarse sampling check
          nact.CheckRasterExtent(gp.Extent, ProcCell)
          # set the extent the feature area plus 1 cell
          # to insure all area is processed
          gp.Extent = nact.GetExtent(tmpFeat,ProcCell)

          # Feature To Raster to create raster mask
          # We do this because setting the mask to
          # a feature is not consistent w/ feature to raster
          OIDField = gp.Describe(tmpFeat).OIDFieldName
          try:
            gp.FeatureToRaster(tmpFeat,OIDField,tmpFeatRaster)
          except Exception:
            GPMsg("w","Feature to Raster failed.")
            raise Exception

          gp.Extent = tmpFeatRaster
          gp.Cellsize = tmpFeatRaster
          gp.Mask = tmpFeatRaster

          # create grid expressions for combine()
          if not zoneRaster:
            # no zone raster specified
            # use row # for for cover raster value (ZONE)
            # replace NoData with NDCode
            PRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,kRec,kRec)
            WRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,NDCode,lyrWR)
          else:
            # use zoneRaster values for ZONE
            # Replace nodata with our NoData code
            PRExpr = "con(isnull(%s),%s,%s)" % (lyrZR,NDCode,lyrZR)
            WRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,NDCode,lyrWR)

          gp.SingleOutputMapAlgebra("combine(%s,%s)" % \
                                    (PRExpr,WRExpr),tmpCombRaster)
          gp.BuildRasterAttributeTable(tmpCombRaster)

        except Exception, xmsg:
          GPMsg("w", str(xmsg).strip() + "\n" +\
                "Raster processing failed for %s = %s" % \
                (strIDField,strIDValue))
          # Get next feature
          ProcRow = ProcRows.Next()
          kRec += 1
          continue

        # done raster processing; clean up
        gp.ClearEnvironment("Extent")
        gp.ClearEnvironment("Mask")
        gp.Delete(tmpFeat)
        gp.Delete(tmpFeatRaster)

        tvCmb = "tvCmb"
        gp.MakeTableview(tmpCombRaster,tvCmb)

        # find field names in the combine output table
        #  VALUE, COUNT, <AFIELD>, <WFIELD>
        CFields = gp.Describe(tvCmb).Fields
        AField = CFields[3].Name
        WField = CFields[4].Name

        # check whether there was any overlap at all
        Result = gp.GetRasterProperties(tmpCombRaster,"UNIQUEVALUECOUNT")
        CombRows = int(Result.GetOutput(0))

        # copy VAT to temp table

        tmpSchema = memWS + "/xxschema"
        if not gp.Exists(tmpRAT):
          # start create a schema table in-memory (first time)
          tvSchema = "tvSchema"
          gp.CreateTable(memWS,"xxschema")
          gp.MakeTableView(tmpSchema,tvSchema)
          # add fields to output weight table template
          if IDFieldType == "String":
            gp.AddField(tvSchema,"AREAID","TEXT","#","#",IDFieldLen)
          else:
            gp.AddField(tvSchema,"AREAID","LONG")
          gp.AddField(tvSchema,"ZONE","LONG")
          gp.AddField(tvSchema,"WTZONE","LONG")
          gp.AddField(tvSchema,"NCELLS","LONG")
          gp.AddField(tvSchema,"AREA","DOUBLE")
          gp.AddField(tvSchema,"AREAF","FLOAT")
          gp.AddField(tvSchema,"WAREA","DOUBLE")
          gp.AddField(tvSchema,"WAREAF","FLOAT")
          gp.AddField(tvSchema,"COUNT","LONG")
          gp.CreateTable(os.path.dirname(tmpRAT),
                         os.path.basename(tmpRAT),tmpSchema)
          gp.Delete(tmpSchema)

        gp.AddField(tmpRAT,AField,"LONG")
        gp.AddField(tmpRAT,WField,"LONG")
        gp.Append(tvCmb,tmpRAT,"NO_TEST")
        gp.Delete(tmpCombRaster) # clean up

        gp.MakeTableView(tmpRAT,tvRAT)

        # populate ID field
        gp.CalculateField(tvRAT,"AREAID",
                "\"%s\"" % strIDValue)
        gp.CalculateField(tvRAT,"WTZONE", "[%s]" % WField)
        gp.CalculateField(tvRAT,"ZONE", "[%s]" % AField)
        gp.CalculateField(tvRAT,"NCELLS","[%s]" % "COUNT")

        # calculate area percents for input zone (AField)
        gp.Statistics_analysis(tvRAT,tmpSum,"COUNT SUM")
        # read the sum of cells from the results
        Rows = gp.SearchCursor(tmpSum)
        SumCount = float(Rows.Next().SUM_COUNT)
        del Rows

        # calculate cell areas: AREA, AREAF
        CellArea = ProcCell ** 2
        WRCellArea = float(dWR.MeanCellHeight) ** 2
        # calculate areas
        gp.CalculateField(tvRAT,"AREA", "[COUNT] * %s" % CellArea)
        # calculate percents
        gp.CalculateField(tvRAT,"AREAF","[COUNT] / %s" % SumCount)


        # calculate weight zone WAREA, WAREAF

        gp.AddJoin(tvRAT,WField,tvWRRAT,"VALUE")

        # determine COUNT field name
        WRName =  gp.Describe(tvWRRAT).Name
        # remove .dbf extension if there (file image formats)
        WRName = os.path.splitext(WRName)[0]
        if dWR.Format == "GRID":
          CtField = "%s.vat:COUNT" % WRName
        else:
          CtField = "%s.vat.COUNT" % WRName
        # fgdb/arcsde raster - "VAT_name.COUNT"
        if not gp.ListFields(tvRAT,CtField):
          CtField = "%s.COUNT" % WRName

        # Populate weight-zone-area WAREA; remove join
        strExpr = "[%s] * %s" % (CtField ,WRCellArea)
        gp.CalculateField(tvRAT,"WAREA", strExpr)
        gp.MakeTableView(tmpRAT,tvRAT)

        # Populate weight-zone-area-fraction WAREAF; remove join
        # (first, reselect for matches so we don't divide by zero)
        strExpr = "\"WAREA\" > 0"
        gp.SelectLayerByAttribute(tvRAT,"#",strExpr)
        gp.CalculateField(tvRAT,"WAREAF","[AREA] / [WAREA]")
        gp.SelectLayerByAttribute(tvRAT,"CLEAR_SELECTION")

        # save results to the output table

        # create output table template
        if not gp.Exists(tmpOut):
          gp.CreateTable(os.path.dirname(tmpOut),
                         os.path.basename(tmpOut),tmpRAT)
          # drop the fields we don't want
          DropFields = "COUNT;%s;%s" % (WField,AField)
          gp.DeleteField(tmpOut,DropFields)

        if not gp.Exists(outTable):
          # first time for a successful overlay: create output table
          gp.CreateTable(os.path.dirname(outTable),\
                         os.path.basename(outTable),tmpOut)

        # Append rows to temporary table (only the fields we need will copy)
        gp.Append(tmpRAT,tmpOut,"NO_TEST")

        # Use a cursor to output the results to OutTable in sorted order
        strSort =  "AREAID a; WTZONE a; ZONE a"
        IRows = gp.SearchCursor(tmpOut,"","","",strSort)
        ORows = gp.InsertCursor(outTable)
        IRow = IRows.Next()
        while IRow:
          ORows.InsertRow(IRow)
          IRow = IRows.Next()
        # clean up
        del IRow,IRows,ORows

        # delete rows in tmpRAT, tmpOut for next run
        gp.DeleteField(tvRAT,"%s;%s" % (AField,WField))
        gp.DeleteRows(tmpRAT)
        gp.DeleteRows(tmpOut)

        # report progress
        strMsg = "Processed %s = \"%s\" (%s/%s) ..." % \
          (strIDField,strIDValue,kRec,numRows)
        GPMsg(strMsg)

        # Get next feature
        ProcRow = ProcRows.Next()
        kRec += 1

    else:

      # features do not overlap, we can do it one step

      # set up raster environment

      # Extent
      gp.Extent = tmpFC

      # single points give you a one-point extent
      if not gp.Extent:
        gp.Extent = nact.GetExtent(tmpFC, ProcCell)

      # check extent
      try:
        nact.CheckRasterExtent(gp.Extent, dWR.MeanCellHeight,False)
      except Exception, xmsg:
        raise MsgError, "Feature class extent is " \
          "smaller than Weight_raster cell size.\n" + str(xmsg)

      # Coarse sampling check
      nact.CheckRasterExtent(gp.Extent, dWR.MeanCellHeight)
      # set the extent the feature area plus 1 cell
      # to insure all area is processed
      gp.Extent = nact.GetExtent(tmpFC,ProcCell)

      gp.Cellsize = ProcCell

      # Feature To Raster to create raster for overlay
      # We do this because setting the mask to
      # a feature is not consistent w/ feature to raster
      try:
        gp.FeatureToRaster(tmpFC,strIDField1,tmpFeatRaster)
      except:
        raise Exception, "Feature to Raster failed."

      lyrFR = "lyrFR"
      gp.MakeRasterLayer(tmpFeatRaster,lyrFR)

      # ensure environment includes snap etc.
      gp.Extent = tmpFeatRaster
      gp.Cellsize = tmpFeatRaster
      gp.Mask = tmpFeatRaster

      # create grid expressions for combine()
      if not zoneRaster:
        # combine feature id with weight id
        # replace NoData with NDCode in weight raster
        WRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,NDCode,lyrWR)
        MAExpr = "combine(%s,%s)" % (lyrFR,WRExpr)
      else:
        # combine feature id with weight id and zone id
        # Replace nodata with our NoData code
        WRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,NDCode,lyrWR)
        PRExpr = "con(isnull(%s),%s,%s)" % (lyrZR,NDCode,lyrZR)
        MAExpr = "combine(%s,%s,%s)" % (lyrFR,WRExpr,PRExpr)
      try:
        gp.SingleOutputMapAlgebra(MAExpr,tmpCombRaster)
        gp.BuildRasterAttributeTable(tmpCombRaster)
      except:
        raise MsgError, gp.GetMessages(2) + "Raster processing failed."

      # done raster processing; clean up
      gp.ClearEnvironment("Extent")
      gp.ClearEnvironment("Mask")
      gp.Delete(lyrFR)

      # find field names in the combine output table
      tvCmb = "tvCmb"
      #  ID, VALUE, COUNT, <AFIELD>, <WFIELD>
      gp.MakeTableView(tmpCombRaster,tvCmb)
      CFields = gp.Describe(tvCmb).Fields

      AField = CFields[3].Name
      WField = CFields[4].Name

      if zoneRaster:
        ZField = CFields[5].Name
      else:
        ZField = AField

      CombRows = CountRows(tvCmb)
      if not CombRows:
        raise MsgError, "Raster overlay resulted in no output"

      # copy VAT to temp table
      # first create a schema table
      tmpSchema = memWS + "/xxschema"
      tvSchema = "tvSchema"
      gp.CreateTable(memWS,"xxschema",tvCmb)
      gp.MakeTableView(tmpSchema,tvSchema)
      # add fields to output weight table template
      if IDFieldType == "String":
        gp.AddField(tvSchema,"AREAID","TEXT","#","#",IDFieldLen)
      else:
        gp.AddField(tvSchema,"AREAID","LONG")
      gp.AddField(tvSchema,"ZONE","LONG")
      gp.AddField(tvSchema,"WTZONE","LONG")
      gp.AddField(tvSchema,"NCELLS","LONG")
      gp.AddField(tvSchema,"AREA","DOUBLE")
      gp.AddField(tvSchema,"AREAF","FLOAT")
      gp.AddField(tvSchema,"WAREA","DOUBLE")
      gp.AddField(tvSchema,"WAREAF","FLOAT")
      gp.MakeTableView(tmpSchema,tvSchema) # refresh with new columns
      gp.CreateTable(os.path.dirname(tmpRAT),os.path.basename(tmpRAT),tmpSchema)
      gp.Delete(tmpSchema)
      gp.Append(tvCmb,tmpRAT,"NO_TEST")
      gp.MakeTableView(tmpRAT,tvRAT)

      # populate ID field
      tmpFRName = gp.Describe(tmpFeatRaster).Name
      if IDFieldType == "String":
        gp.AddJoin(tvRAT,AField,tmpFeatRaster,"VALUE")
        gp.CalculateField(tvRAT,"AREAID","[%s.vat:%s]" % (tmpFRName,strIDField1))
        gp.MakeTableView(tmpRAT,tvRAT)  # remove all joins

      else:
        gp.CalculateField(tvRAT,"AREAID","[%s]" % AField) # ID Field

      gp.CalculateField(tvRAT,"WTZONE", "[%s]" % WField)
      gp.CalculateField(tvRAT,"ZONE", "[%s]" % ZField)
      gp.CalculateField(tvRAT,"NCELLS","[%s]" % "COUNT")

      # calculate area percents for input zone (AField)
      gp.Statistics_analysis(tvRAT,tmpSum,"COUNT SUM","AREAID")

      # calculate cell areas
      CellArea = ProcCell ** 2
      WRCellArea = float(dWR.MeanCellHeight) ** 2
      # calculate areas
      gp.CalculateField(tvRAT,"AREA", "[COUNT] * %s" % CellArea)
      # calculate percents
      gp.AddJoin(tvRAT,"AREAID",tmpSum,"AREAID")
      tmpSumName = os.path.basename(tmpSum)
      tmpRATName = os.path.basename(tmpRAT)
      gp.CalculateField(tvRAT,"AREAF","[%s.COUNT] / [%s.SUM_COUNT]" %\
                        (tmpRATName,tmpSumName))
      gp.RemoveJoin(tvRAT,tmpSumName)

      # calculate weight zone WAREA, WAREAF

      gp.AddJoin(tvRAT,WField,tvWRRAT,"VALUE")

      # determine join field name for COUNT
      WRName =  gp.Describe(tvWRRAT).Name
      # remove .dbf extension if there (file image formats)
      WRName = os.path.splitext(WRName)[0]
      if dWR.Format == "GRID":
        CtField = "%s.vat:COUNT" % WRName
      else:
        CtField = "%s.vat.COUNT" % WRName
      # fgdb/arcsde raster - "VAT_name.COUNT"
      if not gp.ListFields(tvRAT,CtField):
        CtField = "%s.COUNT" % WRName

      # Populate weight-zone-area WAREA; remove join
      strExpr = "[%s] * %s" % (CtField ,WRCellArea)
      gp.CalculateField(tvRAT,"WAREA", strExpr)
      gp.MakeTableView(tmpRAT,tvRAT)

      # Populate weight-zone-area-fraction WAREAF; remove join
      # (first, reselect for matches so we don't divide by zero)
      strExpr = "\"WAREA\" > 0"
      gp.SelectLayerByAttribute(tvRAT,"#",strExpr)
      gp.CalculateField(tvRAT,"WAREAF","[AREA] / [WAREA]")
      gp.SelectLayerByAttribute(tvRAT,"CLEAR_SELECTION")

      # save results to the output table

      # create output table template
      gp.CreateTable(os.path.dirname(tmpOut),
                     os.path.basename(tmpOut),tmpRAT)
      # drop the fields we don't want
      DropFields = "VALUE;COUNT;%s;%s" % (WField,AField)
      if zoneRaster: DropFields += ";%s" % ZField
      gp.DeleteField(tmpOut,DropFields)

      # Append rows to temporary table (only the fields we want will copy)
      gp.Append(tmpRAT,tmpOut,"NO_TEST")


      # create real output table
      gp.CreateTable(os.path.dirname(outTable),\
                     os.path.basename(outTable),tmpOut)

      # Use a cursor to output the results to OutTable in sorted order
      strSort =  "AREAID a; WTZONE a; ZONE a"
      IRows = gp.SearchCursor(tmpOut,"","","",strSort)
      ORows = gp.InsertCursor(outTable)
      IRow = IRows.Next()
      while IRow:
        ORows.InsertRow(IRow)
        IRow = IRows.Next()
      # clean up
      del IRow,IRows,ORows


      # if point buffers, check for overlap
      if dInputFC.ShapeType == "Point":
        tmpTable1 = "in_memory/xxcount_check1"
        tmpTable2 = "in_memory/xxcount_check2"
        gp.Statistics(tmpOut,tmpTable1,"NCELLS SUM","AREAID")
        gp.Statistics(tmpTable1,tmpTable2,"SUM_NCELLS MIN;SUM_NCELLS MAX")
        Rows = gp.SearchCursor(tmpTable2)
        Row = Rows.Next()
        minCell = float(Row.MIN_SUM_NCELLS)
        maxCell = float(Row.MAX_SUM_NCELLS)
        del Row, Rows
        gp.Delete(tmpTable1)
        gp.Delete(tmpTable2)
        pctDif = 100 * ( maxCell - minCell ) / minCell
        print pctDif
        if pctDif > 2.0:
          GPMsg("w","Statistics may be invalid because of point buffer overlaps")

  except MsgError, xmsg:
    GPMsg("e",str(xmsg))
  except GPError:
    GPMsg("e",str(traceback.format_exc()).strip())
    numMsg = gp.MessageCount
    for i in range(0, numMsg):
      GPMsg("Return",i)
  except:
    GPMsg("e",str(traceback.format_exc()).strip())
  finally:
    try:
      del ProcRow, ProcRows # remove cursor
    except:
      pass
    for f in [lyrProcFC, lyrWR, lyrFR, tmpFC,
               tvWRRAT, tvCmb, tvSchema, tvRAT,
               tmpRAT, tmpFeat, tmpFeatRaster,
               tmpSchema, tmpSum, tmpOut, tmpFGDB, tmpWS]:
      try:
        if f:
          gp.Delete(f)
      except:
        pass
    if gp.Exists(tmpWS):
      GPMsg("w", "Could not delete %s" % tmpWS)


if __name__ == "__main__":
  runTool()

