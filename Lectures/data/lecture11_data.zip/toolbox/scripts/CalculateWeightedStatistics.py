"""
ArcGIS Script Tool - Area Weighted Statistics

"""
# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc; gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName

# Create the Geoprocessor object
gp = nact.getGP(9.3)

# temp file names
tvWT,tmpTab,tmpSum,tmpSta,tmpOutTable,tmpFGDB,tmpWS = \
  [None] * 7

try:

  # Environment
  gp.Toolbox = "management"
  gp.OverwriteOutput = 1
  gp.QualifiedFieldNames = False

  WeightTable    = gp.GetParameterAsText(0)
  AreaIDField    = gp.GetParameterAsText(1)

  try:
    if AreaIDField in ["","#"]: AreaIDField = "AREAID"
    AIField = gp.ListFields(WeightTable,AreaIDField)[0]
  except:
    raise MsgError, "No field %s in %s" % (AreaIDField,WeightTable)

  WeightKeyField = gp.GetParameterAsText(2)
  DataTable      = gp.GetParameterAsText(3)
  DataKeyField   = gp.GetParameterAsText(4)
  DataValFields  = gp.GetParameter(5)

  # convert multi-value to a python list
  lstVF = []
  for k in range(DataValFields.RowCount):
    lstVF.append(DataValFields.GetValue(k,0))
  numVF = len(lstVF)  # count them!

  strStat        = gp.GetParameterAsText(6)
  strStat = strStat.upper().replace("IMUM","")
  if strStat not in ["MEAN","SUM","MAX","MIN"]:
    raise MsgError, "Invalid statistic: " + strStat

  OutTable       = gp.GetParameterAsText(7)

  # Weight table fields
  AreaFracField  = gp.GetParameterAsText(8)
  WAreaFracField = gp.GetParameterAsText(9)
  WeightAreaField = gp.GetParameterAsText(10)
  if AreaFracField in ["","#"]: AreaFracField = "AREAF"
  if WAreaFracField in ["","#"]: WAreaFracField = "WAREAF"
  if WeightKeyField in ["","#"]: WeightKeyField = "WTZONE"
  if WeightAreaField in ["","#"]: WeightAreaField = "#"
  dWeightTable = gp.Describe(WeightTable)
  lstWeightTableFields = [Fld.Name for Fld in dWeightTable.Fields]
  for Fld in [AreaIDField,AreaFracField,WAreaFracField,WeightKeyField]:
    if Fld not in lstWeightTableFields:
      raise MsgError, "Field %s not found in %s" % (Fld,WeightTable)

  # short names for area-fraction fields
  AREAF = AreaFracField
  WAREAF = WAreaFracField

  # workspace environment
  CWS = gp.Workspace       # save current workspace environment
  SWS = gp.ScratchWorkspace
  tmpWS = ScratchName("xxwk","","folder")
  os.mkdir(tmpWS)

  # set up a file geodatabase for our tables
  tmpFGDB = ScratchName("",".gdb","workspace",tmpWS)
  gp.CreateFileGDB(os.path.dirname(tmpFGDB),os.path.basename(tmpFGDB))
  gp.Workspace = tmpFGDB
  gp.ScratchWorkspace = tmpFGDB
  # use memory workspace for small temp files (fast)
  memWS = "in_memory"

  GPMsg("Creating table..")

  # create many to one table - do table layout in in_memory for speed
  tmpSchema = ScratchName("xxSchema","","Table",memWS)
  gp.CreateTable(memWS,os.path.basename(tmpSchema),WeightTable+";"+DataTable)
  lstKeep = ["OID",AreaIDField,AREAF,WAREAF,WeightKeyField] + lstVF
  if WeightAreaField != "#": lstKeep.append(WeightAreaField)
  strDrop = ""
  for Fld in gp.Describe(tmpSchema).Fields:
    if Fld.Name not in lstKeep and Fld.Type <> "OID": strDrop += Fld.Name + ";"
  try:
    gp.DeleteField(tmpSchema,strDrop)
  except:
    pass

  # add weight value fields
  lstWF = ["w_%s" % f for f in lstVF]
  for ff in lstWF:
    gp.AddField(tmpSchema,ff,"DOUBLE",19,9)

  tvWT = "tvWT" # weight table layer
  gp.QualifiedFieldNames = False
  gp.MakeTableView(WeightTable,tvWT)
  tmpTabdt = ScratchName("xxdt","","table",tmpFGDB)
  tmpTabwt = ScratchName("xxwt","","table",tmpFGDB)
  gp.CopyRows(DataTable,tmpTabdt)
  # join, select matches, and copy to temp table
  gp.AddJoin(tvWT,WeightKeyField,tmpTabdt,DataKeyField,"KEEP_COMMON")
  tmpTab = ScratchName("xxtab","","table",tmpFGDB)
  gp.CopyRows(tvWT,tmpTabwt)
  gp.MakeTableView(WeightTable,tvWT) # remove join
  gp.Delete(tmpTabdt)

  gp.CreateTable(tmpFGDB,os.path.basename(tmpTab),tmpSchema)
  gp.Append(tmpTabwt,tmpTab,"NO_TEST")
  gp.Delete(tmpTabwt)

  GPMsg("Calculating weights...")
  # area-weighted field calculation
  # MEAN: "[value_field]*[AREAF]" , sum by areaid, then div sum/areaid
  # SUM:  "[Value_field]*[WAREAF]", sum by areaid

  for k in range(numVF):
    if strStat == "MEAN":
      strExpr = "[%s] * [%s]" % (lstVF[k],AREAF)
      gp.CalculateField(tmpTab,lstWF[k],strExpr)
    elif strStat == "SUM":
      strExpr = "[%s] * [%s]" % (lstVF[k],WAREAF)
      gp.CalculateField(tmpTab,lstWF[k],strExpr)


  # now run statistics
  # build stat expression
  strStatExpr = ""
  if strStat in ["MEAN","SUM"]:
    for k in range(numVF):
      strStatExpr += "%s SUM;" % lstWF[k]
  else: # min, max
      for k in range(numVF):
        strStatExpr += "%s %s;" % (lstVF[k],strStat)
  if WeightAreaField != "#": strStatExpr += WeightAreaField + " SUM;"
  strStatExpr = strStatExpr[:-1]  # drop trailing ";"

  GPMsg("Calculating statistics...")
  ## run statistics
  tmpSta = ScratchName("xxsta","","table",tmpFGDB)
  gp.Statistics(tmpTab,tmpSta,strStatExpr,AreaIDField)

  if strStat == "MEAN":
    # sum AREAF for weights (in case they don't add up to 1.0 for each areaid
    tmpSum = ScratchName("xxfrq","","table",tmpFGDB)
    strExpr = "%s SUM" % AREAF
    gp.Statistics_analysis(tmpTab,tmpSum,strExpr,AreaIDField)

  GPMsg("Weighting results...")
  for k in range(numVF):
    gp.AddField(tmpSta,lstVF[k],"DOUBLE",20,5)
    if strStat in ["MEAN","SUM"]:
      gp.CalculateField(tmpSta,lstVF[k],"[%s_%s]" % ("SUM",lstWF[k]))
      if strStat == "MEAN":
        lyrSta = "lyrSta"
        gp.MakeTableView(tmpSta,lyrSta)
        gp.AddJoin(lyrSta,AreaIDField,tmpSum,AreaIDField,"KEEP_COMMON")
        SumName = os.path.splitext(os.path.basename(tmpSum))[0]
        StaName = os.path.splitext(os.path.basename(tmpSta))[0]
        strExpr = "[%s.SUM_%s] / [%s.SUM_%s]" % \
                (StaName,lstWF[k],SumName,AREAF)
        gp.CalculateField(lyrSta,lstVF[k],strExpr)
    else:
      gp.CalculateField(tmpSta,lstVF[k],"[%s_%s]" % (strStat,lstVF[k]))

  GPMsg("Formatting and writing results...")
  # Create output table with just our output fields
  # AREAID and value fields, and copy our result to it
  tmpOutTable = ScratchName("xxout","","table",memWS)
  gp.CreateTable(os.path.dirname(tmpOutTable), \
                 os.path.basename(tmpOutTable))
  if AIField.Type == "String":
    gp.AddField(tmpOutTable,AreaIDField,"TEXT","#","#",AIField.Length)
  else:
    gp.AddField(tmpOutTable,AreaIDField,"LONG")

  # add "carry" fields to output (FREQUENCY, AREA)
  # add FREQUENCY field to output (it's already in tmpSta)
  gp.AddField(tmpOutTable,"FREQUENCY","LONG")
  if WeightAreaField != "#":
    # add and populate area field in in tmpSTA
    gp.AddField(tmpSta,WeightAreaField,"DOUBLE",19,1)
    gp.CalculateField(tmpSta,WeightAreaField,"[SUM_%s]" % WeightAreaField)
    # add area field to output table
    gp.AddField(tmpOutTable,WeightAreaField,"DOUBLE",19,1)


  for vf in lstVF:
    gp.AddField(tmpOutTable,vf,"DOUBLE",20,5)
  gp.Append(tmpSta,tmpOutTable,"NO_TEST")

  # copy to output
  gp.CopyRows(tmpOutTable,OutTable)
  # fix INFO table
  if gp.Describe(OutTable).DataType == "ArcInfoTable":
    gp.DeleteField(OutTable,"OBJECTID")

except MsgError, xmsg:
  GPMsg("e",str(xmsg))
except GPError:
  GPMsg("e",str(traceback.format_exc()).strip())
  numMsg = gp.MessageCount
  for i in range(0, numMsg):
    GPMsg("Return",i)
except:
  GPMsg("e",str(traceback.format_exc()).strip())
finally:
  # Clean up
  for tmp in [tvWT,tmpTab,tmpSum,tmpSta,tmpOutTable,tmpFGDB,tmpWS]:
    try:
      if tmp: gp.Delete(tmp)
    except:
      pass
  if gp.Exists(tmpWS):
    GPMsg("w", "Could not delete %s" % tmpWS)

