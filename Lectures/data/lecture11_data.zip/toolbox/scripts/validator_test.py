# Create the parameter array and values
#
import arcgisscripting
gp = arcgisscripting.create(9.3)

# Add the toolbox and fetch the parameter list
#
gp.addtoolbox(r"E:\tools\Tbx\nact\nact_ofr_package\NACT.tbx")
params = gp.GetParameterInfo("AreaStatisticsToTable")
params[0].value = r"E:\tools\Tbx\nact\ntbx_data\Naomi\bcov\polygon"
params[1].value = "FID"
params[2].value = "#"
params[3].value = "#"
params[4].value = "#"
params[5].value = "#"
params[6].value = "#"

class ToolValidator:
  """Class for validating a tool"s parameter values and controlling
  the behavior of the tool"s dialog."""

  def __init__(self):
    """Setup the Geoprocessor and the list of tool parameters."""
    import arcgisscripting as ARC
    self.GP = ARC.create(9.3)
    self.params = self.GP.getparameterinfo()

  def initializeParameters(self):
    """Refine the properties of a tool"s parameters.  This method is
    called when the tool is opened."""
    return

  def updateParameters(self):
    import os
    if self.params[0].Value:
      try:
        d = self.GP.Describe(self.params[0].Value)
        inPath = d.CatalogPath
        dPath = self.GP.Describe(inPath)
      except:
        return
      if self.params[0].Altered:
        # user changed the input area argument
        # enable zone field argument
        self.params[1].Enabled = True

      if d.DataType == "Coverage":
        # convert coverage to coverage FC path
        for FC in ["polygon","arc","point"]:
          FCPath = inPath + "/" + FC
          if self.GP.Exists(FCPath):
            self.params[0].Value = os.path.realpath(FCPath)
            break

      if d.DatasetType[:6] == "Raster":
        # if zone field hasn't been set, default it to value
        if d.IsInteger:
          if not self.params[1].Value and not self.params[0].HasBeenValidated:
            self.params[1].Value = "VALUE"
        else:
          # not an integer raster - clear out value field
          self.params[1].Value = None
          self.params[1].Enabled = False

      # Output zone value -
      if self.params[1].Value:
        # if we have a zone field, disable this field!
        self.params[2].Value = None
        self.params[2].Enabled = False
      else:
        # enable user-specified output zone value
        self.params[2].Enabled = True
        # Default output zone value is input dataset name
        if self.params[0].Value and not self.params[2].Altered:
          DT = self.GP.Describe(dPath).DataType
          if DT == "CoverageFeatureClass":
            strName = os.path.basename(os.path.dirname(inPath))
          else:
            strName = os.path.splitext(os.path.basename(inPath))[0]
          self.params[2].Value = strName.upper()

    # No integer stats available for float value rasters
    import os
    if self.params[3].Value:
      if self.GP.Describe(self.params[3].Value).IsInteger:
        self.params[5].Filter.List = \
          ["MEAN", "MAJORITY", "MAXIMUM", "MEDIAN", "MINIMUM",
           "MINORITY", "RANGE", "STD", "SUM", "VARIETY"]
      else:
        self.params[5].Filter.List = \
          ["MEAN", "MINIMUM", "MAXIMUM","RANGE", "STD", "SUM"]

    return

  def updateMessages(self):
    if self.params[0].Value:
      InArea = self.params[0].Value
      # check coverage topology
      try:
        d = self.GP.Describe(InArea)
        dPath = self.GP.Describe(d.CatalogPath)
      except:
        self.params[0].SetErrorMessage("bad juju " + str(InArea))
        print "bad juju " + str(InArea)
        return
      if dPath.DataType.find("Coverage") >= 0:
        if dPath.DataType == "Coverage" or \
          not ( dPath.DataType == "CoverageFeatureClass" and \
            dPath.ShapeType in ["Polygon","PolyLine"]) :
          self.params[0].SetErrorMessage(\
            "Coverage polygon or line topology invalid. "
            "Please use Build or Clean.")
      elif d.DataSetType == "FeatureDataset":
        # feature datasets are not supported input
        self.params[0].SetIDMessage("Error",863)

    # bad output path - this can happen when gp.Workspace is None
    if self.params[4].Value:
      import os
      OutPath = os.path.dirname(self.GP.Describe(self.params[4].Value).CatalogPath)
      if self.GP.Describe(OutPath).DataType not in ["Folder","Workspace"]:
        self.params[4].SetIDMessage("Error",198)

    return




# Call routine(s) to debug
#
validator = ToolValidator()
validator.updateParameters()
validator.updateMessages()
i = 0
for k in params:
  print i,str(k.Value)
  i += 1