"""
ArcGIS Script Tool - Footprint Statistics To Table

"""

# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc; gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName, CountRows

# Create the Geoprocessor object
gp = nact.getGP(9.3,"spatial")

def RunTool():
  inLayers = gp.GetParameter(0)
  valueRaster = gp.GetParameterAsText(1)
  outTable = gp.GetParameterAsText(2)
  inStats = gp.GetParameter(3)
  ignoreNoData = (gp.GetParameterAsText(4) in ["DATA","true",""])
  fullPathFootprint = (gp.GetParameterAsText(5) in ["BASEPATH","false",""])
  FootprintStatsToTable(inLayers,valueRaster,outTable,
                        inStats,ignoreNoData,fullPathFootprint)

def FootprintStatsToTable(inLayers,valueRaster,outTable,inStats="MEAN",
                          ignoreNoData=True,fullPathFootprint=False):

  # initialize variables
  lyrVR,tmpFC,tmpZone,tmpTable,tmpSchema,tmpOut,tmpFGDB,tmpWS = [None] * 8
  lstOutFields, lstOutFieldsV = [], []

  try:

    # Environment
    gp.Toolbox = "management"
    gp.OverwriteOutput = 1
    gp.QualifiedFieldNames = False
    gp.LogHistory = False

    # Script arguments

    # Feature Class or Raster Layer(s)
    lstFootprints = []
    # convert multi-value argument to a python list
    for k in range(inLayers.RowCount):
      lstFootprints.append(inLayers.GetValue(k,0))
    numFP = len(lstFootprints)  # count them!

    if numFP == 1:
      GPMsg("w",\
        "Only one footprint data set entered -- only one row will be output.")

    # convert coverages to polygon feature classes
    FPFix = []
    for FP in lstFootprints:
      dFP = gp.Describe(FP)
      strFP = FP
      try:
        DSType = dFP.DatasetType
      except:
        raise MsgError, "%s is not a dataset" % FP
      if dFP.DatasetType.find("Raster") == -1:
        # if a coverage was entered - extract polygon feature class
        if dFP.DataType == "Coverage":
          strFP = os.path.join(dFP.CatalogPath,"polygon")
          if not gp.Exists(strFP):
            raise MsgError, "Coverage \"%s\" does not have polygon topology" % FP
          dFP = gp.Describe(strFP)
        if dFP.ShapeType != "Polygon":
          raise MsgError, "Cannot process \"%s\".\n" % dFP.CatalogPath + \
                "Only polygon feature and raster data sets are supported."
      FPFix.append(strFP)
    lstFootprints = FPFix


    # Value raster (required)
    # for zonal statistics
    dVR = gp.Describe(valueRaster)
    VRName = os.path.basename(dVR.CatalogPath)

    # zonal statistics to calculate
    # this is a multi value (many stats can be calculated)
    lstStats = []
    # convert multi-value argument to a python list
    numStats = inStats.RowCount
    for k in range(numStats):
      lstStats.append(inStats.GetValue(k,0).upper())
    # verify arguments and figure out which fields to drop from output
    if lstStats[0] in ["","#"]: lstStats[0] = "MEAN"
    fltStats =  ["MIN","MAX","RANGE","MEAN","STD","SUM"]
    intStats = ["VARIETY","MAJORITY","MINORITY","MEDIAN"]
    lstDrop = fltStats + intStats
    for kStat in lstStats:
      # Output field names for min,max are "MIN","MAX"
      strStatField = kStat.replace("IMUM","")
      if strStatField not in intStats + fltStats:
        raise MsgError, "Invalid statistic: " + kStat
      # Check to make sure we're not asking integer stats for a float raster
      if strStatField in intStats:
        if not dVR.isInteger:
          raise MsgError, "%s is only supported for integer rasters" % strStat
      lstDrop.remove(strStatField) # we're using this stat, so drop from list
    strDrop = ";".join(lstDrop) # convert to string for DeleteFields tool

    # Ignore NoData in calculations (like Zonal Statistics As Table tool)
    if ignoreNoData:
      ignoreNoData = "DATA"
    else:
      ignoreNoData = "NODATA"

    strIDField = "FOOTPRINT" # hard coded

    FullPathFootprint = gp.GetParameterAsText(5) == "true"

    # initialize temp variables
    lyrVR,tmpFC,tmpZone,tmpFGDB,tmpWS,memWS = [None] * 6

    # initialize file names
    tmpWS = ScratchName("xxwk","","workspace")
    tmpFGDB = os.path.join(tmpWS,"work.gdb")
    memWS = "in_memory"
    tmpFC = os.path.join(tmpFGDB,"tempfeat")
    tmpMask = os.path.join(tmpWS,"maskg")
    tmpZone = os.path.join(tmpWS,"featg")
    tmpZStat = os.path.join(tmpFGDB,"stats")
    tmpTable = ScratchName("xtab","","table",memWS)
    tmpSchema = ScratchName("xschema","","table",memWS)
    tmpOut = ScratchName("xout","","table",memWS)
    lyrVR = "lyrVR"

    # workspace environment
    CWS = gp.Workspace       # save current workspace environment
    SWS = gp.ScratchWorkspace

    # work in a folder (GRIDs are fastest)
    os.mkdir(tmpWS)
    gp.Workspace = tmpWS
    gp.ScratchWorkspace = tmpWS

    # set up a file geodatabase for features
    gp.CreateFileGDB(os.path.dirname(tmpFGDB),os.path.basename(tmpFGDB))

    # make value raster layer
    gp.MakeRasterLayer(valueRaster,lyrVR)

    # Raster processing environment

    try:
      # if processing cell size explicitly set in environment, use it
      ProcCell = float(gp.CellSize)
      GPMsg("w","Using environment Cell Size: %s" % ProcCell)
    except:
      # otherwise, use cell size of value raster
      ProcCell = float(dVR.MeanCellHeight)
      GPMsg("Using Cell Size of %s (%s)" % (VRName,ProcCell))
    gp.CellSize = ProcCell
    if gp.SnapRaster:
      GPMsg("w","Using environment Snap Raster: %s" % gp.SnapRaster)
    else:
      gp.SnapRaster = lyrVR
      GPMsg("Raster snapping to %s" % VRName)

    # output coordinate system
    VRSR = dVR.SpatialReference
    if VRSR.Name == "Unknown":
      GPMsg("w","ID 522 %s" % valueRaster)
    else:
      gp.OutputCoordinateSystem = VRSR

    # start processing list of Footprint data sets
    ##GPMsg("Processing %s footprint layers ..." % numFP)

    kRec = 0
    FirstFootprint = True
    PrjWarning = False

    # process each footprint, one at a time
    for FP in lstFootprints:
      try:
        # Calculate string ID Field value from data set name
        dFP = gp.Describe(FP)

        FP_is_features = dFP.DataSetType.find("Raster") == -1

        # extract strIDFieldValue from input dataset path
        if not FullPathFootprint:
          strIDFieldValue = os.path.basename(dFP.CatalogPath)
          if FP_is_features:
            if gp.Describe(dFP.Catalogpath).DataType == "CoverageFeatureClass":
              # "e:\work\MyCover\polygon" -> "MyCover"
              strIDFieldValue = os.path.basename(os.path.dirname(dFP.CatalogPath))
              strIDFieldValue = os.path.splitext(strIDFieldValue)[0]
          strIDFieldWidth = "32"
        else:
          strIDFieldValue = dFP.CatalogPath
          strIDFieldWidth = "128"

        # initialize environment
        gp.ClearEnvironment("Mask")
        gp.ClearEnvironment("Extent")

        # coordinate system
        FPSR = dFP.SpatialReference
        if FPSR.Name == "Unknown":
          GPMsg("w","ID 522 %s" % FP)

        # if this is a feature class or layer, copy/project selected features
        if FP_is_features:
          gp.CopyFeatures(FP,tmpFC)
          gp.Extent = nact.GetExtent(tmpFC)
        else:
          gp.Extent = nact.GetExtent(FP)

        # check extent

        # Is extent larger than cell size of value raster?
        # If so this generates an error

        try:
          nact.CheckRasterExtent(gp.Extent,dVR.MeanCellHeight,False)
        except Exception, msg:
          if str(msg).find("larger than extent") != -1:
            raise Exception,\
              "Value raster cell size is larger than footprint extent"

        # Is extent close to or larger than processing cell size?
        # If close, a warning is printed
        nact.CheckRasterExtent(gp.Extent,ProcCell)
        # set the extent the feature area plus 1 cell
        # to insure all area is processed
        gp.Extent = nact.GetExtent(FP,ProcCell)

        # if this is a feature class, convert to a raster footprint
        if FP_is_features:
          try:
            gp.FeatureToRaster(tmpFC,gp.Describe(tmpFC).OIDFieldName,tmpMask)
          except:
            GPMsg("e","Footprint processing failed for %s" % FP)
          gp.Mask = tmpMask
          gp.CreateConstantRaster(tmpZone,1)
          gp.Delete(tmpFC)
          gp.Delete(tmpMask)
          strZones = tmpZone
          strZoneField = "VALUE"
        else:
          try:
            gp.Extent = nact.GetExtent(FP,ProcCell)
            # is this an integer single-value raster?
            gp.MakeTableView(FP,"tv")
            nRows = CountRows("tv")
            if nRows != "1": raise Exception
            tmpZone = None # we don't need one
            strZones = FP
            strZoneField = "VALUE"
          except:
            # if we get here it's a non integer raster or a raster
            # with more than one value, or a raster in a diff coordinate system.
            # Make a single-zone raster footprint
            gp.Mask = FP
            gp.CreateConstantRaster(tmpZone,"1")
            strZones = tmpZone
            strZoneField = "VALUE"




        # calculate zonal statistics
        gp.ZonalStatisticsAsTable(strZones,strZoneField,lyrVR,\
                                tmpZStat,ignoreNoData)
        # Stats can fail one of two ways:
        # - no records  (grid on grid overlay)
        # - zonalstats fails (grid on other raster format - NODATA on conversion
        #     trips an error condition)
        # did we get any records out?
        StatsOK = bool(CountRows(tmpZStat) > 0) # false if 0 records

      except Exception, xmsg:
        # something went wrong for this footprint!
        StatsOK = False
        GPMsg("w",str(xmsg))

      if StatsOK:
        if FirstFootprint:
          # create template table
          # AREAID, TEXT, 15 is first column, follwed by stat fields
          gp.CreateTable(os.path.dirname(tmpTable),os.path.basename(tmpTable))
          gp.AddField(tmpTable,strIDField,"TEXT","#","#",strIDFieldWidth)
          gp.AddField(tmpTable,"NCELLS","LONG")

          # Create table template with this list of fields
          gp.CreateTable(os.path.dirname(tmpSchema),
                        os.path.basename(tmpSchema),
                        tmpTable + ";" + tmpZStat)
          gp.Delete(tmpTable)
          # drop fields we don't need from schema table
          gp.DeleteField(tmpSchema,
            "Field1;VALUE;ZONE_CODE;%s" % strDrop)

          # create output table
          gp.CreateTable(os.path.dirname(outTable),
                         os.path.basename(outTable),
                         tmpSchema)
          gp.DeleteField(outTable,"COUNT")

          # create tmp output table
          gp.CreateTable(os.path.dirname(tmpOut), os.path.basename(tmpOut),
                      tmpSchema)

          FirstFootprint = False # Don't need to do that again future loops

        gp.Append(tmpZStat,tmpOut,"NO_TEST")

        # populate AREAID field and write to output
        gp.CalculateField(tmpOut,strIDField,"\"%s\"" % strIDFieldValue)
        gp.CalculateField(tmpOut,"NCELLS","[COUNT]")

        # Validate field names against output table location
        # (only need to do this the first time)
        if not lstOutFields:
          lstOutFields = gp.Describe(tmpOut).Fields
          outWS = os.path.dirname(outTable)
          typeMap = {"String":"TEXT","SmallInteger":"SHORT","Integer":"LONG",
                     "Single":"FLOAT","Double":"DOUBLE"}
          for Fld in lstOutFields:
            FieldNameV = gp.ValidateFieldName(Fld.Name,outWS)
            # note, we took care of COUNT already with NCELLS field
            if Fld.Name != FieldNameV and Fld.Name <> "COUNT":
              newFldType = typeMap[Fld.Type]
              gp.AddField(tmpOut,FieldNameV,newFldType,"#","#",Fld.Length)
              lstOutFieldsV.append([FieldNameV,Fld.Name])

        # copy values over to fields with validated names, if any
        for fldPair in lstOutFieldsV:
          gp.CalculateField(tmpOut,fldPair[0],"[%s]" % fldPair[1])


        gp.Append(tmpOut,outTable,"NO_TEST")
        gp.DeleteRows(tmpOut) # we can re-use this table next pass

        # report progress - this can be slow so go ahead and report each one
        strMsg = "Processed \"%s\" (%s/%s) ..." % \
                 (FP,kRec + 1,numFP)
        GPMsg(strMsg)
      else:
        GPMsg("w",\
          "Zonal statistics could not be computed for \"%s\" (%s/%s)" \
           % (FP,kRec + 1,numFP))

      # Go on to next footprint
      kRec += 1

      if FirstFootprint:
        # we didn't even do one successfully!
        raise MsgError,"No footprints could be successfully processed.\n" +\
                       "Output table not created."

  except MsgError, xmsg:
    GPMsg("e",str(xmsg))
  except GPError:
    GPMsg("e",str(traceback.format_exc()).strip())
    numMsg = gp.MessageCount
    for i in range(0, numMsg):
      GPMsg("Return",i)
  except:
    GPMsg("e",str(traceback.format_exc()).strip())
  finally:
    for f in [lyrVR,tmpFC,tmpZone,tmpTable,tmpSchema,tmpOut,tmpFGDB,tmpWS]:
      try:
        if f: gp.Delete(f)
      except:
        pass
    if gp.Exists(tmpWS):
      GPMsg("w", "Could not delete %s" % tmpWS)

if __name__ == "__main__":
  RunTool()

