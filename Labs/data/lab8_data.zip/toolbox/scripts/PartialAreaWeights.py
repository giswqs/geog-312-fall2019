"""
ArcGIS Script Tool - Partial Area Weights

"""
# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc; gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName

# Create the Geoprocessor object
gp = nact.getGP(9.3,"spatial")

tmpTab1, tmpTab2, tblMissing, tmpOut = [None] * 4

try:

  nact.SetProduct("ArcInfo") # need ArcInfo license
  gp.OverwriteOutput = True
  gp.Toolbox = "management"

  tblWT = gp.GetParameterAsText(0)
  fldWT_Zone = gp.GetParameterAsText(1)
  fldWT_PZone = gp.GetParameterAsText(2)
  strPZoneValues = gp.GetParameterAsText(3)
  lstPZoneValues = strPZoneValues.split(";")

  fldWT_Area = gp.GetParameterAsText(4)
  tblWZ = gp.GetParameterAsText(5)
  fldWZ_Zone = gp.GetParameterAsText(6)
  fldWZ_PZone = gp.GetParameterAsText(7)
  fldWZ_Area = gp.GetParameterAsText(8)
  tblOut = gp.GetParameterAsText(9)

  # create selection expressions
  lstExpr = ["\"%s\" = %s" %  (fldWT_PZone,k) for k in lstPZoneValues]
  strWT_SelectExpr = " OR ".join(lstExpr)

  lstExpr = ["\"%s\" = %s" %  (fldWZ_PZone,k) for k in lstPZoneValues]
  strWZ_SelectExpr = " OR ".join(lstExpr)

  # sum up zone table AREA values for selected zones to temporary table
  tmpTab1 = ScratchName("x1","","table","in_memory")
  tmpTab2 = ScratchName("x2","","table","in_memory")
  tblMissing = ScratchName("x3","","table","in_memory")
  tmpOut = ScratchName("x4","","table","in_memory")
  tvWZ = "tvWZ"
  gp.MakeTableView(tblWZ,tvWZ,strWZ_SelectExpr)
  gp.CopyRows(tvWZ,tmpTab2)

  gp.Frequency_analysis(tvWZ,tmpTab1,fldWZ_Zone,fldWZ_Area)

  # Select matching rows from weight table

  tvWT = "tvWT"
  gp.MakeTableView(tblWT,tvWT,strWT_SelectExpr)
  # select rows that have a match and copy to temp table
  gp.AddJoin(tvWT,fldWT_Zone,tmpTab1,fldWZ_Zone,"KEEP_COMMON")
  JName = os.path.splitext(os.path.basename(tmpTab1))[0]
  ##gp.SelectLayerByAttribute(tvWT,"#","%s.%s IS NOT NULL" % (JName,fldWZ_Zone))
  gp.RemoveJoin(tvWT,JName) # selected features stays active
  gp.CopyRows(tvWT,tmpTab2)

  gp.MakeTableView(tmpTab2,tvWT)

  # calculate PAREAF value
  gp.AddField(tvWT,"PAREAF","DOUBLE")
  gp.AddJoin(tvWT,fldWT_Zone,tmpTab1,fldWZ_Zone)
  Tab1 = os.path.splitext(os.path.basename(tmpTab1))[0]
  Tab2 = os.path.splitext(os.path.basename(tmpTab2))[0]
  # calculate PAREAF
  gp.CalculateField(tvWT,"%s.PAREAF" % Tab2,\
                    "[%s.%s] / [%s.%s]" % \
                   (Tab2, fldWT_Area, Tab1, fldWZ_Area))
  gp.MakeTableView(tmpTab2,tvWT) # drop all joins

  # summarize results to output (leaving out rows and columns
  # we do not need for weighted statistics)
  FrqFields = "%s;%s" % ("AREAID",fldWT_Zone)
  SumFields = "%s;%s;%s" % ("AREA","AREAF","PAREAF")
  gp.Frequency(tvWT,tblOut,FrqFields,SumFields)
  gp.DeleteField(tblOut,"FREQUENCY")

  gp.Delete(tmpTab1)
  gp.Delete(tmpTab2)

  # find AREAID, weight-zone not included in results (because there
  # was no overlapping area for that particular AREAID/ZONE)

  gp.Statistics(tblWT,tblMissing,"%s COUNT" % "AREAID","AREAID;%s" % fldWT_Zone)
  for fld in ["AREA","AREAF","PAREAF"]:
    gp.AddField(tblMissing,fld,"DOUBLE")
    gp.CalculateField(tblMissing,fld,"0")
  tv = "tv"
  gp.MakeTableView(tblMissing,tv)
  gp.AddJoin(tv,"AREAID",tblOut,"AREAID")
  tblOutName = os.path.splitext(os.path.basename(tblOut))[0]
  gp.SelectLayerByAttribute(tv,"#",\
                           "%s.AREAID IS NULL" % tblOutName)
  gp.RemoveJoin(tv,tblOutName)
  gp.Append(tv,tblOut,"NO_TEST")
  gp.Delete(tblMissing)

  # sort output by AREAID and zone
  tmpOut = "in_memory/xxxOut"
  gp.CopyRows(tblOut,tmpOut)
  gp.Delete(tblOut)
  Rows = gp.SearchCursor(tmpOut,"","","","AREAID;%s" % fldWT_Zone)
  Row = Rows.Next()
  gp.CreateTable(os.path.dirname(tblOut),os.path.basename(tblOut),tmpOut)
  outRows = gp.InsertCursor(tblOut)
  while Row:
    outRows.insertRow(Row)
    Row = Rows.Next()
  del Row, Rows, outRows

  GPMsg("  Partial weights calculated for %s values: %s\n" %\
        (fldWT_PZone,','.join(lstPZoneValues)) + \
        "  and written to table \"%s\"" % os.path.basename(tblOut))

except MsgError, xmsg:
  GPMsg("e",str(xmsg))
except GPError:
  GPMsg("e",str(traceback.format_exc()).strip())
  numMsg = gp.MessageCount
  for i in range(0, numMsg):
    GPMsg("Return",i)
except:
  GPMsg("e",str(traceback.format_exc()).strip())
finally:
  for f in [tmpTab1, tmpTab2, tblMissing, tmpOut]:
    try:
      if f: gp.Delete(f)
    except Exception, xmsg:
      if gp.Exists(f):
        GPMsg("w", str(gp.GetMessages(2)))
