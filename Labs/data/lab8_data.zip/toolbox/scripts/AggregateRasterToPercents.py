"""
ArcGIS Script Tool - Aggregate Raster To Percentage Grids
"""
# Import system modules
import sys
import os
import traceback

# ESRI geoprocessor error
from arcgisscripting import ExecuteError as GPError

# import script utilities nact.py
import nact
from nact import GPMsg, MsgError

# Create the Geoprocessor object, with Spatial license
gp = nact.getGP(9.3,"spatial")

# initialize temp data set names
tmpSnap, tmpGrid, tmpGrid2, lyrSamp = [None] * 4

try:

  # Environment
  gp.Toolbox = "management"
  gp.OverwriteOutput = True
  gp.QualifiedFieldNames = False
  gp.Pyramid = "NONE"

  # Script arguments

  # input category raster
  CatRaster = gp.GetParameterAsText(0) # raster layer
  dCR = gp.Describe(CatRaster)
  if not dCR.IsInteger:
    raise MsgError, "Input \"%s\" is not an integer raster" %\
          dCR.CatalogPath
  CatRasterFmt = dCR.Format
  CatRasterXYUnits = dCR.SpatialReference.LinearUnitName

  # Output workspace
  PctRasterPath = gp.GetParameterAsText(1)
  if gp.Exists(PctRasterPath):
    try:
      gp.Delete(PctRasterPath)
    except:
      pass
    if gp.Exists(PctRasterPath):
      raise MsgError, "Could not delete existing workspace: %s" % PctRasterPath
  # is this a workstation-safe path?
  if PctRasterPath.find(" ") >= 0:
    raise MsgError, "Output folder path may not contain spaces"

  # Raster Cell Size for output
  OutCell = float(gp.GetParameterAsText(2))

  # x and y register for output grids
  # by default make them 0,0
  try:
    XReg = float(gp.GetParameterAsText(3))
    YReg = float(gp.GetParameterAsText(4))
  except:
    XReg, YReg = 0.0,0.0


  # Round output grids to integer percents? (NO_ROUND | ROUND)
  RoundPercents = gp.GetParameterAsText(5) == "true"
  if RoundPercents:
    GPMsg("Output rasters will be rounded to integer percent values.")

  # Expand if needed (Aggregate tool) (EXPAND | TRUNCATE)
  if gp.GetParameterAsText(6).lower() in ["false","truncate"]:
    extentHandling = "TRUNCATE"
  else: extentHandling = "EXPAND"

  # Ignore NoData values? (DATA | NODATA)
  if gp.GetParameterAsText(7).lower() in ["false","nodata"]:
    ignoreNoData = "NODATA"
  else: ignoreNoData = "DATA"

  # NoData value (optional)
  NoDataValue = gp.GetParameterAsText(8)
  if NoDataValue != "":
    try:
      NoDataValue = int(NoDataValue)
    except:
      raise MsgError, "Invalid NoData_value: %s" % NoDatavalue

  # create output workspace
  try:
    if gp.Exists(PctRasterPath): gp.Delete(PctRasterPath)
    os.mkdir(PctRasterPath)
    gp.Workspace = PctRasterPath
    gp.ScratchWorkspace = PctRasterPath
  except:
    raise MsgError, "Output workspace %s could not be created" % PctRasterPath

  # Calculate processing cell size to aggregate.
  # Resampling may be needed as the aggregation factor
  # must be an integer.
  #
  # For example:
  #  input: 30.0 cell size
  #  output: 1000.0 cell size
  #  CellRatio  = 1000.0/30.0 = 33.333
  #  Processing cell = round(1000.0/int(CellRatio) = 1000.0/30 = 30.303
  #  Cell factor = int(1000.0/30.30303) = 33
  InCell = float(dCR.MeanCellHeight)
  CellRatio = OutCell / InCell
  if CellRatio < 2.0:
    raise MsgError, \
      "Output cell size must be more than two times input cell size"
  ProcCell = float(OutCell / int(CellRatio))
  CellFactor = int(round(OutCell / ProcCell)) # this must be an integer
  GPMsg("Input cell size:     %.5g" % dCR.MeanCellHeight)
  GPMsg("Resample cell size:  %.5g" % ProcCell)
  GPMsg("Aggregating %s x %s blocks to %.5g %s cell size." % \
        (CellFactor,CellFactor,OutCell,CatRasterXYUnits.lower()))
  GPMsg("Registration point (X,Y): (%s,%s)" % (XReg,YReg))

  # Set extent and workspace
  gp.Workspace = PctRasterPath
  gp.Extent = nact.GetExtent(CatRaster)

  # create,set snap raster
  tmpSnap = "xxsnap"
  gp.Extent = nact.SetSnapRaster(gp,tmpSnap,XReg,YReg,OutCell)

  # set cell size
  gp.CellSize = ProcCell

  ProcGrid = CatRaster

  # get list of zones and check names
  lyrRAT = "lyrRAT"
  try:
    gp.MakeTableView(ProcGrid,lyrRAT)
    lstCat = nact.ListUnique(lyrRAT,"VALUE")
  except:
    raise MsgError, "Could not create list values in %s" % CatRaster

  # handle NoData value
  if NoDataValue != "":
    lstCat.remove(NoDataValue) # no percent grid needed for that cat
  else:
    MapExpr = lyrSamp

  strPre = "pct"
  lstGrid = []
  for Cat in lstCat:
    strGridName = strPre + str(Cat) # "pct11"
    if len(strGridName) > 13:
      # 13 is the max name length for a grid
      raise MsgError, \
            "Input Category value \"%s\" more than 9 characters" % strCat
    lstGrid.append(strGridName)

  OutLyr = strPre + "stack"
  if gp.Exists(OutLyr): gp.Delete(OutLyr)

  GPMsg("t","Resample...")
  tmpGrid = "xxsamp"
  gp.Resample(ProcGrid,tmpGrid,ProcCell)

  # create a raster layer (for safer map algebra)
  lyrSamp = "lyrSamp"
  gp.MakeRasterLayer(tmpGrid,lyrSamp)

  GPMsg("t","Writing percent grids to %s..." % PctRasterPath)

  # Create map algebra expression
  # Convert cells to 0,100,NoData (percent will be mean)
  #  NoDataValue not specified:
  #    "con(lyrSamp eq <cat>,100,0)"
  #  NoDataValue specified:
  #  "con(setnull(lyrSamp eq <nodata,lyrSamp) eq <cat>,100,0)"
  if NoDataValue == "":
    MapExpr = lyrSamp
  else:
    MapExpr = "setnull(%s eq %s, %s)" % (lyrSamp, NoDataValue,lyrSamp)
  MapExpr = "con(%s eq %s,100,0)" % (MapExpr,"%s")
  # optionally round the resulting percent
  if RoundPercents:
    MapExpr = "int(%s + 0.5)" % MapExpr

  # So aggregate will work right:
  gp.Cellsize = "MAXOF"

  tmpGrid2 = "xxras"

  k = 0
  numCat = len(lstCat)
  for Cat in lstCat:
    OutGrid = lstGrid[k]
    # convert to 0,100
    gp.SingleOutputMapAlgebra_sa(MapExpr % Cat,tmpGrid2)
    # Aggregate to percent grid using mean (average of 0,100 over cell)
    gp.Aggregate_sa(tmpGrid2,OutGrid,CellFactor,
                    "MEAN",extentHandling,ignoreNoData)
    GPMsg("t","Created %s (%s/%s)" % (OutGrid,k+1,numCat))
    k += 1

  # clean up any left over grids (10.0 bug with SOMA?)
  tempRasters = gp.ListRasters("g_g*")
  for k in tempRasters:
    gp.Delete(k)

  # create grid stack that includes all the output grids
  # can't do this if there is a space in the pathname
  try:
    strStack = "gridstk"
    strExpr = "MAKESTACK %s LIST %s" % \
        (strStack, " ".join(lstGrid).lower())
    gp.MultiOutputMapAlgebra(strExpr)
    GPMsg("Created grid stack dataset: %s" % \
          os.path.join(PctRasterPath,strStack))
  except:
    GPMsg("w","Could not create grid stack dataset in %s" % gp.Workspace)

except MsgError, xmsg:
  GPMsg("e",str(xmsg))
except GPError:
  GPMsg("e",str(traceback.format_exc()).strip())
  numMsg = gp.MessageCount
  for i in range(0, numMsg):
    GPMsg("Return",i)
except:
  GPMsg("e",str(traceback.format_exc()).strip())
finally:
  for f in [tmpSnap,lyrSamp,tmpGrid,tmpGrid2]:
    try:
      if f: gp.Delete(f)
    except Exception, xmsg:
      if gp.Exists(f):
        GPMsg("w", str(gp.GetMessages(2)))
