"""
ArcGIS Script Tool - Tabulate Weight Table
"""
# Import system modules
import sys
import os
import traceback

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName

# Create the Geoprocessor object
gp = nact.getGP(9.3,"spatial")

def RunTool():
    # Get arguments
  numArgs = 8
  argv = tuple([gp.GetParameterAsText(i) for i in range(numArgs)])
  TabulateWeightTable(*argv)

def TabulateWeightTable(Weight_table, CaseField, CatField, CatFieldName, ValueField,
        OutTable, CalcPercent="true", ScaleFactor=1):
  """Tablulate Weight Table tool

  arguments

    Weight_table - input weight table
    CaseField = case field (AREAID)
    CatField -
    CatFieldName -
    ValueField -
    OutTable -
    CalcPercent -
    ScaleFactor -
  """
  try:

    nact.SetProduct("ArcInfo") # need ArcInfo license
    gp.Toolbox = "management"

    # initialize variables for cleanup at end
    [tvFrq,tvOutTbl,tmpTbl0,tmpTbl1,tmpWS] = [None] * 5

    CalcPercent = bool(str(CalcPercent).lower() in ["true","percent"])

    try:
      ScaleFactor = float(ScaleFactor)
    except:
      ScaleFactor = 1.0

    # workspace environment
    CWS = gp.Workspace       # save current
    SWS = gp.ScratchWorkspace
    tmpWS = ScratchName("",".gdb","workspace")
    gp.CreateFileGDB(os.path.dirname(tmpWS),
                       os.path.basename(tmpWS))
    gp.Workspace = tmpWS
    gp.ScratchWorkspace = tmpWS

    tmpTbl0 = ScratchName("xx0","","table")
    tmpTbl1 = ScratchName("xx1","","table")

    GPMsg("Summarizing rows...")
    gp.Frequency(Weight_table,tmpTbl0,"%s;%s" % (CatField,CaseField),ValueField)

    if CatFieldName != "#":
      lstFld = gp.Describe(Weight_table).Fields
      lstFN = [Field.Name for Field in lstFld]
      CatFieldType = lstFld[lstFN.index(CatField)].Type
      if CatFieldType == "String":
        gp.AddField(tmpTbl0,CatFieldName,"TEXT","#","#",15)
      else:
        gp.AddField(tmpTbl0,CatFieldName,"LONG")
      gp.CalculateField(tmpTbl0,CatFieldName,"[%s]" % CatField)
      CatField = CatFieldName

    if ScaleFactor <> 1:
      GPMsg("Scaling data values...")
      gp.CalculateField(tmpTbl0,ValueField,
                        "[%s] * %s" % (ValueField,ScaleFactor))

    # sum values
    # CaseField is first so the fields will come out sorted in pivot table
    gp.Frequency(tmpTbl0,tmpTbl1,CaseField,ValueField)

##    if gp.GetInstallinfo("desktop")["Version"] != "10.1":
##      try:
##        gp.AddIndex(tmpTbl1,CaseField,"CASE") # this tool is picky
##      except:
##        pass

    if CalcPercent:
      GPMsg("Calculating percents...")
      # convert values to percents
      tvFrq = "tvFrq"
      gp.MakeTableView(tmpTbl0,tvFrq)
      gp.AddJoin(tvFrq,CaseField,tmpTbl1,CaseField)
      Pre0 = (os.path.basename(tmpTbl0))
      Pre1 = (os.path.basename(tmpTbl1))
      strExpr = "100.0 * [%s.%s] / [%s.%s]" % (Pre0,ValueField,Pre1,ValueField)
      gp.CalculateField(tvFrq,"%s.%s" % (Pre0,ValueField),strExpr)
      gp.RemoveJoin(tvFrq,os.path.basename(tmpTbl1))

    # run pivot table
    GPMsg("Pivot table...")
    gp.PivotTable(tmpTbl0,CaseField,CatField,ValueField,OutTable)

    SumField = gp.ValidateFieldName("SUM_" + ValueField,
                                    os.path.dirname(OutTable))
    gp.AddField(OutTable,SumField,"DOUBLE")
    tvOutTbl = "tvOutTbl"
    OutTblName = os.path.splitext(gp.Describe(OutTable).Name)[0]
    if gp.Describe(OutTable).DataType == "ArcInfoTable":
      psep = ":"
    else:
      psep = "."
    JoinTblName = gp.Describe(tmpTbl1).Name
    gp.MakeTableView(OutTable,tvOutTbl)
    gp.AddJoin(tvOutTbl,CaseField,tmpTbl1,CaseField)
    gp.CalculateField(tvOutTbl,
                      "%s%s%s" % (OutTblName,psep,SumField),"[%s.%s]" % \
                       (JoinTblName,ValueField))
    gp.RemoveJoin(tvOutTbl,JoinTblName)

  except MsgError, xmsg:
    GPMsg("e",str(xmsg))
  except GPError:
    GPMsg("e",str(traceback.format_exc()).strip())
    numMsg = gp.MessageCount
    for i in range(0, numMsg):
      GPMsg("Return",i)
  except:
    GPMsg("e",str(traceback.format_exc()).strip())
  finally:
    try:
      del Row,Rows
    except:
      pass
    for f in [tvFrq,tvOutTbl,tmpTbl0,tmpTbl1,tmpWS]:
      try:
        if f: gp.Delete(f)
      except:
        pass
    if gp.Exists(tmpWS):
      GPMsg("w", "Could not delete %s" % tmpWS)

if __name__ == "__main__":
  RunTool()