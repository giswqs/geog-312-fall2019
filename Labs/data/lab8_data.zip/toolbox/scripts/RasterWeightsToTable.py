"""
ArcGIS Script Tool - Raster Weights To Table

"""
# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc; gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName

# tmp dataset names (for easier cleanup later)
lyrAR,lyrWR,lyrZR,lyrCR,tvRAT, \
  tmpRaster1,tmpRAT,tmpSum,tmpOut, \
  tmpFGDB,tmpWS =\
  [None] * 11

# Create the Geoprocessor object w/ Spatial Analyst license
gp = nact.getGP(9.3,"spatial")

try:

  nact.SetProduct("ArcInfo") # need ArcInfo license

  # Environment
  gp.Toolbox = "management"
  gp.OverwriteOutput = 1
  gp.QualifiedFieldNames = False
  gp.LogHistory = False

  # Script arguments

  # Input geodataset (feature class or raster data set)
  inputRaster = gp.GetParameterAsText(0)
  dInput = gp.Describe(inputRaster)

  # Area ID field
  IDField = gp.GetParameterAsText(1).upper()
  # find datatype of IDField
  try:
    lstFields = gp.ListFields(inputRaster,IDField)
  except:
    IDField = None
    lstFields = None
  if lstFields:
    IDFieldType = lstFields[0].Type
    IDFieldLen = lstFields[0].Length
  else:
    IDField = None
    IDFieldType = None

  # Weight raster
  weightRaster = gp.GetParameterAsText(2)
  lyrWR = "lyrWR"
  gp.MakeRasterLayer(weightRaster,lyrWR)

  # Output table
  strOutTable = gp.GetParameterAsText(3)

  # missing value code for nodata areas
  strMissingValueCode = gp.GetParameterAsText(4)
  try:
    NDCode = int(strMissingValueCode)
  except:
    NDCode = 9999

  # Zone Raster (optional - raster layer)
  zoneRaster = gp.GetParameterAsText(5)
  try:
    lyrZR = "lyrZR"
    gp.MakeRasterLayer(zoneRaster,lyrZR)
    dZR = gp.Describe(zoneRaster)
    ZRCell = dZR.MeanCellHeight
    ZRaster = dZR.CatalogPath
  except:
    zoneRaster = None

  strOutputIDField = "AREAID"

  # workspace environment
  CWS = gp.Workspace       # save current workspace environment
  SWS = gp.ScratchWorkspace

  # work in a folder (GRIDs are fastest)
  tmpWS = ScratchName("xxwk","","workspace")
  os.mkdir(tmpWS)

  gp.Workspace = tmpWS
  gp.ScratchWorkspace = tmpWS
  # set up a file geodatabase for features
  tmpFGDB = os.path.join(tmpWS,"work.gdb")
  gp.CreateFileGDB(tmpWS,"work.gdb")
  # use memory workspace for small temp files (fast)
  memWS = "in_memory"

  # do some describes

  dWR = gp.Describe(weightRaster)
  WRName = os.path.basename(dWR.CatalogPath)

  # output coordinate system
  gp.ClearEnvironment("OutputCoordinateSystem")
  IRSR = dInput.SpatialReference
  WRSR = dWR.SpatialReference
  if IRSR.Name == "Unknown": GPMsg("w","ID 522 %s" % inputRaster)
  if WRSR.Name == "Unknown":
    GPMsg("w","ID 522 %s" % weightRaster)
  else:
    if IRSR.Name != "Unknown":
      if not nact.CompareSR(IRSR,WRSR):
        GPMsg("%s\n%s\n" % (IRSR.ExportToString(),WRSR.ExportToSTring()))
        raise MsgError, \
              "Inputs have different coordinate systems:\n" + \
              "  %s\n  %s" %\
              (IRSR.Name,WRSR.Name)
    gp.OutputCoordinateSystem = WRSR
  if zoneRaster:
    ZRSR = dZR.SpatialReference
    if ZRSRName  == "Unknown":
      GPMsg("w","ID 522 %s" % zoneRaster)
      if WRSR.Name != "Unknown":
        if not nact.CompareSR(WRSR,ZRSR):
          raise MsgError, \
              "Inputs have different coordinate systems:\n" + \
              "  %s\n  %s" %\
                (WRSR.Name,ZRSR.Name)

  # Create weight raster table view (for weight raster calculations)
  tvWRRAT = "tvWRRAT"
  try:
    gp.MakeTableView(lyrWR,tvWRRAT)
  except:
    GPMsg("w","Building raster attributes for %s..." % WRaster)
    try:
      gp.BuildRasterAttributeTable(lyrWR)
      gp.MakeTableView(lyrWR,tvWRRAT)
    except:
      raise MsgError, "Could not build raster attribute table for " + lyrWR

  # zone raster must be integer
  if zoneRaster:
    if not dZR.IsInteger:
      raise MsgError, "Zone_raster must be integer"


  # set up environment

  gp.Toolbox = "management"
  gp.OverwriteOutput = True

  # set up input area layer
  FPData = inputRaster

  # Raster processing environment

  try:
    # if processing cell size explicitly set in environment, use it
    ProcCell = float(gp.CellSize)
    GPMsg("w","Using environment Cell Size: %s" % ProcCell)
  except:
    # otherwise, use cell size of weight raster
    ProcCell = dWR.MeanCellHeight
    CellRaster = weightRaster
    GPMsg("Using Cell Size of \"%s\" (%s)" % (CellRaster,ProcCell))
  gp.CellSize = ProcCell

  if gp.SnapRaster:
    GPMsg("w","Using environment Snap Raster: \"%s\"" % gp.SnapRaster)
  else:
    gp.SnapRaster = weightRaster
    GPMsg("Raster snapping to %s" % gp.SnapRaster)

  # Extent
  gp.Extent = nact.GetExtent(FPData)

  # Coarse sampling check
  nact.CheckRasterExtent(gp.Extent, ProcCell)
  # set the extent the feature area plus 1 cell
  # to insure all area is processed
  gp.Extent = nact.GetExtent(FPData,ProcCell)

  # Mask
  gp.Mask = inputRaster

  gp.Toolbox = "sa"
  # Set up VALUE for overlay
  tmpRaster1 = ScratchName("xxb","","grid")
  if not IDField:
    # "dissolve" to single value grid
    gp.CreateConstantRaster(tmpRaster1,1)
    # replace ARaster
    ARaster = tmpRaster1
  elif IDField != "VALUE":
    gp.Lookup(inputRaster,IDField,tmpRaster1)
    # replace ARaster
    ARaster = tmpRaster1
  else:
    ARaster = inputRaster

  try:
    gp.BuildRasterAttributeTable(ARaster)
  except:
    raise MsgError, "Could not build raster table for mask " + ARaster

  gp.Toolbox = "management"

  # make raster layers for map algebra
  # (SOMA can break on dataset path)
  lyrWR = "lyrWR"
  gp.MakeRasterLayer(weightRaster,lyrWR)
  lyrAR = "lyrAR"
  gp.MakeRasterLayer(ARaster,lyrAR)

  # create grid expressions for combine()
  if not zoneRaster:
    # use input raster for zone raster
    # replace NoData with NDCode
    PRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,NDCode,lyrAR)
    WRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,NDCode,lyrWR)
    CombExpr = "combine(%s,%s)" % (PRExpr,WRExpr)
  else:
    # use input raster for areaid raster
    # use zone raster for partition raster
    # Replace nodata with our NoData code
    PRExpr = "con(isnull(%s),%s,%s)" % (lyrZR,NDCode,lyrZR)
    WRExpr = "con(isnull(%s),%s,%s)" % (lyrWR,NDCode,lyrWR)
    CombExpr = "combine(%s,%s,%s)" % (lyrAR,PRExpr,WRExpr)

  tmpCombRaster = ScratchName("xxcmb1","","grid")

  gp.Toolbox = "sa"
  gp.SingleOutputMapAlgebra(CombExpr,tmpCombRaster)
  gp.BuildRasterAttributeTable(tmpCombRaster) # ensure COUNT gets populated

  # done raster processing; clean up
  gp.ClearEnvironment("Extent")
  gp.ClearEnvironment("Mask")

  gp.Toolbox = "management"

  # make a raster layer
  lyrCR = "lyrCR"
  gp.MakeRasterLayer(tmpCombRaster,lyrCR)
  # find field names in the combine output table
  #  VALUE, COUNT, <AFIELD>, <WFIELD>
  CFields = gp.Describe(lyrCR).Fields
  CFNames = [k.Name.upper() for k in CFields]
  CFNames = CFNames[CFNames.index("COUNT") + 1:]
  if zoneRaster:
    AField = CFNames[0]
    ZField = CFNames[1]
    WField = CFNames[2]
  else:
    AField = CFNames[0]
    WField = CFNames[1]

  # check whether there was any overlap at all
  Result = gp.GetRasterProperties(lyrCR,"UNIQUEVALUECOUNT")
  CombRows = int(Result.GetOutput(0))

  gp.Toolbox = "management"

  if CombRows > 0:
    # copy VAT to temp table
    tvRAT = "tvRAT"
    gp.MakeTableView(lyrCR,tvRAT)
    tmpRAT = ScratchName("tmpRAT","","table",memWS)
    gp.CopyRows(tvRAT,tmpRAT)

    # recreate layer pointing to scratch
    gp.MakeTableView(tmpRAT,tvRAT)
    # add fields for our output weight table
    # AREAID data type depends on input data type
    if IDField: Alias = "#"
    else: Alias = IDField
    if IDFieldType == "String":
      gp.AddField(tvRAT,"AREAID","TEXT","#","#","32",Alias)
    else:
      gp.AddField(tvRAT,"AREAID","LONG","#","#","#",Alias)

    gp.AddField(tvRAT,"ZONE","LONG")
    gp.AddField(tvRAT,"WTZONE","LONG")
    gp.AddField(tvRAT,"NCELLS","LONG")
    gp.AddField(tvRAT,"AREA","DOUBLE")
    gp.AddField(tvRAT,"AREAF","DOUBLE")
    gp.AddField(tvRAT,"WAREA","DOUBLE")
    gp.AddField(tvRAT,"WAREAF","DOUBLE")
    gp.MakeTableView(tmpRAT,tvRAT) # refresh with new columns

    # populate ID field
    if IDFieldType == "String":
      gp.AddJoin(tvRAT,AField,lyrAR,"VALUE")
      # layer name was coming up funny (raster to raster join?)
      # so find name just by searching with listFields
      rIDField = gp.ListFields(tvRAT,"*:" + IDField)[0].Name
      gp.CalculateField(tvRAT,"AREAID", "[%s]" % (rIDField))
      gp.MakeTableView(tmpRAT,tvRAT)     # remove join
    else:
      gp.CalculateField(tvRAT,"AREAID", "[%s]" % AField)

    # Populate other fields
    if zoneRaster:
      gp.CalculateField(tvRAT,"ZONE", "[%s]" % ZField)
    else:
      gp.CalculateField(tvRAT,"ZONE", "[%s]" % AField)
    gp.CalculateField(tvRAT,"WTZONE", "[%s]" % WField)
    gp.CalculateField(tvRAT,"NCELLS","[%s]" % "COUNT")

    # calculate cell areas
    CombCellSize = float(gp.Describe(tmpCombRaster).MeanCellHeight)
    CellArea = CombCellSize ** 2
    WRCellArea = float(dWR.MeanCellHeight) ** 2
    # calculate/populate areas
    gp.CalculateField(tvRAT,"AREA", "[COUNT] * %s" % CellArea)

    # calculate percents
    tmpFrq = ScratchName("xxfrq","","table",tmpFGDB)
    gp.Statistics(tvRAT,tmpFrq,"AREA SUM","AREAID")
    gp.AddJoin(tvRAT,"AREAID",tmpFrq,"AREAID")
    RATName = os.path.basename(tmpRAT)
    FrqName = os.path.basename(tmpFrq)
    # reselect so we don't try to divide by zero
    strExpr = "\"%s.SUM_AREA\" > 0" % FrqName
    gp.SelectLayerByAttribute(tvRAT,"#",strExpr)
    gp.CalculateField(tvRAT,
      "AREAF","[%s.AREA] / [%s.SUM_AREA]" % (RATName,FrqName))
    gp.RemoveJoin(tvRAT,FrqName)
    gp.SelectLayerByAttribute(tvRAT,"CLEAR_SELECTION")
    gp.Delete(tmpFrq)

    # calculate weight zone AREAF, AREA
    gp.AddJoin(tvRAT,WField,weightRaster,"VALUE")

    # determine COUNT field name
    WRName =  dWR.Name
    # remove .dbf extension if there (file image formats)
    WRName = os.path.splitext(WRName)[0]

    if dWR.Format == "GRID":
      CtField = "%s.vat:COUNT" % WRName
    else:
      # image formats
      CtField = "%s.vat.COUNT" % WRName
    # fgdb/arcsde raster - "VAT_name.COUNT"
    if not gp.ListFields(tvRAT,CtField):
      CtField = "VAT_%s.COUNT" % WRName

    strExpr = "[%s] * %s" % (CtField ,WRCellArea)
    gp.CalculateField(tvRAT,"WAREA", strExpr)
    gp.MakeTableView(tmpRAT,tvRAT) # remove join

    # calculate percent of weight zone areas
    # First, reselect so we don't divide by zero
    strExpr = "\"WAREA\" > 0"
    gp.SelectLayerByAttribute(tvRAT,"#",strExpr)
    gp.CalculateField(tvRAT,"WAREAF","[AREA] / [WAREA]")
    gp.SelectLayerByAttribute(tvRAT,"CLEAR_SELECTION")

  # save our results
  # create a table in with the fields in the order we want
  # (in_memory for fast table creation)
  tmpOut = ScratchName("tmpOut","","table",memWS)
  gp.CreateTable(memWS,os.path.basename(tmpOut),tmpRAT)
  # drop the first few fields
  FFields = gp.Describe(tmpOut).Fields
  FFNames = [k.Name.upper() for k in FFields]
  FFirst = FFNames.index("AREAID")
  DropFields = ";".join(FFNames[1:FFirst])
  if DropFields: gp.DeleteField(tmpOut,DropFields)

  # Append rows to temporary table (only the fields we need will copy)
  gp.Append(tmpRAT,tmpOut,"NO_TEST")

  gp.Delete(lyrCR)
  gp.Delete(tmpCombRaster)

  # create output table
  gp.CreateTable(os.path.dirname(strOutTable),\
               os.path.basename(strOutTable),tmpOut)
  # load into a sorted layer, and push to disk!
  strSort =  "%s a;%s a;%s a" % ("AREAID","ZONE","WTZONE")
  IRows = gp.SearchCursor(tmpOut,"","","",strSort)
  ORows = gp.InsertCursor(strOutTable)
  IRow = IRows.next()
  while IRow:
    ORows.InsertRow(IRow)
    IRow = IRows.Next()
  del IRow,IRows,ORows

except MsgError, xmsg:
  GPMsg("e",str(xmsg))
except GPError:
  GPMsg("e",str(traceback.format_exc()).strip())
  numMsg = gp.MessageCount
  for i in range(0, numMsg):
    GPMsg("Return",i)
except:
  GPMsg("e",str(traceback.format_exc()).strip())
finally:
  for f in [lyrAR,lyrWR,lyrZR,lyrCR,tvRAT,
            tmpRaster1,tmpRAT,tmpSum,tmpOut,tmpFGDB,tmpWS]:
    try:
      if f: gp.Delete(f)
    except:
      pass
  if gp.Exists(tmpWS):
    GPMsg("w", "Could not delete %s" % tmpWS)



