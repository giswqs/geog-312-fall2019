"""
ArcGIS Script Tool - Tabulate FeaturesTo Percent

"""
# Import system modules
import sys
import os
import traceback

# enable garbage collection
import gc; gc.enable()

# ArcGIS geoprocessing error object
from arcgisscripting import ExecuteError as GPError

# import utilities (in same folder as this script)
import nact
from nact import GPMsg, MsgError, ScratchName

from FeatureWeightsToTable import FeatureWeightsToTable
from TabulateWeightTable  import TabulateWeightTable

gp = nact.getGP(9.3,"spatial")

def RunTool():
    # Script arguments

    # Feature Class to use as source
    # can be a layer or dataset
    zoneFeatures = gp.GetParameterAsText(0)

    # Field to identify each feature
    zoneField = gp.GetParameterAsText(1).upper()

    # Category Raster
    catRaster = gp.GetParameterAsText(2)

    # output table
    outTable = gp.GetParameterAsText(3)

    # Buffer distance (only used if features overlap)
    bufDist = gp.GetParameterAsText(4)

    # missing value code for nodata areas
    NDCode = gp.GetParameterAsText(5)
    try:
        NDCode = int(NDCode)
    except:
        NDCode = None

    # Features overlap?
    featuresOverlap = gp.GetParameterAsText(6) == "true"

    # area scale value for total
    try:
        areaScale = float(gp.GetParameterAsText(7))
    except:
        areaScale = None

    TabulateFeaturesToPercent(zoneFeatures,zoneField,catRaster,outTable,
                              bufDist,NDCode,featuresOverlap,areaScale)

def TabulateFeaturesToPercent(zoneFeatures,zoneField,catRaster,outTable,
                              bufDist=None,NDCode=9999,featuresOverlap=False,
                              areaScale=1.0):
    try:

        nact.SetProduct("ArcInfo") # need ArcInfo license

        tmpTable = ScratchName("","","table")

        # If output workspace is a folder, add .dbf extension
        # (INFO tables are not supported if spaces in path)
        outPath = os.path.dirname(tmpTable)
        if gp.Describe(outPath).DataType == "Folder":
            tmpTable += ".dbf"

        GPMsg("Feature Weights To Table...")
        FeatureWeightsToTable(zoneFeatures,zoneField,catRaster,tmpTable,\
                              bufDist,NDCode,"",featuresOverlap)

        if gp.GetMessages(2):
            GPMsg("e","Feature Weights to Table failed")
            raise GPError

        GPMsg("Tabulate Weight Table...")

        TabulateWeightTable(tmpTable,"AREAID","WTZONE","PCT_",
                            "AREA",outTable,"PERCENT",areaScale)

        if gp.GetMessages(2):
            GPMsg("e","Tabulate Weight Table failed")
            raise GPError

    except MsgError, xmsg:
        GPMsg("e",str(xmsg))
    except GPError:
        GPMsg("e",str(traceback.format_exc()).strip())
        numMsg = gp.MessageCount
        for i in range(0, numMsg):
            GPMsg("Return",i)
    except:
        GPMsg("e",str(traceback.format_exc()).strip())
    finally:
        try:
            gp.Delete(tmpTable)
        except:
            pass


if __name__ == "__main__":
    RunTool()
