
******************************************************************************
NACT TEST VERSION -- please send comments to cprice@usgs.gov
******************************************************************************

readme.txt 

This is release 2.0 he National Water-Quality Assessment (NAWQA) 
Area-Characterization Toolbox. These tools are designed to be accessed 
using ArcGIS Desktop software (versions 9.3, 10.0, and 10.1). The toolbox is 
composed of a collection of custom tools that implement geographic 
information system (GIS) techniques used by the NAWQA Program to 
characterize aquifer areas, drainage basins, and sampled wells. 

These tools are built on top of standard functionality included in 
ArcGIS Desktop running at the ArcInfo license level. Most of the tools 
require a license for the ArcGIS Spatial Analyst extension. 

ArcGIS is a commercial GIS software system produced by Esri, Inc. 
(http://www.esri.com). The NAWQA Area-Characterization Toolbox is not 
supported by Esri, Inc. or its technical support staff. 

---------------------------------------------------------------------
Any use of trade, product, or firm names is for descriptive purposes 
only and does not imply endorsement by the U.S. Government. 
---------------------------------------------------------------------

SUPPORT

You are welcome to send questions or comments about this report to the 
author, Curtis V. Price, by email: 

mailto:cprice@usgs.gov 

For more information about the National Water-Quality Assessment 
Program, program, visit the NAWQA home page at: 

http://water.usgs.gov/nawqa 

CITATION 

These tools may be cited as follows: 

Price, C. V., Nakagaki, Naomi, and Hitt, K. J., 2012, National 
Water-Quality Assessment (NAWQA) Area-Characterization Toolbox, 
Release 2.0, U.S. Geological Survey Open-File Report 2010-1268. 
[online-only]  

http://pubs.usgs.gov/of/2010/1268

DOCUMENT ACCESSIBLITY 

This software cannot be easily accessed by the visually 
impaired. If you have any questions about accessibility, 
please contact the authors. 

CONTENTS 

This distribution consists of an ArcGIS "Toolbox" file ("NACT.tbx") with 
folders and files containing associated documentation, scripts, and data 
files. Specific documentation and example usage for each tool is 
included in the toolbox file and is accessible from within ArcGIS 
desktop applications (for example, ArcMap and ArcCatalog). 

Tools in the toolbox include: 

Areal Overlay Statistics toolset:
  Feature Statistics To Table
  Footprint Statistics To Table
  Raster Statistics To Table
Areal Overlay Weights toolset:
  Feature Weights To Table
  Footprint Weights To Table
  Raster Weights To Table  
  Tabulate Features To Percent
  Tabulate Footprints To Percent
Areal Overlay Weights Analysis toolset:
  Calculate Weighted Statistics 
  Partial Area Weights
  Tabulate Weight Table
Point Overlay toolset:
  Point Overlay Polygon To Table
  Point Overlay Raster To Table
Selection and Area Processing toolset:
  Aggregate Raster to Percent Grids
  Shrink Polygon Area
  Weed Points

CHANGES IN VERSION 2.0

- All tools now are supported for ArcGIS 9.3, 10, and 10.1
- Improved tool dialogs and tool documentation
- Numerous bug fixes and performance improvements
- The functionality of the Area Statistics To Table and Area Weights To 
  Table tools for feature inputs have been incorporated into the Feature 
  Statistics and Feature Weights tools. For raster inputs, the new Raster 
  Statistics and Raster Weights tools have been added.  
- The Feature Statistics and Feature Weights tools now process all 
    features at once by default. If you need to process input features
    one-at-a-time to avoid errors from overlapping input features, the
    argument "OVERLAP" must be specified.
- A new argument ("Group field") for the Feature Statistics To Table and 
  Feature Weights To Table tools allow groups of non-overlapping features 
  to be processed together. This is done to optimize processing speed.
- The Tabulate Footprints to Percent and Tabulate Weights
    To Percent tools have been moved from the Selection and
    Area Processing toolset to the Areal Overlay Weights toolset.
- The Weed Points tool now has an additional argument to allow the user to
    drop non-selected points from the output dataset.

INSTALLATION INSTRUCTIONS 

1. Download the archive file "NACT.zip" to your computer.

2. In a selected folder (for example, "C:\Tools"), unzip the downloaded 
file "NACT.zip."  This will create a directory ("NACT") containing a 
collection of files and folders. 

3. You can now safely delete the zip file. 

4. At this point, you can use the toolbox in any ArcGIS desktop 
application.  For more details about accessing tools in ArcGIS,
see the ArcGIS Desktop help:

ArcGIS 9.3: Adding and removing toolboxes
http://webhelp.esri.com/arcgisdesktop/9.3/index.cfm?TopicName=Adding%20and%20removing%20toolboxes

ArcGIS 10.0: A quick tour of executing tools 
http://help.arcgis.com/en/arcgisdesktop/10.0/help/index.html#/A_quick_tour_of_executing_tools/002100000001000000/
