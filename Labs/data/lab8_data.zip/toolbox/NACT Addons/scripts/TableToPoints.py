"""Table To Points"""

import arcgisscripting
from arcgisscripting import ExecuteError as GPError
gp = arcgisscripting.create(9.3)

CodeBlock = """
def DMSToDD(dms,Flip="NOFLIP"):
    # Author: Curtis Price, http://profile.usgs.gov/cprice
    # Disclaimer: Not approved by USGS. (Provisional, subject to revision.)
    try:
        # convert dd mm ss.ss to dddmmss.sss
        Splits = [float(k) for k in str(dms).split()]
        if len(Splits) == 3:
            xdms = "%i%02i%02i" % (Splits[0],Splits[1],int(Splits[2])) +\
                   ("%g" % (Splits[2] % 1))[2:]
        elif len(Splits) == 1:
        # if we didn't have 3-tuples, just remove any spaces
            xdms = str(dms).replace(" ","")
        else:
            raise

        # okay, we have a string in the format: "ddmmss.sss"

        # calculate degrees, minutes, seconds
        xdeg = int(float(xdms) / 1e4)
        if xdeg < 0: sign = -1
        else: sign = 1
        # find degree value in xdms string
        # with that, we can get the minutes and seconds by position
        minpos = xdms.find(str(xdeg)) + len(str(xdeg))
        xmin = float(xdms[minpos:minpos+2])
        xsec = float(xdms[minpos+2:])

        # DMS triplet to decimal degrees
        dd = abs(xdeg) + xmin / 60.0 + xsec / 3600.0
        dd = dd * sign

        # flip sign if requested
        if str(Flip).lower() in ["flip","true"]:
            dd = dd * -1

        return dd

    except Exception, xmsg:
        raise Exception, "Invalid input"
"""

def XYTableToPoints(inTable,xField,yField,DMS,flipX,xyCoordinateSystem,
                     outPoints,xFieldName,yFieldName,
                     outputCoordinateSystem,geoTrans):
    gp.Toolbox = "management"
    tv = "tvTab"
    gp.MakeTableView(inTable,tv)
    lyrPoint = "lyrPoint"
    if DMS.lower() == "dms": DMS = True
    else: DMS = False
    if flipX.lower() in ["flip","true"]: flipX = True
    else: flipX = False
    try:
        tmpTab = "in_memory/xxpt"
        gp.CopyRows(inTable,tmpTab)

        try:
            gp.AddField(tmpTab,xFieldName,"DOUBLE")
            gp.AddField(tmpTab,yFieldName,"DOUBLE")
        except:
            pass
        gp.MakeTableView(tmpTab,tv)
        if DMS:
            gp.CalculateField(tv,xFieldName,
                "DMSToDD(!%s!,\"%s\")" % (xField,flipX),"PYTHON",
                CodeBlock)
            gp.CalculateField(tv,yFieldName,
                "DMSToDD(!%s!)" % (yField),"PYTHON",
                CodeBlock)
        else:
            if flipX:
                gp.CalculateField(tv,xFieldName,
                                  "-1 * float(!%s!)" % xField,"PYTHON")
            else:
                gp.CalculateField(tv,xFieldName,
                                  "float(!%s!)" % xField,"PYTHON")

            gp.CalculateField(tv,yFieldName,"float(!%s!)" % yField,"PYTHON")

        # create point layer
        gp.MakeXYEventLayer(tmpTab,xFieldName,yFieldName,
                            lyrPoint,xyCoordinateSystem)

        # Create output point feature class
        if not outputCoordinateSystem:
            # copy to output point feature class
            gp.CopyFeatures(lyrPoint,outPoints)
        else:
            gp.Project(lyrPoint,outPoints,outputCoordinateSystem,geoTrans)
        gp.Delete(lyrPoint)
        gp.Delete(tmpTab)
        try:
            gp.DeleteField(outPoints,"OBJECTID;FID_;OID_")
        except:
            pass


    except GPError:
        gp.AddError(gp.GetMessages(0))
    except Exception, xmsg:
        gp.AddError(str(xmsg))
    finally:
        try:
            gp.Delete(tmpTab)
        except:
            pass


if __name__ == '__main__':
    # Get arguments
    numArg = 11
    argv = list()
    for i in range(numArg):
        try:
            argv.append(gp.GetParameterAsText(i))
        except:
            argv.append("")
    XYTableToPoints(*argv)
