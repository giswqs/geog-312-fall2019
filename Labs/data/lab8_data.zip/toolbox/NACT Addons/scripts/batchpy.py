# example python script to run tools

# example .bat file:
#
# :: myfile.bat
# batchpy.py cover_1 out1.dbf
# batchpy.py cover_2 out2.dbf

import sys, os
try:
  # add "/point" to coverage path
  # os.path.realpath converts relative to full paths
  pointCov = os.path.realpath(sys.argv[1]) + "/point"
  outFile = os.path.realpath(sys.argv[2])
except:
  print "batchpy.py <pointcover> <outfile>"
  sys.exit()

Here = os.path.realpath(".")

import arcgisscripting
gp = arcgisscripting.create()
gp.Workspace = Here
gp.ScratchWorkspace = Here

# use variables for easy editing
Area_ID_Field = "STAID"
weightRaster = "D:/work/co1990g"
zoneRaster = "D:/work/nlcde_all"

try:
  # Add the NACT toolbox
  gp.AddToolbox(r"D:\nact_test_20110315\NACT.tbx")
  # Run the Feature Weights To Table tool
  gp.FeatureWeightsToTable_nact(pointCov,Area_ID_Field,weightRaster, \
    outFile,"500 Meters","99",zoneRaster)
  gp.AddMessage(gp.GetMessages(0))
except Exception, xmsg:
  gp.AddError(gp.GetMessages(0))
  raise Error, "script failed"
