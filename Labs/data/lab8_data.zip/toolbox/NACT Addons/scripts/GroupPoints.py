"""
ArcGIS Script Tool - Group Points
"""

# Import system modules
import sys, string, os

# arcgis module
import arcgisscripting
from arcgisscripting import ExecuteError as GPError

# add nact.py module
Here = os.path.dirname(sys.argv[0])
sys.path.append(os.path.join(Here,"../scripts"))
import nact
from nact import GPMsg, MsgError, ScratchName, CountRows

# Create the Geoprocessor object
gp = nact.getGP(9.3,"spatial")

tmpFGDB, tmpPoints, distTable, tmp1, tmp2, lyrPnt = [None] * 6

try:

  gp.Toolbox = "management"
  gp.OverwriteOutput = True
  WKenv = gp.Workspace
  gp.LogHistory = False
  gp.AddToolbox(os.path.join(Here,"../NACT.tbx"))

  inputPoints = gp.GetParameterAsText(0)
  dscInput = gp.Describe(gp.Describe(inputPoints).CatalogPath)

  outputPoints = gp.GetParameterAsText(1)

  groupDistance = gp.GetParameterAsText(2)
  if groupDistance == "#":
    Ext = dscInput.Extent
    groupDistance = \
      0.25 * max(Extent.YMax - Extent.YMin,Extent.XMax - Extent.XMin)
  GPMsg("w","Using Grouping distance: %s..." % groupDistance)

  try:
    maxGroup = int(gp.GetParameterAsText(3))
  except:
    maxGroup = 25

  # get processing coordinate system from environment
  CS = gp.OutputCoordinateSystem
  # if not set, use input dataset's coordinate system
  if not CS:
    CS = dscInput.SpatialReference
    if CS.Name == "Unknown":
      GPMsg("w","ID 522 %s" % inputPoints)
  elif CS.Type != "Projected":
    GPMsg("w","ID 981 distance")  # decimal degrees inappropriate

  if WKenv:
    if os.path.splitext(WKenv)[1].find("gdb") > -1:
      gp.Workspace = os.path.dirname(WKenv)
      gp.ScratchWorkspace = gp.Workspace

  # set up a file geodatabase for our tables
  tmpFGDB = ScratchName("",".gdb","workspace")
  gp.CreateFileGDB(os.path.dirname(tmpFGDB),os.path.basename(tmpFGDB))
  gp.Workspace = tmpFGDB
  memWS = "in_memory"

  tmpPoints = "in_memory/wrkPoints"
  tmpExtentPt = "in_memory/extPoints"

  gp.CopyFeatures(inputPoints,tmpPoints)
  lyrPnt = "lyrPnt"
  gp.MakeFeatureLayer(tmpPoints,lyrPnt)
  numPoints = nact.CountRows(lyrPnt)

  gp.AddField(lyrPnt,"GRP","LONG")
  gp.AddField(lyrPnt,"GRPC","LONG")
  gp.CalculateField(lyrPnt,"GRP","-1")
  # tag "loners" (nothing within tolerance)
  GPMsg("Initializing group tags...")
  gp.Near_analysis(lyrPnt,lyrPnt,groupDistance)
  gp.SelectLayerByAttribute(lyrPnt,"#","NEAR_FID = -1")
  gp.CalculateField(lyrPnt,"GRP","0")
  # tag points to be grouped with -1
  gp.SelectLayerByAttribute(lyrPnt,"SWITCH_SELECTION")
  gp.CalculateField(lyrPnt,"GRP","-1")
  gp.DeleteField(lyrPnt,"NEAR_FID;NEAR_DIST")

  # start grouping
  GPMsg("Grouping points...")
  group = 1 # first group is Group 1

  # get FID of first feature
  OIDField = gp.ListFields(lyrPnt,"#","OID")[0].Name
  Rows = gp.SearchCursor(lyrPnt)
  Row = Rows.Next()
  if Row:
    FirstFID = Row.GetValue(OIDField)
  else:
    FirstFID = None
  del Row, Rows

  while FirstFID:
    # select first untagged point
    gp.SelectLayerByAttribute(lyrPnt,"#","%s = %s" % (OIDField,FirstFID))
    numSelect = CountRows(lyrPnt)
    lastSelect = -1
    # add points within group distance until no more found
    k = 0 # count iterations
    while numSelect != lastSelect and k < maxGroup:
      lastSelect = numSelect
      gp.SelectLayerByLocation(lyrPnt,"WITHIN_A_DISTANCE",
                    "#",groupDistance,"ADD_TO_SELECTION")
      # count selected
      numSelect = CountRows(lyrPnt)
      k += 1
    # we have a group now, tag it
    gp.CalculateField(lyrPnt,"GRP",str(group))
    # get next group
    gp.SelectLayerByAttribute(lyrPnt,"SWITCH_SELECTION")
    gp.SelectLayerByAttribute(lyrPnt,"#","GRP = -1")
    # get FID of first selected feature
    Rows = gp.SearchCursor(lyrPnt)
    Row = Rows.Next()
    if Row:
      FirstFID = Row.GetValue(OIDField)
    else:
      FirstFID = None
    del Row,Rows
    group += 1
  group = group - 1
  GPMsg("%5s point groups" % group)
  gp.SelectLayerByAttribute(lyrPnt,"#","GRP = 0")
  numLoners = CountRows(lyrPnt)
  GPMsg("%5s points with no neighbors within group distance" % numLoners)
  gp.CalculateField(lyrPnt,"GRP","[%s] * -1" % OIDField)
  gp.SelectLayerByAttribute(lyrPnt,"CLEAR_SELECTION")

  # retag groups with unique, sequential IDS
  gp.MakeFeatureLayer(tmpPoints,lyrPnt) # refresh layer
  tmp1 = os.path.join(memWS,"XYList1")
  tmp1Name = "XYList1"
  OIDField = gp.ListFields(lyrPnt,"#","OID")[0].Name
  gp.Statistics_analysis(lyrPnt,tmp1,"%s COUNT" % OIDField,"GRP")
  gp.AddJoin(lyrPnt,"GRP",tmp1,"GRP")
  gp.CalculateField(lyrPnt,"GRPC","[%s.FREQUENCY]" % tmp1Name)
  gp.CalculateField(lyrPnt,"GRP","[%s.%s] + 1" % (tmp1Name,OIDField))
  gp.RemoveJoin(lyrPnt,tmp1Name)

  gp.CopyFeatures(lyrPnt,outputPoints)

except MsgError, xmsg:
  GPMsg("Error",str(xmsg))
except GPError:
  line, file, err = nact.TraceInfo()
  GPMsg("Error","Geoprocessing error on %s of %s:" % (line,file))
  GPMsg("Error",str(gp.GetMessages(0)))
except:
  line, file, err = nact.TraceInfo()
  GPMsg("Error","Python error on %s of %s" % (line,file))
  GPMsg("Error",err)
finally:
  try:
    del Row, Rows
  except:
    pass
  # delete layer and datasets
  for f in [lyrPnt, tmpPoints, distTable, tmp1, tmp2,  tmpFGDB]:
    try:
      if f: gp.Delete(f)
    except Exception, xmsg:
      if gp.Exists(f):
        GPMsg("w", str(gp.GetMessages(2)))




