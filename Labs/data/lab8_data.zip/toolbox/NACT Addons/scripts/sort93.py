# Name:         Sort93
# Purpose:      Sort features or tables, like 10.0 Sort_management tool
# Author:       cprice@usgs.gov
# Created:      02/15/2012 10:54:53
# Environment:  ArcGIS 9.3, Python 2.5

import os
import sys
import traceback
import arcgisscripting
from arcgisscripting import ExecuteError as GPError
gp = arcgisscripting.create(9.3)

def RunSort93():
    """Run Sort93 from script tool interface"""
    table = gp.getParameterAsText(0)
    outputDS = gp.getParameterAsText(1)
    # put into format "field1 ascending; field2 descending ... "
    sorts = []
    for k in [2,4,6]:
        try:
            sortField = gp.getParameterAsText(k)
            sortType = gp.getParameterAsText(k+1)
            if not sortType: sortType = "ASCENDING"
            if sortField:
                sorts.append("%s %s" % (sortField,sortType))
            else:
                break
        except:
            break
    sortFields = ";".join(sorts)

    # Run the tool
    Sort93(table,outputDS,sortFields)


def Sort93(table,outputDS,sortFields):
    """Do a sort of a feature class or table in ArcGIS 9.3

    arguments

      table - input table view or feature class

      outputDS - output dataset

      sortFields - (text) fields to sort (up to 3) in the form:
        "field1 ASCENDING; field2 DESCENDING ..."

    This tool is superseded by the ArcGIS 10 tool Sort_management.

    """

    try:
        dTV = gp.Describe(table)

        # is the input just a table?
        inPath = dTV.CatalogPath
        isFC = gp.Describe(inPath).DataType.lower().find("table") == -1

        # create output
        gp.workspace = os.path.dirname(outputDS)
        gp.Toolbox = "management"
        if isFC:
            gp.CreateFeatureClass(gp.workspace,
                                  os.path.basename(outputDS),
                                  "",inPath)
        else:
            gp.CreateTable(gp.workspace,
                           os.path.basename(outputDS),
                           table)

        # Make list of field names in the layer
        fieldList = [f.name for f in dTV.Fields]

        # drop ObjectID field (system populates that)
        fieldList.remove(dTV.OIDFieldName)

        # Make dictionary of validated field names
        vField = {}
        for f in fieldList:
            vField[f] = gp.ValidateFieldname(f)

        # Set up search and insert cursors

        gp.AddMessage("Sorting...")
        Rows = gp.searchCursor(table, "", "", "", sortFields)
        iRows = gp.InsertCursor(outputDS)

        # Copy data in sorted order from the input to the output
        Row = Rows.next()
        while Row:
            iRow = iRows.newRow()
            for Fld in fieldList:
                # try, in case writing the field fails
                try:
                    iRow.setValue(vField[Fld], Row.getValue(Fld))
                except Exception, xmsg:
                    pass

            iRows.insertRow(iRow)
            Row = Rows.next()


        del Row,Rows, iRows,iRow

        if isFC:
            # set spatial reference
            try:
                prj = gp.Describe(inPath).SpatialReference
                gp.DefineProjection(outputDS,prj)
            except:
                pass

    except GPError:
        gp.AddError(gp.GetMessages(2))
    except Exception, msg:
        gp.AddError(str(msg))
    finally:
        # in case we crashed horribly, delete cursors
        try:
            del Row,Rows, iRows,iRow
        except:
            pass

if __name__ == '__main__':
    RunSort93()
