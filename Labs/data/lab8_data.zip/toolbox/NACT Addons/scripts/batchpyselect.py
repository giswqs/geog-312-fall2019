# example python script to run tools on a selected set

# example .bat file:
#
# :: myfile.bat
# batchpyselect.py nawqapt PROCGRP 1 out1.dbf
# batchpyselect.py nawqapt PROCGRP 2 out2.dbf

import sys, os
try:
  # add "/point" to coverage path
  # os.path.realpath converts relative to full paths
  pointCov = os.path.realpath(sys.argv[1]) + "/point"
  selField = sys.argv[2]
  selValue = sys.argv[3]
  outFile = os.path.realpath(sys.argv[4])
except:
  print "batchpy.py <pointcover> <outfile>"
  sys.exit()

Here = os.path.realpath(".")

import arcgisscripting
gp = arcgisscripting.create()
gp.Workspace = Here
gp.ScratchWorkspace = Here
# Add the NACT toolbox
gp.AddToolbox(r"D:\nact_test_20110315\NACT.tbx")

# use variables for easy editing
weightRaster = "D:/work/co1990g"
zoneRaster = "D:/work/nlcde_all"

try:
  # create a layer to select
  lyrPnt = "lyrPnt"
  gp.MakeFeatureLayer(pointCov,lyrPnt)
  gp.SelectLayerByAttribute(lyrPnt,"#","%s = %s" % (selField,selValue))
  # Run the Feature Weights To Table tool
  gp.FeatureWeightsToTable_nact(lyrPnt,Area_ID_Field,weightRaster, \
    outFile,"500 Meters","99",zoneRaster)
  gp.AddMessage(gp.GetMessages(0))
except Exception, xmsg:
  gp.AddError(gp.GetMessages(0))
  raise Error, "script failed"
