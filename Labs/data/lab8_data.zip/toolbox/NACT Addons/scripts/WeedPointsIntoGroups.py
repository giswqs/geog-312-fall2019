"""
ArcGIS Script Tool - Weed Points into Groups
"""

# Import system modules
import sys
import os
import traceback

# arcgis module
import arcgisscripting
from arcgisscripting import ExecuteError as GPError

# import nact module (../../scripts)
nactPath = os.path.join(os.path.dirname(sys.argv[0]),
                        "../../scripts")
sys.path.append(os.path.normpath(nactPath))
import nact
from nact import GPMsg, MsgError, ScratchName, CountRows
from WeedPoints import WeedPoints

# Create the Geoprocessor object
gp = nact.getGP()
gp.Toolbox = "management"

def RunWPIG():
    inputPoints = gp.GetParameterAsText(0)
    outputPoints = gp.GetParameterAsText(1)
    groupField = gp.GetParameterAsText(2)
    nearTolerance = gp.GetParameterAsText(3)
    WPIG(inputPoints,outputPoints,groupField,nearTolerance)

def WPIG(inputPoints,outputPoints,groupField="GROUP",nearTolerance=None):
    """Weed points into groups
    """
    tmpIn,tmpOut,outList,lyr = "tmpIn","tmpOut",[None],"lyr"
    try:
        tmpWS = r"C:\workspace\work.gdb"
        tmpIn = os.path.join(tmpWS,tmpIn)
        gp.CopyFeatures(inputPoints,tmpIn)
        numLeft = CountRows(tmpIn)
        GPMsg("Processing %s points..." % numLeft)
        gp.AddField(tmpIn,groupField,"LONG")
        tmpOut = os.path.join(tmpWS,"tmpPt")
        outList = []
        grp = 0
        while numLeft:
            grp += 1
            WeedPoints(tmpIn,tmpOut,nearTolerance)
            gp.MakeFeatureLayer(tmpOut,lyr)
            gp.SelectLayerByAttribute(lyr,"","WEEDCODE = 'KEEP'")
            gp.CalculateField(lyr,groupField,str(grp))
            tmpOut1 = os.path.join(tmpWS,"WeedPt%s" % grp)
            numFound = CountRows(lyr)
            GPMsg("*** %s points found" % numFound)
            gp.CopyFeatures(lyr,tmpOut1)
            outList.append(tmpOut1)
            # copy non-weeded points for next iteration
            gp.SelectLayerByAttribute(lyr,"SWITCH_SELECTION")
            gp.CopyFeatures(lyr,tmpIn)
            gp.Delete(lyr)
            numLeft = CountRows(tmpIn)
            GPMsg("%s points remaining...\n" % numLeft)

        GPMsg("cleaning up...")
        outListString = ";".join(outList)
        gp.Merge(outListString,outputPoints)
        gp.DeleteField(outputPoints,"WEEDCODE;WEEDDIST")
        GPMsg("%s groups created" % grp)
    except MsgError, xmsg:
        GPMsg("e",str(xmsg))
    except GPError:
        GPMsg("e",str(traceback.format_exc()).strip())
        numMsg = gp.MessageCount
        for i in range(0, numMsg):
            GPMsg("Return",i)
    except:
        GPMsg("e",str(traceback.format_exc()).strip())

    finally:
        for f in outList + [tmpIn,tmpOut,lyr]:
            try:
                if f: gp.Delete(f)
            except:
                pass

if __name__ == "__main__":
    RunWPIG()
