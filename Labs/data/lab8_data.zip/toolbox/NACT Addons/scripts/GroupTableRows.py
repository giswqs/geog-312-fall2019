# Name:         GroupTableRows.py
# Purpose:
# Author:       Curtis Price (cprice@usgs.gov)
# Created:      09/19/2011 12:49:24
# Environment:  ArcGIS 9.3, Python 2.5

import os
import sys
import traceback
import arcgisscripting
from arcgisscripting import ExecuteError as GPError
gp = arcgisscripting.create(9.3)

# import nact module (../../scripts)
nactPath = os.path.join(os.path.dirname(sys.argv[0]),
                        "../../scripts")
sys.path.append(os.path.normpath(nactPath))
try:
  import nact
  from nact import GPMsg, MsgError
except:
  gp.AddError("%s not found" % os.path.join(nactPath,"nact.py"))
  raise

def GroupTableRows(inTable,groupFields,caseField,seqField=None,
         sortField=None,sortType="ASCENDING"):
    """Add Case Number

    arguments

      inTable - input table or table view
      sortFields - fields to sort, ';'-delimited
      caseField  - numeric case field to create or use
      seqField (optional) - numeric sequence field to create or use
      """
    try:
        try:
            gp.AddField(inTable,caseField,"LONG")
        except:
            pass
        if seqField:
            try:
                gp.AddField(inTable,seqField,"LONG")
            except:
                pass
            if not sortField:
                sortFields = groupFields
            else:
                sortFields = "%s;%s %s" % (groupFields,sortField,sortType)
            Result = gp.GetCount_management(inTable)
            numRows = int(Result.GetOutput(0))
            Rows = gp.UpdateCursor(inTable,"","","",sortFields)
            Row = Rows.Next()
            lstFields = groupFields.split(';')
            nFld = len(lstFields)
            lstFldVal = [None] * nFld
            # initialize rows processed, case#, seq#
            rp = 1
            case = 0
            seq = 0
            increment = max(int((numRows / 100)),10)
            gp.SetProgressor("step","Grouping %s rows..." % numRows,0,numRows,
                             increment)
            while Row:
                for k in range(nFld):
                    if Row.GetValue(lstFields[k]) != lstFldVal[k]:
                        for kk in range(nFld):
                            lstFldVal[kk] = Row.GetValue(lstFields[kk])
                        case += 1
                        seq = 0
                        break
                seq += 1
                ##print "seq:",seq,"case:",case
                if seqField:
                    Row.SetValue(seqField,seq)
                Row.SetValue(caseField,case)
                Rows.UpdateRow(Row)
                if rp % increment == 0:
                  gp.SetProgressorPosition(rp)
                if rp % 500 == 0:
                  gp.SetProgressorLabel("%s / %s rows processed" % (rp,numRows))
                ##if rp % 1000 == 0: print "%s rows processed..." % rp
                rp += 1
                Row = Rows.Next()
        return case

    except GPError:
        GPMsg("e",gp.GetMessages(2))
    except Exception, xmsg:
        GPMsg("e",str(xmsg))
    finally:
        try:
            del Row, Rows
        except:
            pass


if __name__ == '__main__':
    # Get arguments
    inTable = gp.GetParameterAsText(0)
    grpField1 = gp.GetParameterAsText(1)
    grpField2 = gp.GetParameterAsText(2)
    grpField3 = gp.GetParameterAsText(3)
    caseField = gp.GetParameterAsText(4)
    seqField = gp.GetParameterAsText(5)
    sortField = gp.GetParameterAsText(6)
    sortType = gp.GetParameterAsText(7)
    lstGrp = [grpField1]
    if grpField2: lstGrp.append(grpField2)
    if grpField3: lstGrp.append(grpField3)
    strGrpFields = ';'.join(lstGrp)
    GroupTableRows(inTable,strGrpFields,caseField,seqField,sortField,sortType)
    gp.SetParameterAsText(8,inTable)
