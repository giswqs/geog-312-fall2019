# Name:         CalcMatchDistance.py
# Purpose:
# Author:       cprice
# Created:      10/06/2011 16:22:17
# Environment:  ArcGIS 9.3, Python 2.5

import os
import sys
import traceback
from arcgisscripting import ExecuteError as GPError

# import nact module (../../scripts)
nactPath = os.path.join(os.path.dirname(sys.argv[0]),
                        "../../scripts")
sys.path.append(os.path.normpath(nactPath))

try:
  import nact
  from nact import GPMsg, MsgError
except:
  gp.AddError("%s not found" % os.path.join(nactPath,"nact.py"))
  raise

gp = nact.getGP()

def CalcMatchDistance(inPoints,fromField,toPolys,toField,outPoints,
                      searchDist="1e9",coordSystem=""):
    """Calculate Match Distance tool """
    
    # usage for stand-alone python script
    if not outPoints:
        print "Usage: %s " % os.path.basename(sys.argv[0]) +\
              "<Input_points> <Field> <Match_features>\n      " \
              "<Match_field> <Output_points> {Search_distance}"
        sys.exit()    
        
    try:
        # temp variables
        lyrPt = "lyrPt"
        lyrPoly = "lyrPoly"
        tmpPt = r"in_memory\xxpt1"
        tmpPt2 = r"in_memory\xxpt2"     
        
        # usage for stand-alone python script
        if not outPoints:
            print "Usage: %s " % os.path.basename(sys.argv[0]) +\
                  "<Input_points> <Field> <Match_features>\n      " \
                  "<Match_field> <Output_points> {Search_distance}"
            sys.exit()
        
        gp.Toolbox = "management"
        gp.overwriteOutput = True
        if coordSystem != "":
            gp.outputCoordinateSystem = coordSystem
        else:
            gp.outputCoordinateSystem = gp.Describe(toPolys).catalogPath
            
        gp.MakeFeatureLayer(inPoints,lyrPt)
        gp.MakeFeatureLayer(toPolys,lyrPoly)

        fromFieldType = gp.ListFields(lyrPt,fromField)[0].Type
        toFieldType = gp.ListFields(lyrPoly,toField)[0].Type
        if fromFieldType != toFieldType:
            raise MsgError, "Join fields are not the same type."
        if fromFieldType == "String":
            qryFormat = "\"%s\" = '%s'" 
        else:
            qryFormat =  "\"%s\" = %s" 
        
        gp.CreateFeatureClass(os.path.dirname(tmpPt),
                              os.path.basename(tmpPt),"POINT",lyrPt)
        gp.CreateFeatureClass(os.path.dirname(tmpPt2),
                              os.path.basename(tmpPt2),"POINT",lyrPt)        
        gp.AddField(tmpPt2,"NEAR_FID","LONG")
        gp.AddField(tmpPt2,"NEAR_DIST","FLOAT")
        gp.CalculateField(tmpPt2,"NEAR_FID","-1")
        gp.CalculateField(tmpPt2,"NEAR_DIST","-1")        
        joinValues =  nact.ListUnique(lyrPt,fromField)
        numValues = len(joinValues)
        gp.SetProgressor("step","Near processing...",0,numValues)        
        for joinValue in joinValues:
            gp.SetProgressorLabel("Processing %s = %s" % (fromField,joinValue))            
            # select matching features
            gp.SelectLayerByAttribute(lyrPt,"#", 
                                   qryFormat % (fromField,joinValue))
            gp.SelectLayerByAttribute(lyrPoly, "#",
                                     qryFormat % (toField,joinValue))
            Result = gp.GetCount(lyrPoly)
            nPoly = int(Result.getOutput(0))       
            if nPoly > 0:
                # Copy selected points and run Near tool
                gp.CopyFeatures(lyrPt,tmpPt)                   
                gp.Near_analysis(tmpPt,lyrPoly,searchDist)
                gp.Append(tmpPt,tmpPt2,"NO_TEST")
            else:
                # No match, don't bother to run the Near
                gp.Append(lyrPt,tmpPt2,"NO_TEST")
                
            # update progressor    
            gp.SetProgressorPosition()
            
        # copy out results    
        gp.CopyFeatures(tmpPt2,outPoints)
                     
    except GPError:
        GPMsg("e",gp.GetMessages(0))
    except Exception, xmsg:
        GPMsg("e",str(xmsg))
    finally:
        for f in lyrPt,lyrPoly,tmpPt,tmpPt2:
            if f: 
                try:
                    gp.Delete(f)
                except:
                    pass


if __name__ == '__main__':
    # Get arguments
    numArg = 7
    argv = list()
    for i in range(numArg):
        try:
            argv.append(gp.GetParameterAsText(i))
        except:
            argv.append("")
    CalcMatchDistance(*argv)
    
  
